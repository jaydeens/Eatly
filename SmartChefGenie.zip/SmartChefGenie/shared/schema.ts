import { pgTable, text, serial, integer, boolean, jsonb, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password"),
  name: text("name"),
  email: text("email").unique(),
  image: text("image"),
  provider: text("provider").default("credentials"),
  providerId: text("providerId"),
  createdAt: timestamp("created_at").defaultNow(),
  // Health profile
  dateOfBirth: timestamp("date_of_birth"),
  isPregnant: boolean("is_pregnant"),
  allergies: text("allergies").array(),
  medicalConditions: text("medical_conditions").array(),
  dietaryRestrictions: text("dietary_restrictions").array(),
  // Physical metrics
  heightCm: integer("height_cm"),
  weightKg: integer("weight_kg"),
  lastWeightUpdate: timestamp("last_weight_update"),
  targetWeightKg: integer("target_weight_kg"),
  notificationsEnabled: boolean("notifications_enabled").default(true),
  // App preferences
  coachNickname: text("coach_nickname").default("PC"),
});

// Auth provider accounts
export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  provider: text("provider").notNull(),
  providerAccountId: text("provider_account_id").notNull(),
  refresh_token: text("refresh_token"),
  access_token: text("access_token"),
  expires_at: integer("expires_at"),
  token_type: text("token_type"),
  scope: text("scope"),
  id_token: text("id_token"),
  session_state: text("session_state"),
});

// User schema for registration and login
export const loginSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
});

export const registerSchema = z.object({
  username: z.string().min(3, { message: "Username must be at least 3 characters" }),
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  dateOfBirth: z.string()
    .refine((val) => {
      // Simple date validation
      return !isNaN(Date.parse(val));
    }, { message: "Please enter a valid date of birth" })
    .transform((val) => new Date(val)), // Transform string to Date
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
  confirmPassword: z.string().min(6, { message: "Password must be at least 6 characters" }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  email: true,
  image: true,
  provider: true,
  providerId: true,
  dateOfBirth: true,
  isPregnant: true,
  allergies: true,
  medicalConditions: true,
  dietaryRestrictions: true,
  heightCm: true,
  weightKg: true,
  lastWeightUpdate: true,
  targetWeightKg: true,
  notificationsEnabled: true,
  coachNickname: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type LoginFormValues = z.infer<typeof loginSchema>;
export type RegisterFormValues = z.infer<typeof registerSchema>;

// Recipe schema
export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  image: text("image").notNull(),
  time: text("time").notNull(),
  servings: integer("servings").notNull(),
  calories: integer("calories").notNull(),
  difficulty: text("difficulty").notNull(),
  healthScore: integer("health_score"),
  tags: text("tags").array().notNull(),
  ingredients: text("ingredients").array().notNull(),
  instructions: text("instructions").array().notNull(),
  nutrition: jsonb("nutrition").notNull(),
  tips: text("tips").notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
});

export const insertRecipeSchema = createInsertSchema(recipes).omit({
  id: true,
});

export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type Recipe = typeof recipes.$inferSelect;

// Ingredient schema for recipe generation
export const ingredientSchema = z.object({
  ingredients: z.array(z.string()),
  dietaryFilters: z.array(z.object({
    name: z.string(),
    active: z.boolean(),
    icon: z.string(),
  })),
  cuisineType: z.string().optional(),
  servings: z.number().default(2),
});

export type IngredientInput = z.infer<typeof ingredientSchema>;

// Recipe generation response
export const generateRecipeSchema = z.object({
  cuisineType: z.string().optional(),
  recipes: z.array(z.object({
    title: z.string(),
    image: z.string(),
    description: z.string(),
    time: z.string(),
    servings: z.number(),
    calories: z.number(),
    difficulty: z.string(),
    healthScore: z.number().optional(),
    tags: z.array(z.string()),
    ingredients: z.array(z.string()),
    instructions: z.array(z.string()),
    nutrition: z.object({
      protein: z.number(),
      carbs: z.number(),
      fat: z.number(),
      fiber: z.number(),
    }),
    tips: z.string(),
  })),
});

export type GeneratedRecipes = z.infer<typeof generateRecipeSchema>;

// Schema for nutritional goals
export const nutritionGoals = pgTable("nutrition_goals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  caloriesTarget: integer("calories_target"), // Daily target in kcal
  proteinTarget: integer("protein_target"), // Daily target in grams
  carbsTarget: integer("carbs_target"), // Daily target in grams
  fatTarget: integer("fat_target"), // Daily target in grams
  fiberTarget: integer("fiber_target"), // Daily target in grams
  waterTarget: integer("water_target"), // Daily target in ml
  healthScoreTarget: integer("health_score_target"), // Target health score (1-10)
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertNutritionGoalSchema = createInsertSchema(nutritionGoals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertNutritionGoal = z.infer<typeof insertNutritionGoalSchema>;
export type NutritionGoal = typeof nutritionGoals.$inferSelect;

// Schema for nutritional history tracking
export const nutritionLogs = pgTable("nutrition_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  date: timestamp("date").defaultNow().notNull(),
  mealType: text("meal_type").notNull(), // breakfast, lunch, dinner, snack
  foodItems: text("food_items").array().notNull(),
  calories: integer("calories"),
  protein: integer("protein"), // in grams
  carbs: integer("carbs"), // in grams
  fat: integer("fat"), // in grams
  fiber: integer("fiber"), // in grams
  water: integer("water"), // in ml
  healthScore: integer("health_score"), // 1-10 scale
  imageUrl: text("image_url"),
  recipeId: integer("recipe_id"), // Optional link to a recipe
  notes: text("notes"), // User notes about the meal
});

export const insertNutritionLogSchema = createInsertSchema(nutritionLogs).omit({
  id: true,
});

export type InsertNutritionLog = z.infer<typeof insertNutritionLogSchema>;
export type NutritionLog = typeof nutritionLogs.$inferSelect;

// Schema for weight tracking history
export const weightLogs = pgTable("weight_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  date: timestamp("date").defaultNow().notNull(),
  weightKg: integer("weight_kg").notNull(),
  notes: text("notes"),
  bmi: integer("bmi"), // Body Mass Index calculation (stored as integer, e.g. 245 for BMI 24.5)
  prediction: jsonb("prediction"), // AI prediction data
});

export const insertWeightLogSchema = createInsertSchema(weightLogs).omit({
  id: true,
});

export type InsertWeightLog = z.infer<typeof insertWeightLogSchema>;
export type WeightLog = typeof weightLogs.$inferSelect;

// Schema for notification preferences
export const notificationPreferences = pgTable("notification_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  mealSuggestions: boolean("meal_suggestions").default(true),
  weightReminders: boolean("weight_reminders").default(true),
  nutritionAlerts: boolean("nutrition_alerts").default(true),
  preferredTime: text("preferred_time").default("08:00"), // Time of day for notifications
  lastNotification: timestamp("last_notification"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertNotificationPreferencesSchema = createInsertSchema(notificationPreferences).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertNotificationPreferences = z.infer<typeof insertNotificationPreferencesSchema>;
export type NotificationPreferences = typeof notificationPreferences.$inferSelect;

// Chat message schema for cooking assistant
export const chatMessageSchema = z.object({
  role: z.enum(['user', 'assistant', 'system']),
  content: z.string(),
});

export type ChatMessage = z.infer<typeof chatMessageSchema>;

// Kitchen Timer Settings
export const timerSettings = pgTable("timer_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  durationSeconds: integer("duration_seconds").notNull(),
  isMuted: boolean("is_muted").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertTimerSettingsSchema = createInsertSchema(timerSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertTimerSettings = z.infer<typeof insertTimerSettingsSchema>;
export type TimerSettings = typeof timerSettings.$inferSelect;

// Cooking Progress Tracking
export const cookingProgress = pgTable("cooking_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  recipeId: integer("recipe_id").references(() => recipes.id).notNull(),
  startTime: timestamp("start_time").defaultNow().notNull(),
  endTime: timestamp("end_time"),
  completedSteps: integer("completed_steps").array(),
  status: text("status").default("in_progress"), // in_progress, completed, abandoned
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCookingProgressSchema = createInsertSchema(cookingProgress).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCookingProgress = z.infer<typeof insertCookingProgressSchema>;
export type CookingProgress = typeof cookingProgress.$inferSelect;

// Badges for achievements
export const badges = pgTable("badges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull(),
  icon: text("icon").notNull(), // SVG or icon path
  category: text("category").notNull(), // cooking, nutrition, seasonal, etc.
  requirements: jsonb("requirements").notNull(), // JSON with badge requirements
  tier: integer("tier").default(1), // 1, 2, 3 for bronze, silver, gold
  season: text("season"), // "spring", "summer", "fall", "winter" - null if not seasonal
  points: integer("points").default(10), // Points awarded for this badge
  isLimited: boolean("is_limited").default(false), // If true, badge is limited time
  validFrom: timestamp("valid_from"), // Start date for seasonal badges
  validUntil: timestamp("valid_until"), // End date for seasonal badges
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertBadgeSchema = createInsertSchema(badges).omit({
  id: true,
  createdAt: true,
});

export type InsertBadge = z.infer<typeof insertBadgeSchema>;
export type Badge = typeof badges.$inferSelect;

// User-Badge relationship for earned badges
export const userBadges = pgTable("user_badges", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  badgeId: integer("badge_id").notNull().references(() => badges.id),
  earnedAt: timestamp("earned_at").defaultNow(),
  progress: integer("progress").default(0), // For badges with progress tracking (0-100%)
  showOnProfile: boolean("show_on_profile").default(true),
});

export const insertUserBadgeSchema = createInsertSchema(userBadges).omit({
  id: true,
});

export type InsertUserBadge = z.infer<typeof insertUserBadgeSchema>;
export type UserBadge = typeof userBadges.$inferSelect;

// Seasonal challenges
export const cookingChallenges = pgTable("cooking_challenges", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  season: text("season").notNull(), // "spring", "summer", "fall", "winter"
  year: integer("year").notNull(), // Year of the challenge
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  requiredRecipeCount: integer("required_recipe_count").notNull(), // Number of recipes to complete
  requiredIngredients: text("required_ingredients").array(), // Ingredients that must be used
  badgeId: integer("badge_id").references(() => badges.id), // Badge earned on completion
  points: integer("points").default(50), // Points awarded for completion
  isActive: boolean("is_active").default(true),
  image: text("image"), // Challenge promotional image
  recipeIds: integer("recipe_ids").array(), // Suggested recipe IDs for this challenge
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCookingChallengeSchema = createInsertSchema(cookingChallenges).omit({
  id: true,
  createdAt: true,
});

export type InsertCookingChallenge = z.infer<typeof insertCookingChallengeSchema>;
export type CookingChallenge = typeof cookingChallenges.$inferSelect;

// User progress in challenges
export const userChallengeProgress = pgTable("user_challenge_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  challengeId: integer("challenge_id").notNull().references(() => cookingChallenges.id),
  completedRecipeIds: integer("completed_recipe_ids").array().default([]),
  progress: integer("progress").default(0), // 0-100%
  isCompleted: boolean("is_completed").default(false),
  completedAt: timestamp("completed_at"),
  startedAt: timestamp("started_at").defaultNow(),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const insertUserChallengeProgressSchema = createInsertSchema(userChallengeProgress).omit({
  id: true,
  lastUpdated: true,
});

export type InsertUserChallengeProgress = z.infer<typeof insertUserChallengeProgressSchema>;
export type UserChallengeProgress = typeof userChallengeProgress.$inferSelect;
