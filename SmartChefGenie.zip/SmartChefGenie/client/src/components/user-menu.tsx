import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { UserIcon, BookmarkIcon, LeafIcon, LogInIcon, LogOutIcon, ActivityIcon } from "@/components/ui/icons";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/use-auth";

export default function UserMenu() {
  const [, navigate] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  
  // Handle logout
  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };
  
  // Get user initials for avatar
  const getInitials = () => {
    if (!user || !user.name) return '?';
    return user.name.split(' ')
      .map(part => part.charAt(0).toUpperCase())
      .slice(0, 2)
      .join('');
  };
  
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        {isAuthenticated ? (
          <Button variant="ghost" size="sm" className="rounded-full p-0 h-9 w-9 overflow-hidden border border-gray-200 hover:border-orange-300 transition-colors">
            <Avatar className="h-full w-full">
              <AvatarFallback className="bg-gradient-to-br from-orange-400 to-orange-500 text-white font-medium">
                {getInitials()}
              </AvatarFallback>
            </Avatar>
          </Button>
        ) : (
          <Button variant="ghost" size="sm" className="flex items-center gap-1 hover:bg-orange-100 hover:text-orange-600 transition-colors">
            <LogInIcon className="h-4 w-4" />
            <span>Sign In</span>
          </Button>
        )}
      </DropdownMenuTrigger>
      
      {isAuthenticated ? (
        <DropdownMenuContent align="end" className="w-64 p-2">
          <div className="flex items-center p-2 pb-3 border-b border-gray-100">
            <Avatar className="h-10 w-10 mr-3">
              <AvatarFallback className="bg-gradient-to-br from-orange-400 to-orange-500 text-white font-medium">
                {getInitials()}
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col">
              <p className="font-medium text-gray-800 dark:text-gray-200">{user?.name}</p>
              <p className="truncate text-sm text-gray-500">
                {user?.email}
              </p>
            </div>
          </div>
          
          <div className="p-1">
            <DropdownMenuItem 
              className="cursor-pointer rounded-md py-2 my-1 flex items-center"
              onClick={() => navigate('/saved-recipes')}
            >
              <BookmarkIcon className="mr-2 h-4 w-4 text-orange-500" />
              <span>Saved Recipes</span>
            </DropdownMenuItem>
            
            <DropdownMenuItem 
              className="cursor-pointer rounded-md py-2 my-1 flex items-center"
              onClick={() => navigate('/nutrition')}
            >
              <LeafIcon className="mr-2 h-4 w-4 text-orange-500" />
              <span>Nutrition Tracking</span>
            </DropdownMenuItem>
            
            <DropdownMenuItem 
              className="cursor-pointer rounded-md py-2 my-1 flex items-center"
              onClick={() => navigate('/health')}
            >
              <ActivityIcon className="mr-2 h-4 w-4 text-orange-500" />
              <span>Weight Management</span>
            </DropdownMenuItem>
            
            <DropdownMenuItem 
              className="cursor-pointer rounded-md py-2 my-1 flex items-center"
              onClick={() => navigate('/preferences')}
            >
              <svg className="mr-2 h-4 w-4 text-orange-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="3"></circle>
                <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
              </svg>
              <span>Preferences</span>
            </DropdownMenuItem>
            
            <DropdownMenuItem 
              className="cursor-pointer rounded-md py-2 my-1 flex items-center"
              onClick={() => navigate('/account')}
            >
              <UserIcon className="mr-2 h-4 w-4 text-orange-500" />
              <span>Account Settings</span>
            </DropdownMenuItem>
            
            <DropdownMenuSeparator />
            
            <DropdownMenuItem 
              className="cursor-pointer rounded-md py-2 my-1 flex items-center text-red-600"
              onClick={handleLogout}
            >
              <LogOutIcon className="mr-2 h-4 w-4" />
              <span>Sign Out</span>
            </DropdownMenuItem>
          </div>
        </DropdownMenuContent>
      ) : (
        <DropdownMenuContent align="end" className="w-48 p-2">
          <DropdownMenuItem 
            className="cursor-pointer rounded-md py-2 my-1 flex items-center"
            onClick={() => navigate('/login')}
          >
            <LogInIcon className="mr-2 h-4 w-4 text-orange-500" />
            <span>Sign In</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      )}
    </DropdownMenu>
  );
}