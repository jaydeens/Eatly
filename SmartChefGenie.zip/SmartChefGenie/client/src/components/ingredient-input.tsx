import { useState, useRef, useEffect } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent } from "./ui/card";
import { Separator } from "./ui/separator";
import { Badge } from "./ui/badge";
import { 
  CameraIcon, 
  FilterIcon, 
  PlusIcon, 
  XIcon, 
  WandIcon, 
  SparklesIcon, 
  SaladIcon, 
  ChefHatIcon,
  AlertCircleIcon,
  GlobeIcon,
  UsersIcon
} from "./ui/icons";
import { cn } from "@/lib/utils";

type DietaryFilter = {
  name: string;
  active: boolean;
  icon: string;
};

type CuisineType = {
  name: string;
  active: boolean;
};

interface IngredientInputProps {
  ingredients: string[];
  dietaryFilters: DietaryFilter[];
  cuisineTypes: CuisineType[];
  servings: number;
  addIngredient: (ingredient: string) => void;
  removeIngredient: (index: number) => void;
  toggleDietaryFilter: (index: number) => void;
  toggleCuisineType: (index: number) => void;
  setServings: (servings: number) => void;
  onScan: () => void;
  onGenerate: () => void;
  isGenerating: boolean;
}

export default function IngredientInput({
  ingredients,
  dietaryFilters,
  cuisineTypes,
  servings,
  addIngredient,
  removeIngredient,
  toggleDietaryFilter,
  toggleCuisineType,
  setServings,
  onScan,
  onGenerate,
  isGenerating
}: IngredientInputProps) {
  const [ingredientInput, setIngredientInput] = useState("");
  const [showDietaryFilters, setShowDietaryFilters] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [pendingIngredients, setPendingIngredients] = useState<string[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  // Animated suggestions effect - much larger pool of ingredients
  const allIngredients = [
    // Vegetables
    "tomatoes", "spinach", "carrots", "broccoli", "bell peppers", "zucchini", "eggplant", 
    "mushrooms", "onions", "garlic", "potatoes", "sweet potatoes", "corn", "peas", "asparagus",
    "cabbage", "lettuce", "kale", "celery", "cucumber", "cauliflower", "green beans", "leeks",
    // Fruits
    "apples", "bananas", "oranges", "lemons", "limes", "strawberries", "blueberries", "raspberries",
    "pineapple", "mango", "avocado", "peaches", "pears", "plums", "grapes", "watermelon", "cherries",
    // Proteins
    "chicken", "beef", "pork", "turkey", "tofu", "tempeh", "eggs", "salmon", "tuna", "shrimp", 
    "bacon", "sausage", "ham", "chicken thighs", "ground beef", "ground turkey", "fish fillets",
    // Grains
    "rice", "pasta", "quinoa", "couscous", "oats", "barley", "farro", "bread", "tortillas", "noodles",
    // Dairy
    "milk", "cheese", "yogurt", "butter", "cream", "sour cream", "cream cheese", "parmesan", "cheddar",
    // Pantry items
    "flour", "sugar", "olive oil", "vegetable oil", "soy sauce", "vinegar", "honey", "maple syrup",
    "peanut butter", "tomato sauce", "coconut milk", "beans", "chickpeas", "lentils", "nuts", "seeds"
  ];
  
  // Shuffle and get random suggestions from the pool
  const getRandomIngredients = () => {
    const shuffled = [...allIngredients].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, 10);
  };
  
  const [suggestedIngredients, setSuggestedIngredients] = useState(getRandomIngredients());

  const handleAddIngredient = () => {
    if (ingredientInput.trim() !== "") {
      addIngredient(ingredientInput.trim());
      setIngredientInput("");
      setIsTyping(false);
      // Refresh suggestions when an ingredient is added
      setSuggestedIngredients(getRandomIngredients());
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddIngredient();
    }
  };

  const focusInput = () => {
    inputRef.current?.focus();
  };

  // Effect to periodically refresh suggestions
  useEffect(() => {
    // Refresh suggestions every 15 seconds if the user is active on the page
    const refreshTimer = setInterval(() => {
      setSuggestedIngredients(getRandomIngredients());
    }, 15000);
    
    return () => clearInterval(refreshTimer);
  }, []);
  
  // Animation for pulse effect
  useEffect(() => {
    if (isGenerating && pendingIngredients.length === 0) {
      const timer = setTimeout(() => {
        setPendingIngredients([
          "Analyzing ingredients...",
          "Checking compatibility...",
          "Finding optimal combinations...",
          "Preparing suggestions..."
        ]);
      }, 500);
      return () => clearTimeout(timer);
    }

    if (!isGenerating) {
      setPendingIngredients([]);
    }
  }, [isGenerating]);

  return (
    <div className="relative">
      {/* Background effect */}
      <div className="absolute -inset-1 bg-gradient-to-r from-orange-500/20 to-orange-400/10 rounded-[22px] blur-lg opacity-70 group-hover:opacity-100 transition duration-1000"></div>

      <div className="relative bg-card dark:bg-black/30 backdrop-blur-md rounded-2xl shadow-xl border border-orange-500/20 p-6 overflow-hidden">
        {/* AI pattern background */}
        <div className="absolute inset-0 opacity-5">
          <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
            <defs>
              <pattern id="ai-pattern" patternUnits="userSpaceOnUse" width="30" height="30" patternTransform="rotate(45)">
                <rect x="0" y="0" width="3" height="10" fill="currentColor" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#ai-pattern)" />
          </svg>
        </div>

        <div className="relative z-10">
          {/* Cuisine Type and Servings Selectors */}
          <div className="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <select 
                className="w-full h-10 px-3 py-2 rounded-lg border-2 border-orange-500/30 bg-background/50 text-sm font-medium hover:border-orange-500/50 focus:border-orange-500 focus:outline-none transition-colors"
                onChange={(e) => toggleCuisineType(cuisineTypes.findIndex(c => c.name === e.target.value))}
              >
                <option value="">Select Cuisine Type</option>
                {cuisineTypes.map((cuisine) => (
                  <option key={cuisine.name} value={cuisine.name}>
                    {cuisine.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <div className="flex items-center gap-2">
                <UsersIcon size={16} className="text-orange-500" />
                <span className="text-sm font-medium">Servings:</span>
                <select 
                  className="w-full h-10 px-3 py-2 rounded-lg border-2 border-orange-500/30 bg-background/50 text-sm font-medium hover:border-orange-500/50 focus:border-orange-500 focus:outline-none transition-colors"
                  value={servings}
                  onChange={(e) => setServings(Number(e.target.value))}
                >
                  {[1, 2, 3, 4, 5, 6, 8, 10, 12].map((num) => (
                    <option key={num} value={num}>
                      {num} {num === 1 ? 'serving' : 'servings'}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Header with AI badge */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-orange-500 to-orange-400 p-2 rounded-xl shadow-lg">
                <SaladIcon size={16} className="text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Ingredient AI</h3>
                <p className="text-xs text-muted-foreground">Enhanced by machine learning</p>
              </div>
            </div>

            <Badge 
              variant="outline" 
              className="bg-background/50 dark:bg-black/40 backdrop-blur-sm border-orange-500/30 text-foreground"
            >
              <div className="flex items-center gap-1.5">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </span>
                <span className="text-xs">AI Powered</span>
              </div>
            </Badge>
          </div>

          {/* Input section */}
          <div className="space-y-6">
            <div>
              <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-orange-500 to-orange-400 rounded-lg blur opacity-30 group-hover:opacity-100 transition duration-500"></div>
                <div className="relative flex rounded-md shadow-sm bg-card dark:bg-black/50 overflow-hidden">
                  <Input
                    ref={inputRef}
                    type="text"
                    value={ingredientInput}
                    onChange={(e) => {
                      setIngredientInput(e.target.value);
                      setIsTyping(e.target.value.length > 0);
                    }}
                    onKeyDown={handleKeyDown}
                    className="flex-grow border-0 focus-visible:ring-0 focus-visible:ring-offset-0 py-6 px-4 bg-transparent text-foreground placeholder:text-muted-foreground/70"
                    placeholder="Add ingredients from your kitchen..."
                  />
                  <Button
                    type="button"
                    onClick={handleAddIngredient}
                    className="rounded-none px-4 bg-gradient-to-r from-orange-500 to-orange-400 hover:from-orange-600 hover:to-orange-500 text-white border-0"
                  >
                    <PlusIcon size={18} />
                  </Button>
                </div>
              </div>

              {/* Intelligent suggestions - always show suggestions regardless of ingredient count */}
              {!isTyping && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  <div className="w-full flex justify-between items-center mb-1">
                    <p className="text-xs text-muted-foreground mr-1 mt-1">Suggestions:</p>
                    <button 
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        
                        // Use setTimeout to prevent any potential auth check race conditions
                        setTimeout(() => {
                          setSuggestedIngredients(getRandomIngredients());
                        }, 0);
                      }}
                      className="text-xs text-orange-500 hover:text-orange-600 flex items-center gap-1"
                    >
                      <span>Refresh</span>
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"></path>
                        <path d="M21 3v5h-5"></path>
                        <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"></path>
                        <path d="M3 21v-5h5"></path>
                      </svg>
                    </button>
                  </div>
                  {suggestedIngredients.slice(0, 8).map((suggestion, idx) => (
                    <button
                      key={idx}
                      onClick={(e) => {
                        // Prevent default to avoid potential page navigation
                        e.preventDefault();
                        e.stopPropagation();
                        
                        // Use setTimeout to prevent any potential auth check race conditions
                        setTimeout(() => {
                          addIngredient(suggestion);
                          focusInput();
                          // Refresh suggestions after adding
                          setSuggestedIngredients(getRandomIngredients());
                        }, 0);
                      }}
                      type="button"
                      className={cn(
                        "text-xs px-2 py-1 rounded-full border border-orange-500/20 text-foreground/80 hover:bg-orange-500/10 transition-all",
                        `animate-fade-in-${(idx % 5) + 1}`
                      )}
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Actions Row */}
            <div className="flex flex-wrap gap-2">
              <Button
                type="button"
                onClick={onScan}
                variant="outline"
                className="bg-background/50 dark:bg-black/40 backdrop-blur-sm border-orange-500/30 text-foreground hover:bg-orange-500/10 hover:border-orange-500/50"
              >
                <div className="flex items-center gap-1.5">
                  <CameraIcon size={16} className="text-orange-500" />
                  <span>Scan Ingredients</span>
                </div>
              </Button>

              <Button
                type="button"
                onClick={() => setShowDietaryFilters(!showDietaryFilters)}
                variant="outline"
                className="bg-background/50 dark:bg-black/40 backdrop-blur-sm border-orange-500/30 text-foreground hover:bg-orange-500/10 hover:border-orange-500/50"
              >
                <div className="flex items-center gap-1.5">
                  <FilterIcon size={16} className="text-orange-500" />
                  <span>{showDietaryFilters ? "Hide Filters" : "Dietary Filters"}</span>
                </div>
              </Button>
            </div>
          </div>

          {/* Dietary Filters */}
          {showDietaryFilters && (
            <div className="mt-6 pt-4 border-t border-orange-500/10">
              <h3 className="text-sm font-medium text-foreground mb-3 flex items-center gap-2">
                <SparklesIcon size={14} className="text-orange-500" />
                <span>Dietary Preferences</span>
              </h3>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {dietaryFilters.map((filter, index) => (
                  <Button
                    key={index}
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setTimeout(() => toggleDietaryFilter(index), 0);
                    }}
                    variant="outline"
                    size="sm"
                    className={cn(
                      "border-orange-500/30 hover:bg-orange-500/10",
                      filter.active && "bg-orange-500/10 border-orange-500/60 font-medium"
                    )}
                  >
                    <span className="flex items-center gap-1.5">
                      {filter.active && <div className="w-1.5 h-1.5 rounded-full bg-orange-500" />}
                      <span>{filter.name}</span>
                    </span>
                  </Button>
                ))}
              </div>

              {/* Cuisine Types */}
              <div className="mt-6">
                <h3 className="text-sm font-medium text-foreground mb-3 flex items-center gap-2">
                  <GlobeIcon size={14} className="text-orange-500" />
                  <span>Cuisine Preferences</span>
                </h3>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {cuisineTypes.map((cuisine, index) => (
                    <Button
                      key={index}
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setTimeout(() => toggleCuisineType(index), 0);
                      }}
                      variant="outline"
                      size="sm"
                      className={cn(
                        "border-orange-500/30 hover:bg-orange-500/10",
                        cuisine.active && "bg-orange-500/10 border-orange-500/60 font-medium"
                      )}
                    >
                      <span className="flex items-center gap-1.5">
                        {cuisine.active && <div className="w-1.5 h-1.5 rounded-full bg-orange-500" />}
                        <span>{cuisine.name}</span>
                      </span>
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Selected Ingredients */}
          <div className="mt-6 pt-4 border-t border-orange-500/10">
            <h3 className="text-sm font-medium flex items-center gap-2 mb-3">
              <ChefHatIcon size={14} className="text-orange-500" />
              <span>Your Ingredient List</span>
            </h3>

            {ingredients.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {ingredients.map((ingredient, index) => (
                  <Badge
                    key={index}
                    variant="outline"
                    className="px-3 py-1.5 bg-background/50 dark:bg-black/40 backdrop-blur-sm border-orange-500/30 text-foreground"
                  >
                    <span className="mr-1.5">{ingredient}</span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setTimeout(() => removeIngredient(index), 0);
                      }}
                      className="text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <XIcon size={12} />
                    </button>
                  </Badge>
                ))}
              </div>
            ) : (
              <div className="flex items-center gap-2 text-muted-foreground text-sm">
                <AlertCircleIcon size={14} />
                <span>Add ingredients to get started</span>
              </div>
            )}
          </div>

          {/* AI Generation Button */}
          <div className="mt-6 pt-4 border-t border-orange-500/10">
            {isGenerating && (
              <div className="mb-4">
                <div className="space-y-2">
                  {pendingIngredients.map((text, idx) => (
                    <div 
                      key={idx} 
                      className="flex items-center gap-2 text-sm text-foreground/80"
                      style={{ opacity: 0, animation: `fadeIn 0.5s ${idx * 0.7}s forwards` }}
                    >
                      <div className="h-4 w-4 relative">
                        <div className="absolute inset-0 bg-orange-500/20 rounded-full animate-ping"></div>
                        <div className="absolute inset-0 bg-orange-500 rounded-full scale-50"></div>
                      </div>
                      <span>{text}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <Button
              type="button"
              onClick={onGenerate}
              disabled={isGenerating || ingredients.length === 0}
              className="w-full relative group overflow-hidden"
            >
              <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-orange-600 to-orange-400 group-hover:from-orange-500 group-hover:to-orange-300 transition-all duration-300"></div>

              <div className="relative flex items-center justify-center gap-2 py-3 text-white font-medium">
                {isGenerating ? (
                  <>
                    <div className="h-5 w-5 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
                    <span>Hold on now, let me cook</span>
                  </>
                ) : (
                  <>
                    <WandIcon className="text-white" size={18} />
                    <span>Generate Personalized Recipes</span>
                  </>
                )}
              </div>
            </Button>

            {!isGenerating && ingredients.length > 0 && (
              <p className="text-xs text-center mt-2 text-muted-foreground">
                Our AI will generate personalized recipes based on your ingredients
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}