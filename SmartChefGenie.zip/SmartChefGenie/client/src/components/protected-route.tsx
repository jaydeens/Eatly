import { ReactNode } from "react";
import { useLocation, Route, Redirect } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

interface ProtectedRouteProps {
  path: string;
  children: ReactNode;
}

export function ProtectedRoute({ path, children }: ProtectedRouteProps) {
  const { isAuthenticated, isLoading } = useAuth();
  const [location] = useLocation();

  if (isLoading) {
    return (
      <Route path={path}>
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
        </div>
      </Route>
    );
  }

  // If the user isn't authenticated, redirect to /auth
  if (!isAuthenticated) {
    return (
      <Route path={path}>
        <Redirect to={`/auth?redirect=${encodeURIComponent(location)}`} />
      </Route>
    );
  }

  // If the user is authenticated, render the children
  return <Route path={path}>{children}</Route>;
}