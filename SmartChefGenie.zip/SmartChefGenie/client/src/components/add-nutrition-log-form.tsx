import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { format } from "date-fns";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { CalendarIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { InsertNutritionLog } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Form validation schema
const formSchema = z.object({
  date: z.date({
    required_error: "Please select a date",
  }),
  mealType: z.enum(["breakfast", "lunch", "dinner", "snack"], {
    required_error: "Please select a meal type",
  }),
  foodItems: z.string()
    .min(3, "Please enter at least one food item")
    .transform(val => val.split(',').map(item => item.trim())),
  calories: z.coerce.number().min(0).optional(),
  protein: z.coerce.number().min(0).optional(),
  carbs: z.coerce.number().min(0).optional(),
  fat: z.coerce.number().min(0).optional(),
  fiber: z.coerce.number().min(0).optional(),
  water: z.coerce.number().min(0).optional(),
  healthScore: z.coerce.number().min(1).max(10).optional(),
  notes: z.string().optional(),
});

type FormValues = z.input<typeof formSchema>;

interface AddNutritionLogFormProps {
  onSuccess?: () => void;
  onCancel?: () => void;
}

export default function AddNutritionLogForm({ onSuccess, onCancel }: AddNutritionLogFormProps) {
  const { toast } = useToast();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // Define the form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      date: new Date(),
      mealType: "lunch",
      foodItems: "",
      notes: "",
    },
  });
  
  // Mutation for saving nutrition log
  const saveMutation = useMutation({
    mutationFn: async (values: z.output<typeof formSchema>) => {
      // Make a copy of values to ensure foodItems is properly handled
      const nutritionLog: Partial<InsertNutritionLog> = {
        ...values,
        userId: 0, // Will be set by the server based on the authenticated user
      };
      
      const response = await apiRequest({
        method: "POST", 
        url: "/api/nutrition/logs", 
        data: nutritionLog
      });
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/nutrition/logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/nutrition/stats'] });
      toast({
        title: "Success!",
        description: "Your meal has been logged.",
      });
      form.reset({
        date: new Date(),
        mealType: "lunch",
        foodItems: "",
        notes: "",
      });
      if (onSuccess) onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to log meal",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Function to analyze food items and auto-fill nutritional info
  const analyzeFood = async () => {
    const foodItems = form.getValues("foodItems").split(',').map(item => item.trim());
    
    if (!foodItems || foodItems.length === 0 || (foodItems.length === 1 && !foodItems[0])) {
      toast({
        title: "No food items",
        description: "Please enter at least one food item to analyze",
        variant: "destructive",
      });
      return;
    }
    
    setIsAnalyzing(true);
    
    try {
      // First try to use OpenAI for nutrition analysis (more accurate)
      try {
        const openaiResponse = await apiRequest<{success: boolean, analysis: any}>({
          method: "POST", 
          url: "/api/food/analyze/nutrition", 
          data: { foodItems }
        });
        
        if (openaiResponse?.success && openaiResponse?.analysis) {
          const analysis = openaiResponse.analysis;
          
          const calories = Math.round(analysis.calories || 0);
          const protein = Math.round(analysis.protein || 0);
          const carbs = Math.round(analysis.carbs || 0);
          const fat = Math.round(analysis.fat || 0);
          const fiber = Math.round(analysis.fiber || 0);
          
          // Always calculate health score based on nutritional content
          const healthScore = Math.min(10, Math.max(1, Math.round(
            (protein / 50 * 4) + // Protein (good)
            (fiber / 30 * 3) + // Fiber (good)
            (3) - // Base score
            (fat > 70 ? 2 : fat > 40 ? 1 : 0) - // Fat penalty
            (carbs > 300 ? 2 : carbs > 200 ? 1 : 0) // Carbs penalty
          )));
          
          form.setValue("calories", calories);
          form.setValue("protein", protein);
          form.setValue("carbs", carbs);
          form.setValue("fat", fat);
          form.setValue("fiber", fiber);
          form.setValue("healthScore", healthScore);
          
          toast({
            title: "Analysis complete",
            description: "Nutritional information has been filled in based on your food items.",
          });
          return;
        }
      } catch (e) {
        console.log("OpenAI analysis failed, falling back to Spoonacular", e);
      }
      
      // Fallback to Spoonacular
      const response = await apiRequest<{success: boolean, nutritionInfo: any}>({
        method: "POST", 
        url: "/api/spoonacular/nutrition", 
        data: { ingredients: foodItems }
      });
      
      if (response && response.success && response.nutritionInfo) {
        const { calories, protein, carbs, fat, fiber } = response.nutritionInfo;
        
        // Estimate health score based on nutrition
        const healthScore = Math.min(10, Math.max(1, Math.round(
          (protein / 50 * 4) + // Protein (good)
          (fiber / 30 * 3) + // Fiber (good)
          (3) - // Base score
          (fat > 70 ? 2 : fat > 40 ? 1 : 0) - // Fat penalty
          (carbs > 300 ? 2 : carbs > 200 ? 1 : 0) // Carbs penalty
        )));
        
        form.setValue("calories", Math.round(calories));
        form.setValue("protein", Math.round(protein));
        form.setValue("carbs", Math.round(carbs));
        form.setValue("fat", Math.round(fat));
        form.setValue("fiber", Math.round(fiber));
        form.setValue("healthScore", healthScore);
        
        toast({
          title: "Analysis complete",
          description: "Nutritional information has been filled in based on your food items.",
        });
      } else {
        throw new Error("Could not analyze food items");
      }
    } catch (error) {
      console.error("Error analyzing food:", error);
      toast({
        title: "Analysis failed",
        description: "Could not determine nutritional information. Please fill in manually.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };
  
  function onSubmit(values: FormValues) {
    // Transform foodItems from string to array before submitting
    const processedValues = {
      ...values,
      foodItems: values.foodItems.split(',').map(item => item.trim()).filter(item => item.length > 0)
    };
    saveMutation.mutate(processedValues as z.output<typeof formSchema>);
  }
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Log a Meal</CardTitle>
        <CardDescription>Record what you've eaten to track your nutrition</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) =>
                            date > new Date() || date < new Date("1900-01-01")
                          }
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="mealType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Meal Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a meal type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="breakfast">Breakfast</SelectItem>
                        <SelectItem value="lunch">Lunch</SelectItem>
                        <SelectItem value="dinner">Dinner</SelectItem>
                        <SelectItem value="snack">Snack</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="foodItems"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Food Items</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Enter food items, separated by commas (e.g., 'grilled chicken breast, brown rice, broccoli')" 
                      className="min-h-[80px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    List all the foods you've eaten in this meal.
                  </FormDescription>
                  <FormMessage />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={analyzeFood}
                    disabled={isAnalyzing}
                    className="mt-2"
                  >
                    {isAnalyzing ? (
                      <>
                        <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-orange-500 border-t-transparent"></span>
                        Analyzing...
                      </>
                    ) : (
                      "Auto-fill Nutrition Info"
                    )}
                  </Button>
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="calories"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Calories (kcal)</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="protein"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Protein (g)</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="carbs"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Carbs (g)</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="fat"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Fat (g)</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="fiber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Fiber (g)</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="water"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Water (ml)</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="healthScore"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Health Score (1-10)</FormLabel>
                  <FormControl>
                    <div className="flex items-center space-x-2">
                      <Input 
                        type="number" 
                        min={1} 
                        max={10} 
                        {...field} 
                        disabled 
                        className="w-20 bg-muted"
                      />
                      <div className="text-sm text-muted-foreground">
                        (Automatically calculated)
                      </div>
                    </div>
                  </FormControl>
                  <FormDescription>
                    The health score is calculated automatically based on nutritional content
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Add any notes about this meal (optional)"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="flex gap-2 justify-end">
              {onCancel && (
                <Button type="button" variant="outline" onClick={onCancel}>
                  Cancel
                </Button>
              )}
              <Button 
                type="submit" 
                className="bg-gradient-to-r from-orange-500 to-orange-400 hover:from-orange-600 hover:to-orange-500"
                disabled={saveMutation.isPending}
              >
                {saveMutation.isPending ? "Saving..." : "Log Meal"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}