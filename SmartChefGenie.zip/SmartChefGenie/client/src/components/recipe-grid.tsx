import { Skeleton } from "./ui/skeleton";
import { Button } from "./ui/button";
import RecipeCard from "./recipe-card";
import { SaladIcon } from "./ui/icons";
import { type Recipe } from "@shared/schema";
import { useState } from 'react';
import { useToast } from "@/hooks/use-toast";

interface RecipeGridProps {
  recipes: Recipe[];
  isGenerating: boolean;
  firstLoad: boolean;
  onViewRecipe: (recipe: Recipe) => void;
  scrollToTop: () => void;
}

export default function RecipeGrid({
  recipes,
  isGenerating,
  firstLoad,
  onViewRecipe,
  scrollToTop,
}: RecipeGridProps) {
  const [savedRecipes, setSavedRecipes] = useState<Recipe[]>([]);
  const { toast } = useToast();

  const handleSaveRecipe = async (recipe: Recipe) => {
    try {
      const response = await fetch('/api/recipes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(recipe),
      });
      
      if (!response.ok) {
        throw new Error('Failed to save recipe');
      }
      
      setSavedRecipes([...savedRecipes, recipe]);
      toast({
        title: "Recipe saved!",
        description: "You can find this recipe in your saved recipes",
        variant: "default",
      });
    } catch (error) {
      console.error('Error saving recipe:', error);
      toast({
        title: "Could not save recipe",
        description: "Please try again later",
        variant: "destructive",
      });
    }
  };

  if (isGenerating) {
    return (
      <div className="mb-8">
        <div className="text-center mb-6">
          <div className="inline-flex items-center px-4 py-2 bg-primary-50 rounded-full text-primary-700 text-sm">
            <svg
              className="animate-spin -ml-1 mr-3 h-4 w-4 text-primary-600"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              ></circle>
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
              ></path>
            </svg>
            Hold on now, let me cook
          </div>
        </div>

        {/* Skeleton loaders for recipe cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((i) => (
            <div key={i} className="bg-white rounded-xl shadow-md overflow-hidden">
              <Skeleton className="h-48 w-full" />
              <div className="p-5 space-y-3">
                <Skeleton className="h-7 w-3/4 rounded" />
                <div className="flex items-center space-x-2">
                  <Skeleton className="h-5 w-16 rounded" />
                  <Skeleton className="h-5 w-16 rounded" />
                </div>
                <div className="space-y-2">
                  <Skeleton className="h-4 w-full rounded" />
                  <Skeleton className="h-4 w-5/6 rounded" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (recipes.length === 0 && !firstLoad) {
    return (
      <div className="text-center py-12 px-4">
        <div className="inline-block p-4 rounded-full bg-primary-50 text-primary-500 mb-4">
          <SaladIcon size={32} />
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">No recipes generated yet</h3>
        <p className="text-gray-500 max-w-md mx-auto mb-6">
          Add some ingredients and hit generate to see what Chef AI can cook up for you!
        </p>
        <Button
          type="button"
          onClick={scrollToTop}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
        >
          Add Ingredients
        </Button>
      </div>
    );
  }

  if (firstLoad && recipes.length === 0) {
    return null;
  }

  return (
    <div className="space-y-8">
      <h2 className="text-xl md:text-2xl font-display font-bold mb-4">
        Recipe Suggestions{" "}
        <span className="text-sm font-normal font-sans text-gray-500">
          based on your ingredients
        </span>
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {recipes.map((recipe, index) => (
          <RecipeCard
            key={index}
            recipe={recipe}
            onViewRecipe={() => onViewRecipe(recipe)}
            onSaveRecipe={() => handleSaveRecipe(recipe)}
          />
        ))}
      </div>
    </div>
  );
}