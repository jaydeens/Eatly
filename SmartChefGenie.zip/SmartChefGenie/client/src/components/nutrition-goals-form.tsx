import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { NutritionGoal } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Form validation schema based on nutritionGoals schema
const formSchema = z.object({
  caloriesTarget: z.coerce.number().min(500, "Value too low").max(5000, "Value too high").optional(),
  proteinTarget: z.coerce.number().min(10, "Value too low").max(300, "Value too high").optional(),
  carbsTarget: z.coerce.number().min(50, "Value too low").max(500, "Value too high").optional(),
  fatTarget: z.coerce.number().min(10, "Value too low").max(200, "Value too high").optional(),
  fiberTarget: z.coerce.number().min(5, "Value too low").max(100, "Value too high").optional(),
  waterTarget: z.coerce.number().min(500, "Value too low").max(5000, "Value too high").optional(),
  healthScoreTarget: z.coerce.number().min(1, "Minimum value is 1").max(10, "Maximum value is 10").optional(),
});

export default function NutritionGoalsForm() {
  const [isEditing, setIsEditing] = useState(false);
  
  // Fetch current nutrition goals
  const { data: goals, isLoading } = useQuery<NutritionGoal>({
    queryKey: ['/api/nutrition/goals'],
    refetchOnWindowFocus: false,
  });
  
  // Define the form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      caloriesTarget: goals?.caloriesTarget || 2000,
      proteinTarget: goals?.proteinTarget || 70,
      carbsTarget: goals?.carbsTarget || 250,
      fatTarget: goals?.fatTarget || 70,
      fiberTarget: goals?.fiberTarget || 25,
      waterTarget: goals?.waterTarget || 2000,
      healthScoreTarget: goals?.healthScoreTarget || 8,
    },
  });
  
  // Mutation for saving goals
  const saveMutation = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      const response = await apiRequest({
        method: "POST", 
        url: "/api/nutrition/goals", 
        data: values
      });
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/nutrition/goals'] });
      toast({
        title: "Success!",
        description: "Your nutrition goals have been saved.",
      });
      setIsEditing(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to save goals",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update form when goals are loaded using useEffect to prevent infinite re-renders
  useEffect(() => {
    if (goals && !isEditing) {
      form.reset({
        caloriesTarget: goals.caloriesTarget || 2000,
        proteinTarget: goals.proteinTarget || 70,
        carbsTarget: goals.carbsTarget || 250,
        fatTarget: goals.fatTarget || 70,
        fiberTarget: goals.fiberTarget || 25,
        waterTarget: goals.waterTarget || 2000,
        healthScoreTarget: goals.healthScoreTarget || 8,
      });
    }
  }, [goals, isEditing, form]);
  
  function onSubmit(values: z.infer<typeof formSchema>) {
    saveMutation.mutate(values);
  }
  
  function handleCancel() {
    form.reset();
    setIsEditing(false);
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Nutrition Goals</CardTitle>
        <CardDescription>Set your monthly nutritional targets</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center py-4">
            <div className="w-8 h-8 rounded-full border-4 border-orange-500 border-t-transparent animate-spin"></div>
          </div>
        ) : (
          <>
            {!isEditing ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Monthly Calories</p>
                    <p className="text-lg font-semibold">{goals?.caloriesTarget || 2000} kcal</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Protein</p>
                    <p className="text-lg font-semibold">{goals?.proteinTarget || 70} g</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Carbohydrates</p>
                    <p className="text-lg font-semibold">{goals?.carbsTarget || 250} g</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Fat</p>
                    <p className="text-lg font-semibold">{goals?.fatTarget || 70} g</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Fiber</p>
                    <p className="text-lg font-semibold">{goals?.fiberTarget || 25} g</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Water</p>
                    <p className="text-lg font-semibold">{goals?.waterTarget || 2000} ml</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Target Health Score</p>
                    <p className="text-lg font-semibold">{goals?.healthScoreTarget || 8}/10</p>
                  </div>
                </div>
                <Button
                  onClick={() => setIsEditing(true)} 
                  className="w-full mt-4 bg-gradient-to-r from-orange-500 to-orange-400 hover:from-orange-600 hover:to-orange-500"
                >
                  Edit Goals
                </Button>
              </div>
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="caloriesTarget"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Monthly Calories (kcal)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormDescription>Target monthly calorie intake</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="proteinTarget"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Protein (g)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormDescription>Monthly protein goal</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="carbsTarget"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Carbohydrates (g)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormDescription>Monthly carbs goal</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="fatTarget"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Fat (g)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormDescription>Monthly fat goal</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="fiberTarget"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Fiber (g)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormDescription>Monthly fiber goal</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="waterTarget"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Water (ml)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormDescription>Monthly water goal</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="healthScoreTarget"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Health Score (1-10)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min={1}
                              max={10}
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>Target health score</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="flex gap-2 justify-end">
                    <Button type="button" variant="outline" onClick={handleCancel}>
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      className="bg-gradient-to-r from-orange-500 to-orange-400 hover:from-orange-600 hover:to-orange-500"
                      disabled={saveMutation.isPending}
                    >
                      {saveMutation.isPending ? "Saving..." : "Save Goals"}
                    </Button>
                  </div>
                </form>
              </Form>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}