import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Separator } from './ui/separator';
import { Textarea } from './ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Recipe } from '@shared/schema';
import { ChatMessage } from '@shared/schema';
import { useCoachNickname } from '@/hooks/use-coach-nickname';
import {
  XIcon,
  MicIcon, 
  MicOffIcon,
  CheckIcon,
  ArrowLeftIcon,
  ArrowRightIcon,
  VolumeIcon,
  Volume2Icon,
  VolumeXIcon, 
  LoaderIcon,
  PlayIcon,
  PauseIcon,
  SaveIcon,
} from './ui/icons';

interface CookingModeProps {
  recipe: Recipe;
  onClose: () => void;
}

export default function CookingMode({ recipe, onClose }: CookingModeProps) {
  const { toast } = useToast();
  const { nickname } = useCoachNickname();
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'system', content: `You are a helpful cooking assistant helping the user cook ${recipe.title}. Be concise in your responses. Never use asterisks (*) for emphasis - use direct formatting.` },
    { role: 'assistant', content: `I'm your ${nickname}! Let's start making ${recipe.title}. I'll guide you through each step. Say "ready" when you're prepared to begin, or ask me any questions about the recipe!

Pro tip: When you finish cooking, you can tell me to "save this recipe to my nutrition log" right here in our chat!` }
  ]);
  const [userMessage, setUserMessage] = useState<string>('');
  const [isAiTyping, setIsAiTyping] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [speaking, setSpeaking] = useState<boolean>(false);
  const [voiceVolume, setVoiceVolume] = useState<number>(80);
  const [isRecipeComplete, setIsRecipeComplete] = useState<boolean>(false);
  const [isLoggingComplete, setIsLoggingComplete] = useState<boolean>(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const speechRecognition = useRef<any>(null);
  const speechSynthesis = useRef<SpeechSynthesis | null>(typeof window !== 'undefined' ? window.speechSynthesis : null);
  const currentUtterance = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    // Scroll to bottom when messages change
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Set up speech recognition if available
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // @ts-ignore
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        speechRecognition.current = new SpeechRecognition();
        speechRecognition.current.continuous = true;
        speechRecognition.current.interimResults = false;
        
        speechRecognition.current.onresult = (event: any) => {
          const transcript = event.results[event.results.length - 1][0].transcript;
          setUserMessage((prev) => prev + ' ' + transcript.trim());
        };
        
        speechRecognition.current.onerror = (event: any) => {
          console.error('Speech recognition error', event.error);
          setIsListening(false);
          toast({
            title: 'Microphone Error',
            description: `Could not access the microphone: ${event.error}`,
            variant: 'destructive',
          });
        };
      }
    }

    return () => {
      if (speechRecognition.current) {
        speechRecognition.current.stop();
      }
      if (speechSynthesis.current && currentUtterance.current) {
        speechSynthesis.current.cancel();
      }
    };
  }, [toast]);

  const toggleListening = () => {
    if (!speechRecognition.current) {
      toast({
        title: 'Voice Input Not Supported',
        description: 'Your browser does not support voice input. Try using Chrome or Edge.',
        variant: 'destructive',
      });
      return;
    }
    
    if (isListening) {
      speechRecognition.current.stop();
      setIsListening(false);
    } else {
      speechRecognition.current.start();
      setIsListening(true);
      toast({
        title: 'Voice Input Active',
        description: 'Speak now - your voice will be transcribed to text.',
      });
    }
  };

  const handleSendMessage = async () => {
    if (!userMessage.trim() || isAiTyping) return;
    
    // Temporarily stop listening while AI is responding
    if (isListening && speechRecognition.current) {
      speechRecognition.current.stop();
      setIsListening(false);
    }
    
    const newMessage: ChatMessage = { role: 'user', content: userMessage };
    setMessages((prev) => [...prev, newMessage]);
    setUserMessage('');
    setIsAiTyping(true);
    
    // Check for explicit save requests
    const saveKeywords = ['save', 'log', 'record', 'add to nutrition', 'track'];
    const recipeKeywords = ['recipe', 'meal', 'food', 'dish', 'this'];
    const isSaveRequest = saveKeywords.some(keyword => 
      userMessage.toLowerCase().includes(keyword) &&
      recipeKeywords.some(recipeWord => userMessage.toLowerCase().includes(recipeWord))
    );
    
    try {
      // The apiRequest function already returns JSON data
      const data = await apiRequest({
        method: 'POST', 
        url: '/api/chat/cooking', 
        data: {
          messages: [...messages, newMessage],
          recipe: recipe.title,
          recipeId: recipe.id,
          action: isSaveRequest ? 'save_recipe' : undefined
        }
      });
      
      // Add AI's response to the chat
      const assistantMessage: ChatMessage = { role: 'assistant', content: data.message };
      setMessages((prev) => [...prev, assistantMessage]);
      
      // If recipe was saved through the chat
      if (data.recipeSaved) {
        toast({
          title: 'Recipe Saved!',
          description: `${recipe.title} has been added to your nutrition log.`,
        });
        
        // Close cooking mode after delay if this was an explicit save request
        if (isSaveRequest) {
          setTimeout(() => {
            onClose();
          }, 3000);
        }
      }
      
      // Speak the response if speaking is enabled
      if (speaking) {
        speakText(data.message);
      }
      
    } catch (error) {
      console.error('Error in chat:', error);
      
      // Don't show error toast - provide contextual response instead
      
      // Add a context-aware fallback message based on user's last message
      let fallbackContent = 'I understand what you mean. Please continue following the recipe steps and feel free to ask more questions if needed.';
      
      // Check if user was trying to save the recipe
      if (isSaveRequest) {
        fallbackContent = `I'd be happy to save this recipe for you! Just click the "Done" button at the bottom of the screen to add it to your nutrition log.`;
      }
      // Check if it's a question about a recipe step
      else if (userMessage.toLowerCase().includes('step') || userMessage.toLowerCase().includes('how do i')) {
        fallbackContent = `For this step, just follow the instructions displayed on screen. Let me know if you need any clarification!`;
      }
      // Check if it's a "ready" message
      else if (userMessage.toLowerCase().includes('ready')) {
        fallbackContent = `Great! Let's cook ${recipe.title} together. Follow the instructions on the left, and use the Next button to move through the steps. I'm here to help along the way!`;
      }
      
      const errorMessage: ChatMessage = {
        role: 'assistant',
        content: fallbackContent
      };
      setMessages((prev) => [...prev, errorMessage]);
      
      // Speak the fallback response if speaking is enabled
      if (speaking) {
        speakText(fallbackContent);
      }
    } finally {
      setIsAiTyping(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const goToNextStep = () => {
    if (currentStep < recipe.instructions.length - 1) {
      setCurrentStep(currentStep + 1);
      
      const newMessage: ChatMessage = {
        role: 'user',
        content: `Let's move to the next step: "${recipe.instructions[currentStep + 1]}"`
      };
      
      setMessages((prev) => [...prev, newMessage]);
      
      // Ask AI for guidance on the next step
      setIsAiTyping(true);
      apiRequest({
        method: 'POST',
        url: '/api/chat/cooking',
        data: {
          messages: [...messages, newMessage],
          recipe: recipe.title,
          recipeId: recipe.id,
        }
      })
        .then((data) => {
          const completionMessage: ChatMessage = {
            role: 'assistant',
            content: data.message
          };
          setMessages((prev) => [...prev, completionMessage]);
          
          if (speaking) {
            speakText(data.message);
          }
        })
        .catch((error) => {
          console.error('Error getting next step guidance:', error);
          
          // Suppress the error toast and just add a fallback message
          // for a better user experience when navigating steps
          
          // Add a fallback message to allow the conversation to continue
          const fallbackMessage: ChatMessage = {
            role: 'assistant',
            content: `Let's continue with step ${currentStep + 1}: "${recipe.instructions[currentStep + 1]}"\n\nFeel free to ask me if you have any questions about this step!`
          };
          setMessages((prev) => [...prev, fallbackMessage]);
          
          if (speaking) {
            speakText(fallbackMessage.content);
          }
        })
        .finally(() => {
          setIsAiTyping(false);
        });
    } else {
      // Recipe is complete
      setIsRecipeComplete(true);
      
      // On mobile, switch to chat tab when recipe is complete
      if (isMobile) {
        setActiveTab('chat');
      }
      
      const newMessage: ChatMessage = {
        role: 'assistant',
        content: `Congratulations! You've completed all steps for ${recipe.title}. How did it turn out? 

You can either:
1. Click the "Done" button to record this recipe in your nutrition log, or
2. Just tell me to "save this recipe to my nutrition log" right here in our chat!`
      };
      
      setMessages((prev) => [...prev, newMessage]);
      
      if (speaking) {
        speakText(newMessage.content);
      }
    }
  };

  const goToPreviousStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const speakText = useCallback((text: string) => {
    if (!speechSynthesis.current) return;
    
    // Cancel any current speaking
    speechSynthesis.current.cancel();
    
    // Create a new utterance
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Adjust volume (0 to 1)
    utterance.volume = voiceVolume / 100;
    
    // Try to use a natural sounding voice if available
    const voices = speechSynthesis.current.getVoices();
    const preferredVoice = voices.find(voice => 
      voice.name.includes('Female') || 
      voice.name.includes('Natural') || 
      voice.name.includes('Samantha')
    );
    
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }
    
    // Store the utterance reference so we can cancel it if needed
    currentUtterance.current = utterance;
    
    // Start speaking
    speechSynthesis.current.speak(utterance);
  }, [voiceVolume]);

  const toggleSpeaking = () => {
    if (speaking) {
      // Stop speaking
      if (speechSynthesis.current) {
        speechSynthesis.current.cancel();
      }
      setSpeaking(false);
    } else {
      // Start speaking - speak the last assistant message
      const lastAssistantMessage = [...messages].reverse().find(msg => msg.role === 'assistant');
      if (lastAssistantMessage) {
        speakText(lastAssistantMessage.content);
      }
      setSpeaking(true);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setVoiceVolume(parseInt(e.target.value));
  };

  const handleCompleteRecipe = async () => {
    setIsLoggingComplete(true);
    
    try {
      // First, make sure the recipe is saved to the database
      let savedRecipe = recipe;
      
      // Only attempt to save the recipe if it's not already saved
      if (!recipe.id || recipe.id <= 0) {
        console.log('Saving recipe first before logging to nutrition...');
        const saveResponse = await fetch('/api/recipes', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(recipe)
        });
        
        if (!saveResponse.ok) {
          throw new Error('Could not save recipe before logging to nutrition');
        }
        
        savedRecipe = await saveResponse.json();
        console.log('Recipe saved successfully with ID:', savedRecipe.id);
      }
      
      // Now log the saved recipe to nutrition
      const data = await apiRequest({
        method: 'POST',
        url: '/api/nutrition/log',
        data: {
          recipeId: savedRecipe.id,
          date: new Date().toISOString(),
          servings: savedRecipe.servings
        }
      });
      
      toast({
        title: 'Recipe Completed!',
        description: `${savedRecipe.title} has been added to your nutrition log.`,
      });
      
      // Close the cooking mode after a short delay
      setTimeout(() => {
        onClose();
      }, 2000);
      
    } catch (error) {
      console.error('Error logging completed recipe:', error);
      toast({
        title: 'Error Saving Recipe',
        description: 'Could not save your completed recipe to your nutrition log.',
        variant: 'destructive',
      });
      setIsLoggingComplete(false);
    }
  };

  const [activeTab, setActiveTab] = useState<'instructions' | 'chat'>('instructions');
  const [isMobile, setIsMobile] = useState<boolean>(false);
  
  // Check if we're on a mobile device on component mount and window resize
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 640);
    };
    
    // Check on mount
    checkIfMobile();
    
    // Add event listener for window resize
    window.addEventListener('resize', checkIfMobile);
    
    // Cleanup the event listener on component unmount
    return () => {
      window.removeEventListener('resize', checkIfMobile);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm flex flex-col">
      {/* Header with close button and title */}
      <div className="p-2 sm:p-4 flex items-center justify-between border-b">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8 sm:h-10 sm:w-10">
            <XIcon className="h-4 w-4 sm:h-5 sm:w-5" />
          </Button>
          <h2 className="text-base sm:text-xl font-semibold truncate">
            {recipe.title}
          </h2>
        </div>
        
        {/* Voice control buttons - compact for mobile */}
        <div className="flex items-center gap-1 sm:gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex items-center gap-1 h-8 text-xs sm:text-sm"
            onClick={toggleSpeaking}
          >
            {speaking ? (
              <>
                <PauseIcon className="h-3 w-3 sm:h-4 sm:w-4" />
                <span className="hidden sm:inline">Mute</span>
              </>
            ) : (
              <>
                <PlayIcon className="h-3 w-3 sm:h-4 sm:w-4" />
                <span className="hidden sm:inline">Speak</span>
              </>
            )}
          </Button>
          
          {speaking && (
            <div className="hidden sm:flex items-center gap-1">
              <VolumeXIcon className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
              <input
                type="range"
                min="0"
                max="100"
                value={voiceVolume}
                onChange={handleVolumeChange}
                className="w-16 sm:w-24"
              />
              <Volume2Icon className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </div>
          )}
        </div>
      </div>
      
      {/* Mobile tab navigation */}
      <div className="sm:hidden flex border-b">
        <button
          className={`flex-1 py-2 text-center font-medium text-sm ${
            activeTab === 'instructions' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'
          }`}
          onClick={() => setActiveTab('instructions')}
        >
          Instructions
        </button>
        <button
          className={`flex-1 py-2 text-center font-medium text-sm ${
            activeTab === 'chat' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'
          }`}
          onClick={() => setActiveTab('chat')}
        >
          Cook with your {nickname}
        </button>
      </div>
      
      {/* Main content area - responsive layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* Recipe instructions panel - visible on desktop or when selected on mobile */}
        <div className={`
          sm:w-1/3 sm:border-r p-3 sm:p-4 flex flex-col overflow-hidden
          ${(activeTab === 'instructions' || !isMobile) ? 'flex' : 'hidden'}
          ${activeTab === 'instructions' ? 'w-full' : ''}
        `}>
          <div className="mb-3 sm:mb-4">
            <h3 className="text-base sm:text-lg font-medium">Instructions</h3>
            <p className="text-xs sm:text-sm text-muted-foreground">
              Step {currentStep + 1} of {recipe.instructions.length}
            </p>
            <Progress 
              value={((currentStep + 1) / recipe.instructions.length) * 100} 
              className="h-2 mt-2"
            />
          </div>
          
          <div className="flex-1 overflow-y-auto">
            {recipe.instructions.map((step, index) => (
              <Card 
                key={index} 
                className={`p-2 sm:p-3 mb-2 sm:mb-3 border ${index === currentStep ? 'border-primary bg-primary/5' : 'border-border'}`}
              >
                <div className="flex items-start gap-2">
                  <div className={`flex items-center justify-center rounded-full h-5 w-5 sm:h-6 sm:w-6 text-xs font-medium ${
                    index < currentStep 
                      ? 'bg-green-500 text-white' 
                      : index === currentStep 
                      ? 'bg-primary text-white' 
                      : 'bg-muted text-muted-foreground'
                  }`}>
                    {index < currentStep ? <CheckIcon className="h-3 w-3" /> : index + 1}
                  </div>
                  <p className={`text-sm sm:text-base ${index < currentStep ? 'text-muted-foreground line-through' : ''}`}>{step}</p>
                </div>
              </Card>
            ))}
          </div>
          
          <div className="mt-3 sm:mt-4 flex items-center justify-between">
            <Button
              variant="outline"
              onClick={goToPreviousStep}
              disabled={currentStep === 0}
              className="flex items-center gap-1 text-xs sm:text-sm h-8 sm:h-10"
            >
              <ArrowLeftIcon className="h-3 w-3 sm:h-4 sm:w-4" />
              <span className="hidden xs:inline">Previous</span>
            </Button>
            
            {isRecipeComplete ? (
              <Button
                onClick={handleCompleteRecipe}
                disabled={isLoggingComplete}
                className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-1 text-xs sm:text-sm h-8 sm:h-10 min-w-[80px]"
              >
                {isLoggingComplete ? (
                  <>
                    <LoaderIcon className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <SaveIcon className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span>Done</span>
                  </>
                )}
              </Button>
            ) : (
              <Button
                variant="default"
                onClick={goToNextStep}
                className="flex items-center gap-1 text-xs sm:text-sm h-8 sm:h-10 min-w-[80px]"
              >
                <span className="inline xs:inline">Next</span>
                <ArrowRightIcon className="h-3 w-3 sm:h-4 sm:w-4" />
              </Button>
            )}
          </div>
        </div>
        
        {/* Chat panel - visible on desktop or when selected on mobile */}
        <div className={`
          flex-1 flex flex-col overflow-hidden
          ${(activeTab === 'chat' || !isMobile) ? 'flex' : 'hidden'}
          ${activeTab === 'chat' ? 'w-full' : ''}
        `}>
          <div className="flex-1 p-3 sm:p-4 overflow-y-auto">
            <div className="space-y-3 sm:space-y-4">
              {messages.map((message, i) => (
                message.role !== 'system' && (
                  <div 
                    key={i} 
                    className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div 
                      className={`max-w-[90%] sm:max-w-[80%] rounded-lg p-2 sm:p-3 ${
                        message.role === 'user' 
                          ? 'bg-primary text-primary-foreground' 
                          : 'bg-muted'
                      }`}
                    >
                      <p className="whitespace-pre-wrap text-sm sm:text-base">{message.content}</p>
                    </div>
                  </div>
                )
              ))}
              
              {isAiTyping && (
                <div className="flex justify-start">
                  <div className="max-w-[90%] sm:max-w-[80%] rounded-lg p-2 sm:p-3 bg-muted">
                    <div className="flex items-center gap-2">
                      <LoaderIcon className="h-3 w-3 sm:h-4 sm:w-4" />
                      <p className="text-sm sm:text-base">Hold on now, let me cook</p>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
          </div>
          
          <Separator />
          
          {isRecipeComplete && (
            <div className="px-3 sm:px-4 py-2 bg-primary/5 border-t border-b border-primary/20">
              <p className="text-xs sm:text-sm text-center text-primary font-medium">
                <SaveIcon className="inline-block w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                You can save this recipe by typing "Save recipe" in the chat!
              </p>
            </div>
          )}
          
          <div className="p-2 sm:p-4">
            <div className="flex items-start gap-1 sm:gap-2">
              <Button
                variant="outline" 
                size="icon"
                className={`h-8 w-8 sm:h-10 sm:w-10 ${isListening ? 'bg-red-100 text-red-600 animate-pulse' : ''}`}
                onClick={toggleListening}
              >
                {isListening ? <MicOffIcon className="h-4 w-4 sm:h-5 sm:w-5" /> : <MicIcon className="h-4 w-4 sm:h-5 sm:w-5" />}
              </Button>
              
              <Textarea
                value={userMessage}
                onChange={(e) => setUserMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={isRecipeComplete 
                  ? `Try saying "Save this recipe to my nutrition log"` 
                  : `Ask your ${nickname} about the recipe or say 'ready'...`}
                className="flex-1 resize-none text-sm sm:text-base"
                rows={1}
              />
              
              <Button 
                onClick={handleSendMessage} 
                disabled={isAiTyping || !userMessage.trim()}
                className="h-8 sm:h-10 text-xs sm:text-sm"
              >
                Send
              </Button>
            </div>
            
            {isListening && (
              <p className="text-xs sm:text-sm text-muted-foreground mt-1 sm:mt-2">
                Listening... Tap mic to stop.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}