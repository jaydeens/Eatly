import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "../ui/button";
import { ChefHatIcon, MenuIcon, PlusIcon, SearchIcon, BookmarkIcon, UserIcon, MoonIcon, SunIcon, LeafIcon, MessageCircleIcon, ActivityIcon } from "../ui/icons";
import { Award as AwardIcon } from "lucide-react";
import MobileNav from "../mobile-nav";
import UserMenu from "../user-menu";
import { cn } from "@/lib/utils";
import { useTheme } from "@/providers/theme-provider";

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const [mobileMenu, setMobileMenu] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();

  // Add header shadow effect on scroll
  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [scrolled]);

  // Close mobile menu when location changes
  useEffect(() => {
    setMobileMenu(false);
  }, [location]);

  const isActive = (path: string) => location === path;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className={cn(
        "bg-card sticky top-0 z-50 transition-shadow duration-300",
        scrolled ? "shadow-md" : "shadow-sm"
      )}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-3">
            <Link href="/">
              <div className="flex items-center gap-2.5 group cursor-pointer">
                <div className="flex items-center justify-center w-10 h-10 bg-gradient-to-br from-orange-400 to-orange-500 rounded-lg shadow-sm group-hover:shadow transform transition-transform group-hover:scale-105">
                  <ChefHatIcon className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-xl font-bold">
                  <span className="text-foreground">Eat</span><span className="text-orange-500">ly</span>
                </h1>
              </div>
            </Link>
            
            <nav className="hidden md:flex items-center space-x-1">
              <NavLink 
                href="/" 
                label="Home" 
                icon={<HomeIcon className="h-4 w-4" />}
                isActive={isActive("/")} 
              />
              <NavLink 
                href="/saved-recipes" 
                label="Saved Recipes" 
                icon={<BookmarkIcon className="h-4 w-4" />}
                isActive={isActive("/saved-recipes")} 
              />
              <NavLink 
                href="/health" 
                label="Weight Management" 
                icon={<ActivityIcon className="h-4 w-4" />}
                isActive={isActive("/health")} 
              />
              <NavLink 
                href="/achievements" 
                label="Achievements" 
                icon={<AwardIcon className="h-4 w-4" />}
                isActive={isActive("/achievements")} 
              />
              <Link href="/chat">
                <div className={cn(
                  "flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer",
                  isActive("/chat") 
                    ? "text-white bg-gradient-to-r from-orange-600 to-orange-400" 
                    : "text-foreground hover:text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-950/30"
                )}>
                  <MessageCircleIcon className="h-4 w-4 mr-2" />
                  Personal Coach (PC)
                </div>
              </Link>
            </nav>

            <div className="flex items-center gap-3">

              
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="h-9 w-9 rounded-full hover:bg-orange-50 dark:hover:bg-orange-950/30 text-muted-foreground hover:text-orange-600 dark:hover:text-orange-400 transition"
              >
                {theme === 'dark' ? (
                  <SunIcon className="h-[18px] w-[18px]" />
                ) : (
                  <MoonIcon className="h-[18px] w-[18px]" />
                )}
              </Button>
              
              {/* Create button removed as requested */}
              
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden h-9 w-9 rounded-full hover:bg-orange-50 dark:hover:bg-orange-950/30 text-muted-foreground hover:text-orange-600 dark:hover:text-orange-400 transition"
                onClick={() => setMobileMenu(!mobileMenu)}
              >
                <MenuIcon className="h-[18px] w-[18px]" />
              </Button>
              
              <UserMenu />
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu Dropdown */}
      {mobileMenu && (
        <div className="md:hidden bg-card border-b border-border shadow-sm animate-in slide-in-from-top duration-300">
          <div className="p-3 space-y-1.5">
            <MobileNavLink 
              href="/" 
              label="Home" 
              icon={<HomeIcon className="h-5 w-5" />} 
              isActive={isActive("/")}
            />
            <MobileNavLink 
              href="/saved-recipes" 
              label="Saved Recipes" 
              icon={<BookmarkIcon className="h-5 w-5" />} 
              isActive={isActive("/saved-recipes")}
            />
            <MobileNavLink 
              href="/health" 
              label="Weight Management" 
              icon={<ActivityIcon className="h-5 w-5" />} 
              isActive={isActive("/health")}
            />
            <MobileNavLink 
              href="/achievements" 
              label="Achievements" 
              icon={<AwardIcon className="h-5 w-5" />}
              isActive={isActive("/achievements")}
            />
            <Link href="/chat">
              <div className={cn(
                "flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-colors cursor-pointer",
                isActive("/chat") 
                  ? "text-white bg-gradient-to-r from-orange-600 to-orange-400" 
                  : "text-foreground hover:text-orange-600 hover:bg-muted dark:hover:bg-orange-950/30"
              )}>
                <MessageCircleIcon className="h-5 w-5 mr-3" />
                Personal Coach (PC)
              </div>
            </Link>
            <MobileNavLink 
              href="/account" 
              label="Account" 
              icon={<UserIcon className="h-5 w-5" />}
              isActive={isActive("/account")}
            />
            
            <div className="flex items-center px-3 py-2.5 rounded-md text-sm font-medium cursor-pointer"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            >
              {theme === 'dark' ? (
                <>
                  <SunIcon className="h-5 w-5 mr-3" />
                  <span>Light Mode</span>
                </>
              ) : (
                <>
                  <MoonIcon className="h-5 w-5 mr-3" />
                  <span>Dark Mode</span>
                </>
              )}
            </div>
          
            {/* Create Recipe button removed as requested */}
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Mobile Bottom Navigation */}
      <MobileNav />
    </div>
  );
}

// Desktop navigation link
function NavLink({ href, label, icon, isActive }: { href: string; label: string; icon: React.ReactNode; isActive: boolean }) {
  return (
    <Link href={href}>
      <div className={cn(
        "flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer",
        isActive 
          ? "text-orange-600 bg-orange-50 dark:bg-orange-950/40 dark:text-orange-400" 
          : "text-foreground hover:text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-950/30"
      )}>
        {icon && <span className="mr-2">{icon}</span>}
        {label}
      </div>
    </Link>
  );
}

// Mobile navigation link
function MobileNavLink({ href, label, icon, isActive }: { href: string; label: string; icon: React.ReactNode; isActive: boolean }) {
  return (
    <Link href={href}>
      <div className={cn(
        "flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-colors cursor-pointer",
        isActive 
          ? "text-orange-600 bg-orange-50 dark:bg-orange-950/40 dark:text-orange-400" 
          : "text-foreground hover:text-orange-600 hover:bg-muted dark:hover:bg-orange-950/30"
      )}>
        {icon && <span className="mr-3">{icon}</span>}
        {label}
      </div>
    </Link>
  );
}

// Home icon
function HomeIcon({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </svg>
  );
}

// Preferences icon
function PreferencesIcon({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </svg>
  );
}
