import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { LoginForm } from "./login-form";
import { RegisterForm } from "./register-form";
import { ChefHatIcon } from "@/components/ui/icons";

type AuthView = 'login' | 'register';

interface AuthModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialView?: AuthView;
  onSuccess?: () => void;
}

export function AuthModal({ 
  open, 
  onOpenChange, 
  initialView = 'login',
  onSuccess
}: AuthModalProps) {
  const [view, setView] = useState<AuthView>(initialView);
  
  const handleSuccess = () => {
    onOpenChange(false);
    if (onSuccess) {
      onSuccess();
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden">
        <div className="relative">
          {/* Orange gradient header */}
          <div className="bg-gradient-to-r from-orange-500 to-orange-400 p-6 flex items-center flex-col">
            <ChefHatIcon size={42} className="text-white mb-2" />
            <DialogTitle className="text-center text-2xl text-white font-bold">
              {view === 'login' ? 'Welcome back' : 'Join ChefAI'}
            </DialogTitle>
            <DialogDescription className="text-center text-orange-100 mt-1">
              {view === 'login' 
                ? 'Sign in to access your saved recipes' 
                : 'Create an account to save and personalize recipes'}
            </DialogDescription>
          </div>
        </div>
        
        <div className="p-6">
          {view === 'login' ? (
            <LoginForm
              onSuccess={handleSuccess}
              onRegisterClick={() => setView('register')}
            />
          ) : (
            <RegisterForm
              onSuccess={handleSuccess}
              onLoginClick={() => setView('login')}
            />
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}