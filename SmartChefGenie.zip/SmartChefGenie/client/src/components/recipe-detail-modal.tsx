import { useState, useRef, useEffect } from "react";
import { Button } from "./ui/button";
import { Separator } from "./ui/separator";
import { Badge } from "./ui/badge";
import { useToast } from "@/hooks/use-toast";
import CookingMode from "./cooking-mode";
import { 
  XIcon, 
  ClockIcon, 
  UsersIcon, 
  FlameIcon, 
  ChartIcon,
  CheckIcon,
  BookmarkIcon,
  LeafIcon,
  MessageCircleIcon,
  SparklesIcon,
  SaladIcon,
  SearchIcon,
  WandIcon,
  PlayIcon
} from "./ui/icons";
import { type Recipe } from "@shared/schema";
import { cn } from "@/lib/utils";

interface RecipeDetailModalProps {
  recipe: Recipe;
  onClose: () => void;
}

export default function RecipeDetailModal({ recipe, onClose }: RecipeDetailModalProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [showCookingMode, setShowCookingMode] = useState(false);
  const { toast } = useToast();
  
  // Function to determine tag colors
  const getTagColorClasses = (tag: string) => {
    switch (tag.toLowerCase()) {
      case "vegetarian":
        return "bg-green-100 text-green-800 border border-green-200";
      case "vegan":
        return "bg-emerald-100 text-emerald-800 border border-emerald-200";
      case "gluten-free":
        return "bg-amber-100 text-amber-800 border border-amber-200";
      case "low-carb":
        return "bg-blue-100 text-blue-800 border border-blue-200";
      case "dairy-free":
        return "bg-purple-100 text-purple-800 border border-purple-200";
      case "keto":
        return "bg-indigo-100 text-indigo-800 border border-indigo-200";
      case "paleo":
        return "bg-red-100 text-red-800 border border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border border-gray-200";
    }
  };
  
  // Helper to render the health score with appropriate colors
  const renderHealthScore = (score: number) => {
    let color = "text-green-600 dark:text-green-400";
    if (score < 40) color = "text-orange-600 dark:text-orange-400";
    else if (score < 60) color = "text-yellow-600 dark:text-yellow-400";
    else if (score < 80) color = "text-emerald-600 dark:text-emerald-400";
    
    return (
      <div className="flex items-center">
        <div className={`text-2xl font-bold ${color}`}>{score}</div>
        <div className="text-gray-500 dark:text-gray-400 text-sm ml-1">/ 100</div>
      </div>
    );
  };
  
  // Nutrition bar visualization
  const renderNutritionBar = (value: number, max: number, color: string) => {
    const percentage = Math.min(100, (value / max) * 100);
    return (
      <div className="h-2 w-full bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
        <div 
          className={`h-full ${color}`} 
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    );
  };

  const [aiAnimatedText, setAiAnimatedText] = useState(false);

  // Trigger AI animation after the component mounts
  useEffect(() => {
    setTimeout(() => {
      setAiAnimatedText(true);
    }, 500);
  }, []);

  // AI-shaped dots effect - these will appear as decorative elements
  const dotPatterns = useRef(
    Array.from({ length: 8 }, () => ({
      size: 4 + Math.random() * 8,
      top: Math.random() * 100,
      left: Math.random() * 100,
      delay: Math.random() * 2,
      duration: 15 + Math.random() * 15
    }))
  );

  // If cooking mode is active, show that instead of the recipe detail
  if (showCookingMode) {
    return (
      <CookingMode 
        recipe={recipe} 
        onClose={() => setShowCookingMode(false)} 
      />
    );
  }
  
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-md">
      <div className="flex items-center justify-center min-h-screen p-4 text-center sm:p-0">
        <div className="inline-block align-bottom bg-background rounded-2xl text-left overflow-hidden shadow-2xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl w-full relative">
          {/* Background AI pattern */}
          <div className="absolute inset-0 overflow-hidden opacity-5 pointer-events-none">
            {dotPatterns.current.map((dot, i) => (
              <div 
                key={i}
                className="absolute rounded-full bg-orange-500"
                style={{
                  top: `${dot.top}%`,
                  left: `${dot.left}%`,
                  width: `${dot.size}px`,
                  height: `${dot.size}px`,
                  animation: `float-5 ${dot.duration}s ease-in-out ${dot.delay}s infinite`
                }}
              />
            ))}
          </div>
          
          {/* Close button */}
          <button
            onClick={onClose}
            type="button"
            className="absolute top-4 right-4 z-10 bg-background/80 backdrop-blur-sm rounded-full p-2 text-foreground hover:bg-muted focus:outline-none transition-colors shadow-md"
          >
            <span className="sr-only">Close</span>
            <XIcon size={20} />
          </button>

          <div>
            {/* Hero section with image */}
            <div className="relative h-80 sm:h-96 bg-muted overflow-hidden">
              {/* AI-generated badge */}
              <div className="absolute top-4 left-4 z-10">
                <div className="bg-black/50 backdrop-blur-md rounded-full px-3 py-1.5 text-white text-xs flex items-center gap-1.5 shadow-lg">
                  <div className="relative flex items-center">
                    <SparklesIcon size={12} className="text-orange-400" />
                  </div>
                  <div className="font-medium">AI-Enhanced Recipe</div>
                </div>
              </div>
              
              <img
                src={recipe.image}
                className="w-full h-full object-cover"
                alt={recipe.title}
              />
              
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/60 to-black/10 flex items-end">
                {/* Animated AI processing lines */}
                <div className={cn(
                  "absolute inset-x-0 h-px bg-gradient-to-r from-transparent via-orange-500/70 to-transparent",
                  "transition-all duration-1000 ease-in-out",
                  aiAnimatedText ? "opacity-0" : "opacity-100"
                )} style={{ top: "30%", transform: "translateY(-50%)" }}></div>
                
                <div className="p-6 sm:p-8 w-full relative">
                  {/* Title and badges */}
                  <div className="max-w-3xl">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge className="bg-orange-500/80 text-white px-2 py-1 text-xs backdrop-blur-sm">
                        <div className="flex items-center gap-1">
                          <WandIcon size={12} />
                          <span>Chef Recommended</span>
                        </div>
                      </Badge>
                      
                      {recipe.healthScore && recipe.healthScore > 70 && (
                        <Badge className="bg-green-500/80 text-white px-2 py-1 text-xs backdrop-blur-sm">
                          <div className="flex items-center gap-1">
                            <LeafIcon size={12} />
                            <span>Nutritious</span>
                          </div>
                        </Badge>
                      )}
                    </div>
                    
                    <h2 className="text-white text-3xl sm:text-4xl font-bold leading-tight">
                      {recipe.title}
                    </h2>
                    
                    <div className="flex flex-wrap gap-2 mt-4">
                      {recipe.tags.map((tag, tagIndex) => (
                        <span
                          key={tagIndex}
                          className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-white/10 text-white backdrop-blur-sm border border-white/10"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                    
                    <p className="text-white/90 mt-3 text-sm max-w-2xl leading-relaxed">
                      {recipe.description}
                    </p>
                  </div>
                  
                  {/* Recipe info badges */}
                  <div className="flex flex-wrap gap-3 mt-5">
                    {recipe.healthScore !== undefined && recipe.healthScore !== null && (
                      <div className="bg-gradient-to-r from-green-500/20 to-green-400/10 backdrop-blur-md rounded-lg px-3 py-2 text-white text-sm flex items-center border border-green-500/20">
                        <LeafIcon size={16} className="mr-2 text-green-400" />
                        <span>{recipe.healthScore}% Healthy</span>
                      </div>
                    )}
                    <div className="bg-gradient-to-r from-blue-500/20 to-blue-400/10 backdrop-blur-md rounded-lg px-3 py-2 text-white text-sm flex items-center border border-blue-500/20">
                      <ClockIcon size={16} className="mr-2 text-blue-400" />
                      <span>{recipe.time}</span>
                    </div>
                    <div className="bg-gradient-to-r from-purple-500/20 to-purple-400/10 backdrop-blur-md rounded-lg px-3 py-2 text-white text-sm flex items-center border border-purple-500/20">
                      <UsersIcon size={16} className="mr-2 text-purple-400" />
                      <span>{recipe.servings} servings</span>
                    </div>
                    <div className="bg-gradient-to-r from-orange-500/20 to-orange-400/10 backdrop-blur-md rounded-lg px-3 py-2 text-white text-sm flex items-center border border-orange-500/20">
                      <FlameIcon size={16} className="mr-2 text-orange-400" />
                      <span>{recipe.calories} kcal</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Content section */}
            <div className="p-6 sm:p-8">
              {/* Main info cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
                <div className="bg-orange-50 dark:bg-orange-950/30 rounded-lg p-4 text-center">
                  <ClockIcon className="text-orange-500 mx-auto mb-2" size={24} />
                  <div className="font-medium text-gray-900 dark:text-gray-100">{recipe.time}</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">Total Time</div>
                </div>
                
                <div className="bg-orange-50 dark:bg-orange-950/30 rounded-lg p-4 text-center">
                  <UsersIcon className="text-orange-500 mx-auto mb-2" size={24} />
                  <div className="font-medium text-gray-900 dark:text-gray-100">{recipe.servings}</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">Servings</div>
                </div>
                
                <div className="bg-orange-50 dark:bg-orange-950/30 rounded-lg p-4 text-center">
                  <FlameIcon className="text-orange-500 mx-auto mb-2" size={24} />
                  <div className="font-medium text-gray-900 dark:text-gray-100">{recipe.calories}</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">Calories</div>
                </div>
                
                <div className="bg-orange-50 dark:bg-orange-950/30 rounded-lg p-4 text-center">
                  <ChartIcon className="text-orange-500 mx-auto mb-2" size={24} />
                  <div className="font-medium text-gray-900 dark:text-gray-100 capitalize">{recipe.difficulty}</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">Difficulty</div>
                </div>
              </div>
              
              {/* Cook Now button */}
              <div className="flex justify-end mt-4 mb-6">
                <Button 
                  size="default"
                  className="relative group overflow-hidden"
                  onClick={() => setShowCookingMode(true)}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-green-600 to-green-400 group-hover:from-green-500 group-hover:to-green-300"></div>
                  <div className="relative flex items-center z-10 text-white">
                    <PlayIcon className="mr-1.5" size={18} />
                    <span>Cook Now</span>
                  </div>
                </Button>
              </div>

              {/* Main content grid */}
              <div className="grid md:grid-cols-3 gap-8">
                {/* Left sidebar */}
                <div className="md:col-span-1">
                  {/* Ingredients section */}
                  <div className="mb-8">
                    <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-gray-100 flex items-center">
                      <span className="bg-orange-100 dark:bg-orange-900/50 text-orange-700 dark:text-orange-400 rounded-full w-6 h-6 inline-flex items-center justify-center mr-2">
                        <span className="text-xs">1</span>
                      </span>
                      Ingredients
                    </h3>
                    
                    <ul className="space-y-3">
                      {recipe.ingredients.map((ingredient, i) => (
                        <li key={i} className="flex items-start">
                          <span className="h-5 w-5 mt-0.5 rounded-full bg-orange-100 dark:bg-orange-900/50 text-orange-700 dark:text-orange-400 flex items-center justify-center flex-shrink-0">
                            <CheckIcon size={12} />
                          </span>
                          <span className="ml-2 text-gray-700 dark:text-gray-300">{ingredient}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Nutrition information */}
                  <div>
                    <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-gray-100">
                      Nutrition Facts
                    </h3>
                    
                    <div className="bg-gray-50 dark:bg-gray-900/50 rounded-xl p-4 border border-gray-100 dark:border-gray-800">
                      {/* Health score */}
                      {recipe.healthScore !== undefined && recipe.healthScore !== null && (
                        <div className="mb-4 pb-4 border-b border-gray-200 dark:border-gray-700">
                          <div className="text-sm text-gray-600 dark:text-gray-400 mb-1">Health Score</div>
                          {renderHealthScore(recipe.healthScore)}
                        </div>
                      )}
                      
                      {/* Calorie information */}
                      <div className="flex justify-between text-sm mb-4 pb-4 border-b border-gray-200 dark:border-gray-700">
                        <span className="text-gray-700 dark:text-gray-300 font-medium">Calories</span>
                        <span className="font-bold text-gray-900 dark:text-gray-100">{recipe.calories} kcal</span>
                      </div>
                      
                      {/* Nutrition bars */}
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-600 dark:text-gray-400">Protein</span>
                            <span className="font-medium text-gray-900 dark:text-gray-100">{(recipe.nutrition as any)?.protein || 0}g</span>
                          </div>
                          {renderNutritionBar((recipe.nutrition as any)?.protein || 0, 50, 'bg-blue-500')}
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-600 dark:text-gray-400">Carbs</span>
                            <span className="font-medium text-gray-900 dark:text-gray-100">{(recipe.nutrition as any)?.carbs || 0}g</span>
                          </div>
                          {renderNutritionBar((recipe.nutrition as any)?.carbs || 0, 100, 'bg-orange-500')}
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-600 dark:text-gray-400">Fat</span>
                            <span className="font-medium text-gray-900 dark:text-gray-100">{(recipe.nutrition as any)?.fat || 0}g</span>
                          </div>
                          {renderNutritionBar((recipe.nutrition as any)?.fat || 0, 50, 'bg-yellow-500')}
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-600 dark:text-gray-400">Fiber</span>
                            <span className="font-medium text-gray-900 dark:text-gray-100">{(recipe.nutrition as any)?.fiber || 0}g</span>
                          </div>
                          {renderNutritionBar((recipe.nutrition as any)?.fiber || 0, 30, 'bg-green-500')}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Main content area */}
                <div className="md:col-span-2">
                  {/* Instructions section */}
                  <div className="mb-8">
                    <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-gray-100 flex items-center">
                      <span className="bg-orange-100 dark:bg-orange-900/50 text-orange-700 dark:text-orange-400 rounded-full w-6 h-6 inline-flex items-center justify-center mr-2">
                        <span className="text-xs">2</span>
                      </span>
                      Instructions
                    </h3>
                    
                    <div className="space-y-6">
                      {recipe.instructions.map((step, i) => (
                        <div 
                          key={i} 
                          className={`relative pl-10 pt-1 pb-5 border-l-2 ${
                            i === currentStep 
                              ? 'border-orange-500' 
                              : i < currentStep 
                                ? 'border-gray-300 dark:border-gray-700' 
                                : 'border-gray-200 dark:border-gray-800'
                          }`}
                        >
                          <div 
                            className={`absolute left-[-9px] top-0 flex items-center justify-center h-6 w-6 rounded-full text-xs font-medium cursor-pointer
                              ${i === currentStep 
                                ? 'bg-orange-500 text-white' 
                                : i < currentStep 
                                  ? 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300' 
                                  : 'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 border border-gray-200 dark:border-gray-700'
                              }`}
                            onClick={() => setCurrentStep(i)}
                          >
                            {i + 1}
                          </div>
                          <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-2">Step {i + 1}</h4>
                          <p className="text-gray-700 dark:text-gray-300">{step}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Chef's tips section */}
                  <div className="mt-8">
                    <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-gray-100 flex items-center">
                      <span className="bg-orange-100 dark:bg-orange-900/50 text-orange-700 dark:text-orange-400 rounded-full w-6 h-6 inline-flex items-center justify-center mr-2">
                        <span className="text-xs">3</span>
                      </span>
                      Chef's Tips
                    </h3>
                    
                    <div className="bg-gradient-to-r from-orange-50 to-orange-100 dark:from-orange-950/30 dark:to-orange-900/20 rounded-xl p-6 border border-orange-200 dark:border-orange-800/30">
                      <p className="text-gray-800 dark:text-gray-200 italic">{recipe.tips}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* AI Recipe Assistant */}
              <div className="mt-8 bg-gradient-to-r from-orange-50 to-orange-100 dark:from-orange-950/30 dark:to-orange-900/20 rounded-xl border border-orange-200 dark:border-orange-800/30 p-5 relative overflow-hidden">
                <div className="absolute -right-16 -top-16 w-32 h-32 bg-orange-200/50 dark:bg-orange-700/10 rounded-full blur-xl"></div>
                <div className="absolute right-10 bottom-10 w-24 h-24 bg-orange-300/30 dark:bg-orange-600/10 rounded-full blur-xl"></div>
                
                <div className="relative">
                  <div className="flex items-center mb-4">
                    <div className="p-2 bg-gradient-to-br from-orange-500 to-orange-400 rounded-lg shadow-md mr-3">
                      <SparklesIcon className="text-white" size={18} />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 dark:text-gray-100">AI Chef Assistant</h3>
                      <p className="text-xs text-gray-600 dark:text-gray-400">Powered by Eatly</p>
                    </div>
                    <div className="ml-auto flex items-center">
                      <span className="relative h-2 w-2 mr-2">
                        <span className="absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75 animate-ping"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                      </span>
                      <span className="text-xs text-gray-600 dark:text-gray-400">Online</span>
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <Button
                      variant="outline" 
                      className="md:col-span-1 bg-white/50 dark:bg-black/20 border-orange-200/50 dark:border-orange-800/30 hover:bg-orange-100/50 dark:hover:bg-orange-950/30 text-gray-700 dark:text-gray-300"
                      onClick={() => toast({
                        title: "Coming Soon",
                        description: "This feature is currently in development",
                        variant: "default",
                      })}
                    >
                      <div className="flex items-center gap-2">
                        <SaladIcon size={14} className="text-orange-500" />
                        <span>Substitute Ingredients</span>
                      </div>
                    </Button>
                    
                    <Button
                      variant="outline" 
                      className="md:col-span-1 bg-white/50 dark:bg-black/20 border-orange-200/50 dark:border-orange-800/30 hover:bg-orange-100/50 dark:hover:bg-orange-950/30 text-gray-700 dark:text-gray-300"
                      onClick={() => toast({
                        title: "Coming Soon",
                        description: "This feature is currently in development",
                        variant: "default",
                      })}
                    >
                      <div className="flex items-center gap-2">
                        <SearchIcon className="h-4 w-4 text-orange-500" />
                        <span>Find Similar Recipes</span>
                      </div>
                    </Button>
                  </div>
                  
                  <div className="px-4 py-3 bg-white/80 dark:bg-black/20 rounded-lg border border-orange-200/50 dark:border-orange-800/30">
                    <div className="text-sm text-gray-600 dark:text-gray-400 mb-1">
                      <span className="font-medium">AI suggestion:</span> This recipe pairs well with a fresh green salad and garlic bread. To save time, prepare the sauce ahead and refrigerate.
                    </div>
                    <Button variant="ghost" size="sm" className="text-orange-600 hover:text-orange-700 hover:bg-orange-100/50 p-0 h-auto">
                      <div className="flex items-center text-xs">
                        <MessageCircleIcon size={12} className="mr-1" />
                        <span>Ask more questions</span>
                      </div>
                    </Button>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="mt-6 pt-4 border-t border-gray-100 dark:border-gray-800 flex flex-wrap justify-between items-center gap-4">
                <div className="flex items-center">
                  <div className="mr-2 text-sm text-gray-600 dark:text-gray-400 font-medium">
                    Liked this recipe?
                  </div>
                  <div className="flex -space-x-1">
                    {[1, 2, 3].map((_, i) => (
                      <div key={i} className="h-8 w-8 rounded-full bg-gray-200 dark:bg-gray-700 border-2 border-white dark:border-gray-900 flex items-center justify-center text-gray-500 dark:text-gray-400 text-xs">
                        {String.fromCharCode(65 + i)}
                      </div>
                    ))}
                    <div className="h-8 w-8 rounded-full bg-orange-100 dark:bg-orange-900/50 border-2 border-white dark:border-gray-900 flex items-center justify-center text-orange-600 dark:text-orange-500 text-xs">
                      +28
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-3">
                  
                  <Button 
                    size="sm"
                    className="relative group overflow-hidden"
                    onClick={() => {
                      // Call API to save recipe
                      fetch('/api/recipes', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(recipe)
                      })
                      .then(res => {
                        if (res.ok) {
                          return res.json().then(data => {
                            toast({
                              title: "Recipe saved!",
                              description: "You can find this recipe in your saved recipes",
                              variant: "default",
                            });
                            return data;
                          });
                        } else {
                          throw new Error('Failed to save recipe');
                        }
                      })
                      .catch(err => {
                        console.error('Error saving recipe:', err);
                        toast({
                          title: "Could not save recipe",
                          description: "Please try again later",
                          variant: "destructive",
                        });
                      });
                    }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-orange-400 group-hover:from-orange-500 group-hover:to-orange-300"></div>
                    <div className="relative flex items-center z-10 text-white">
                      <BookmarkIcon className="mr-1.5" size={16} />
                      <span>Save Recipe</span>
                    </div>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
