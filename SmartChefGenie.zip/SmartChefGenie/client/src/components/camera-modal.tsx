import { useState, useEffect, useRef } from "react";
import { Button } from "./ui/button";
import { XIcon, CameraIcon, ChartIcon } from "./ui/icons";
import FoodAnalysisModal from "./food-analysis-modal";
import { useToast } from "../hooks/use-toast";

interface CameraModalProps {
  onClose: () => void;
  onScanComplete: (ingredients: string[]) => void;
}

export default function CameraModal({ onClose, onScanComplete }: CameraModalProps) {
  const [scanning, setScanning] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [permissionError, setPermissionError] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [scanMode, setScanMode] = useState<'ingredients' | 'analyze'>('ingredients');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const { toast } = useToast();

  // Initialize camera
  useEffect(() => {
    async function setupCamera() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment" }
        });
        
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setCameraActive(true);
          setPermissionError(false);
        }
      } catch (error) {
        console.error("Error accessing camera:", error);
        setPermissionError(true);
      }
    }
    
    setupCamera();
    
    // Cleanup function
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const captureImage = () => {
    if (!videoRef.current || !canvasRef.current) return null;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    
    if (!context) return null;
    
    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // Draw the current video frame to the canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Convert canvas to base64 image
    const imageData = canvas.toDataURL('image/jpeg');
    return imageData;
  };

  const handleStartScan = async () => {
    if (!cameraActive) return;
    
    setScanning(true);
    
    try {
      // Capture image for both modes
      const imageData = captureImage();
      if (!imageData) {
        throw new Error("Failed to capture image");
      }
      
      // For ingredients scanning mode
      if (scanMode === 'ingredients') {
        try {
          // Call the API to detect ingredients using Clarifai
          const response = await fetch('/api/ingredients/scan', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ image: imageData }),
          });
          
          const data = await response.json();
          
          if (!response.ok) {
            throw new Error(data.message || 'Failed to scan ingredients');
          }
          
          if (data.success && data.ingredients && data.ingredients.length > 0) {
            // Filter out duplicates and pass ingredients back to parent
            const uniqueIngredients = Array.from(new Set(data.ingredients)) as string[];
            onScanComplete(uniqueIngredients);
          } else {
            toast({
              variant: "destructive",
              title: "No ingredients detected",
              description: "Try a clearer image or different angle of your ingredients.",
            });
          }
        } catch (error) {
          console.error("Error scanning ingredients:", error);
          toast({
            variant: "destructive",
            title: "Ingredient scanning failed",
            description: (error as Error).message || "Failed to detect ingredients. Please try again.",
          });
        } finally {
          setScanning(false);
        }
      } 
      // For food analysis mode
      else {
        setCapturedImage(imageData);
        setIsAnalyzing(true);
        setScanning(false);
      }
    } catch (error) {
      console.error("Error capturing image:", error);
      toast({
        variant: "destructive",
        title: "Capture failed",
        description: "Failed to capture the image. Please try again.",
      });
      setScanning(false);
    }
  }

  return (
    <>
      {/* Hidden canvas for image capture */}
      <canvas ref={canvasRef} className="hidden" />
      
      {isAnalyzing && capturedImage && (
        <FoodAnalysisModal 
          imageData={capturedImage} 
          onClose={() => {
            setIsAnalyzing(false);
            setCapturedImage(null);
            onClose();
          }} 
        />
      )}
      
      {!isAnalyzing && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:p-0">
            <div className="fixed inset-0 bg-gray-500 dark:bg-gray-900 bg-opacity-75 dark:bg-opacity-90 transition-opacity"></div>
            <div className="relative inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
              <div className="absolute top-0 right-0 pt-4 pr-4">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="text-gray-400 hover:text-gray-500"
                >
                  <XIcon />
                </Button>
              </div>
              
              <div>
                <div className="mt-3 text-center sm:mt-5">
                  <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-white">
                    {permissionError ? "Camera Access Required" : scanMode === 'ingredients' ? "Scan Ingredients" : "Analyze Food"}
                  </h3>
                  
                  {/* Scan mode selection */}
                  {!permissionError && (
                    <div className="mb-4 mt-2 inline-flex rounded-md overflow-hidden border border-gray-300 dark:border-gray-600">
                      <button
                        onClick={() => setScanMode('ingredients')}
                        className={`px-3 py-1.5 text-xs font-medium transition-colors ${
                          scanMode === 'ingredients' 
                            ? 'bg-gradient-to-r from-primary-500 to-orange-400 text-white border-r border-gray-300 dark:border-gray-600' 
                            : 'bg-white dark:bg-black text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-900 border-r border-gray-300 dark:border-gray-600'
                        }`}
                      >
                        Find Ingredients
                      </button>
                      <button
                        onClick={() => setScanMode('analyze')}
                        className={`px-3 py-1.5 text-xs font-medium transition-colors ${
                          scanMode === 'analyze' 
                            ? 'bg-gradient-to-r from-primary-500 to-orange-400 text-white' 
                            : 'bg-white dark:bg-black text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-900'
                        }`}
                      >
                        Analyze Food
                      </button>
                    </div>
                  )}
                  
                  <div className="mt-4 relative">
                    {permissionError ? (
                      <div className="bg-gray-100 dark:bg-gray-900 rounded-lg overflow-hidden aspect-video relative flex flex-col items-center justify-center p-4">
                        <CameraIcon size={48} className="text-gray-400 dark:text-gray-200 mb-4" />
                        <p className="text-gray-500 dark:text-gray-200 text-sm max-w-xs">
                          Camera access is required to scan ingredients. Please allow camera access and try again.
                        </p>
                      </div>
                    ) : (
                      <div className="bg-gray-800 rounded-lg overflow-hidden aspect-video relative">
                        {/* Live camera feed */}
                        <video 
                          ref={videoRef}
                          autoPlay 
                          playsInline
                          muted
                          className="w-full h-full object-cover"
                        />
                        
                        {/* Scanner animation only when actively scanning */}
                        {scanning && (
                          <>
                            <div className="absolute inset-0 bg-gradient-to-b from-green-400/10 to-transparent animate-pulse"></div>
                            <div
                              className="absolute left-0 right-0 h-0.5 bg-primary-400"
                              style={{
                                top: "50%",
                                animation: "scan 3s infinite linear",
                              }}
                            ></div>
                          </>
                        )}

                        {/* Camera viewfinder guides */}
                        <div className="absolute inset-0 border-2 border-dashed border-white/30 m-8 rounded"></div>

                        {/* Status indicator */}
                        {scanning && (
                          <div className="absolute top-4 right-4 flex items-center">
                            <span className="h-2.5 w-2.5 bg-primary-500 rounded-full animate-pulse mr-1.5"></span>
                            <span className="text-white text-xs">Scanning...</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  
                  <div className="mt-4">
                    <p className="text-sm text-gray-500 dark:text-gray-200">
                      {permissionError 
                        ? "Please enable camera access in your browser settings" 
                        : scanning 
                          ? scanMode === 'ingredients'
                            ? "Hold your camera steady while we identify your ingredients"
                            : "Hold your camera steady while we analyze your food"
                          : scanMode === 'ingredients'
                            ? "Position your camera to show ingredients clearly"
                            : "Position your camera to show your meal clearly"
                      }
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mt-5 sm:mt-6 flex gap-3">
                <Button
                  type="button"
                  onClick={onClose}
                  variant="secondary"
                  className="flex-1"
                >
                  Cancel
                </Button>
                
                {!permissionError && !scanning && (
                  <Button
                    type="button"
                    onClick={handleStartScan}
                    disabled={!cameraActive || scanning}
                    className="flex-1 bg-gradient-to-r from-primary-500 to-orange-400 text-white hover:from-primary-600 hover:to-orange-500 disabled:opacity-50"
                  >
                    {scanMode === 'ingredients' ? 'Scan Ingredients' : 'Analyze Food'}
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
