import { useLocation } from "wouter";
import { useState } from "react";
import { 
  HomeIcon, 
  BookmarkIcon, 
  UserIcon, 
  MoonIcon,
  SunIcon,
  MessageCircleIcon,
  ActivityIcon,
  AppleIcon
} from "./ui/icons";
import { Award as AwardIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { useTheme } from "@/providers/theme-provider";

export default function MobileNav() {
  const [location, setLocation] = useLocation();
  const { theme, setTheme } = useTheme();
  // Create button state/effect removed as requested

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Determine active tab
  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <>
      {/* Floating create button removed as requested */}
      
      {/* Floating theme toggle button */}
      <button 
        onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
        className="md:hidden fixed bottom-20 left-4 z-50 w-12 h-12 rounded-full bg-card border border-border flex items-center justify-center shadow-lg"
      >
        {theme === 'dark' ? (
          <SunIcon className="text-orange-500" size={20} />
        ) : (
          <MoonIcon className="text-orange-500" size={20} />
        )}
      </button>

      {/* Bottom navigation bar */}
      <div className="md:hidden fixed bottom-0 inset-x-0 bg-card border-t border-border z-40 shadow-lg">
        <div className="flex justify-around">
          <NavButton 
            icon={<HomeIcon size={22} />} 
            label="Home" 
            isActive={isActive("/")}
            onClick={() => setLocation("/")}
          />
          <button 
            className={cn(
              "flex flex-col items-center pt-2 pb-1 px-3 relative",
              isActive("/chat") 
                ? "text-white" 
                : "text-muted-foreground hover:text-foreground"
            )}
            onClick={() => setLocation("/chat")}
          >
            {isActive("/chat") && (
              <div className="absolute top-0 inset-x-3 h-0.5 bg-orange-500 dark:bg-orange-400 rounded-full" />
            )}
            <div className={cn(
              "p-1.5 rounded-full transition-colors",
              isActive("/chat") 
                ? "bg-gradient-to-r from-orange-600 to-orange-400 text-white" 
                : "bg-transparent"
            )}>
              <MessageCircleIcon size={22} />
            </div>
            <span className={cn(
              "text-xs mt-1 font-medium",
              isActive("/chat") ? "text-orange-500 dark:text-orange-400" : ""
            )}>Coach</span>
          </button>
          <NavButton 
            icon={<AppleIcon size={22} />} 
            label="Nutrition" 
            isActive={isActive("/nutrition")}
            onClick={() => setLocation("/nutrition")}
          />
          <NavButton 
            icon={<AwardIcon size={22} />} 
            label="Awards" 
            isActive={isActive("/achievements")}
            onClick={() => setLocation("/achievements")}
          />
          <NavButton 
            icon={<UserIcon size={22} />} 
            label="Account" 
            isActive={isActive("/account")}
            onClick={() => setLocation("/account")}
          />
        </div>
      </div>
    </>
  );
}

interface NavButtonProps {
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
}

function NavButton({ icon, label, isActive, onClick }: NavButtonProps) {
  return (
    <button 
      className={cn(
        "flex flex-col items-center pt-2 pb-1 px-3 relative",
        isActive 
          ? "text-white" 
          : "text-muted-foreground hover:text-foreground"
      )}
      onClick={onClick}
    >
      {isActive && (
        <div className="absolute top-0 inset-x-3 h-0.5 bg-orange-500 dark:bg-orange-400 rounded-full" />
      )}
      <div className={cn(
        "p-1.5 rounded-full transition-colors",
        isActive 
          ? "bg-gradient-to-r from-orange-500 to-orange-400 text-white" 
          : "bg-transparent"
      )}>
        {icon}
      </div>
      <span className={cn(
        "text-xs mt-1 font-medium",
        isActive ? "text-orange-500 dark:text-orange-400" : ""
      )}>{label}</span>
    </button>
  );
}
