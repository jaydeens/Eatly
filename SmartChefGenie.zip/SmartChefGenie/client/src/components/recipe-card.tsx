import { useState, useRef, useEffect } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ClockIcon, UsersIcon, BookmarkIcon, FlameIcon, SparklesIcon, LeafIcon, WandIcon } from "./ui/icons";
import { type Recipe } from "@shared/schema";
import { cn } from "@/lib/utils";

interface RecipeCardProps {
  recipe: Recipe;
  onViewRecipe: () => void;
  onSaveRecipe?: () => Promise<void>;
}

export default function RecipeCard({ recipe, onViewRecipe, onSaveRecipe }: RecipeCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [isImageLoaded, setIsImageLoaded] = useState(false);
  
  // Function to determine tag colors
  const getTagColorClasses = (tag: string) => {
    switch (tag.toLowerCase()) {
      case "vegetarian":
        return "bg-green-100 text-green-800 border border-green-200";
      case "vegan":
        return "bg-emerald-100 text-emerald-800 border border-emerald-200";
      case "gluten-free":
        return "bg-amber-100 text-amber-800 border border-amber-200";
      case "low-carb":
        return "bg-blue-100 text-blue-800 border border-blue-200";
      case "dairy-free":
        return "bg-purple-100 text-purple-800 border border-purple-200";
      case "keto":
        return "bg-indigo-100 text-indigo-800 border border-indigo-200";
      case "paleo":
        return "bg-red-100 text-red-800 border border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border border-gray-200";
    }
  };
  
  // Truncate the description to a reasonable length
  const truncateDescription = (text: string, maxLength = 100) => {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength).trim() + '...';
  };

  // Calculate health score color
  const getHealthScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-emerald-600";
    if (score >= 40) return "text-yellow-600";
    return "text-orange-600";
  };

  // Animation delay reference
  const animationRef = useRef(Math.random() * 0.5);
  const [showAIBadge, setShowAIBadge] = useState(false);
  
  // Show AI badge with a slight delay
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowAIBadge(true);
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div 
      className="group relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Card background glow effect */}
      <div className={cn(
        "absolute -inset-0.5 bg-gradient-to-r from-orange-500/0 via-orange-500/0 to-orange-400/0 rounded-2xl blur-sm opacity-0 group-hover:opacity-100 group-hover:from-orange-500/20 group-hover:via-orange-500/20 group-hover:to-orange-400/20 transition-all duration-700",
        isHovered ? "animate-pulse" : ""
      )}></div>
      
      <Card 
        className="relative bg-background dark:bg-black/40 backdrop-blur-sm rounded-xl overflow-hidden shadow transition-all duration-300 h-full flex flex-col transform hover:-translate-y-1 hover:shadow-lg border border-orange-200/20 dark:border-orange-800/20 z-10"
      >
        <div className="relative overflow-hidden">
          {/* Image skeleton/placeholder */}
          {!isImageLoaded && (
            <div className="h-56 w-full bg-muted dark:bg-gray-800/50 flex items-center justify-center">
              <div className="relative h-12 w-12">
                <div className="absolute inset-0 rounded-full border-2 border-t-transparent border-orange-300 animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <SparklesIcon size={16} className="text-orange-500" />
                </div>
              </div>
            </div>
          )}
          
          {/* Actual image with transition */}
          <div className={`${isImageLoaded ? 'opacity-100' : 'opacity-0'} transition-opacity duration-300`}>
            <div className="relative h-56 w-full overflow-hidden">
              <img 
                src={recipe.image} 
                alt={recipe.title} 
                className={`h-full w-full object-cover transition-transform duration-700 ${isHovered ? 'scale-110' : 'scale-100'}`} 
                onLoad={() => setIsImageLoaded(true)}
              />
              
              {/* AI-enhanced recipe badge */}
              <div className={cn(
                "absolute top-3 left-3 transition-all duration-500 transform",
                showAIBadge ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"
              )}
              style={{ transitionDelay: `${animationRef.current}s` }}>
                <Badge className="bg-black/50 text-white backdrop-blur-md border-orange-500/20 shadow-lg">
                  <div className="flex items-center gap-1.5">
                    <SparklesIcon size={12} className="text-orange-400" />
                    <span className="text-xs font-medium">AI-Enhanced</span>
                  </div>
                </Badge>
              </div>
              
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"></div>
              
              {/* Recipe metrics */}
              <div className="absolute bottom-0 left-0 right-0 p-3 flex justify-between items-end">
                <div className="flex flex-col gap-1.5">
                  {recipe.healthScore !== undefined && recipe.healthScore !== null && (
                    <div className="inline-flex items-center gap-1 text-xs text-white/90">
                      <div className="relative flex h-3 w-3">
                        <div className={cn(
                          "absolute inline-flex h-full w-full rounded-full",
                          recipe.healthScore >= 70 ? "bg-green-500" : 
                          recipe.healthScore >= 50 ? "bg-yellow-500" : "bg-orange-500"
                        )}></div>
                      </div>
                      <span>{recipe.healthScore}% Healthy</span>
                    </div>
                  )}
                  
                  <div className="flex items-center gap-3">
                    <div className="inline-flex items-center gap-1 text-xs text-white/90">
                      <ClockIcon size={12} className="text-orange-400" />
                      <span>{recipe.time}</span>
                    </div>
                    
                    <div className="inline-flex items-center gap-1 text-xs text-white/90">
                      <UsersIcon size={12} className="text-orange-400" />
                      <span>{recipe.servings} servings</span>
                    </div>
                  </div>
                </div>
                
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-8 w-8 rounded-full bg-gradient-to-r from-orange-600 to-orange-400 backdrop-blur-md border border-white/10 text-white hover:bg-orange-500"
                  onClick={onSaveRecipe}
                  disabled={!onSaveRecipe}
                >
                  <BookmarkIcon size={14} />
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="p-4 flex-grow flex flex-col">
          <div className="flex-grow space-y-3">
            <h3 className="text-lg font-bold text-foreground line-clamp-2">{recipe.title}</h3>

            {/* AI-recommended badge if health score is high */}
            {recipe.healthScore && recipe.healthScore > 80 && (
              <div className={cn(
                "inline-flex items-center gap-1.5 py-1 px-2 text-xs font-medium rounded-md bg-green-100/50 dark:bg-green-900/20 text-green-700 dark:text-green-400 border border-green-200/50 dark:border-green-800/30",
                "transition-all duration-500",
                showAIBadge ? "opacity-100" : "opacity-0"
              )}>
                <LeafIcon size={12} />
                <span>AI Recommended for Health</span>
              </div>
            )}

            {/* Dietary tags */}
            <div className="flex flex-wrap gap-1.5">
              {recipe.tags.slice(0, 3).map((tag, tagIndex) => (
                <Badge
                  key={tagIndex}
                  variant="outline"
                  className="bg-background/50 dark:bg-black/20 backdrop-blur-sm border-orange-200/30 dark:border-orange-800/30 text-foreground/80"
                >
                  {tag}
                </Badge>
              ))}
              {recipe.tags.length > 3 && (
                <Badge variant="outline" className="bg-background/50 dark:bg-black/20 backdrop-blur-sm border-orange-200/30 dark:border-orange-800/30">
                  +{recipe.tags.length - 3}
                </Badge>
              )}
            </div>

            <p className="text-muted-foreground text-sm">{truncateDescription(recipe.description)}</p>
          </div>

          <div className="mt-4 pt-3 border-t border-orange-100/20 dark:border-orange-900/20 flex items-center justify-between">
            {recipe.calories && (
              <div className="text-sm text-foreground/80 dark:text-foreground/70">
                <span className="font-medium">{recipe.calories}</span>
                <span className="text-foreground/70 dark:text-foreground/60 ml-1">calories</span>
              </div>
            )}
            
            <Button
              onClick={onViewRecipe}
              size="sm"
              className="relative group overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-orange-400 group-hover:from-orange-500 group-hover:to-orange-300"></div>
              <div className="relative z-10 flex items-center gap-1.5 text-white px-3">
                <WandIcon size={14} />
                <span>View Recipe</span>
              </div>
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
