import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { LeafIcon, PlusIcon, CalendarIcon, TrashIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { NutritionLog } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import AddNutritionLogForm from "./add-nutrition-log-form";

export default function NutritionLogsList() {
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedLogId, setSelectedLogId] = useState<number | null>(null);
  
  // Fetch nutrition logs
  const { data: logs, isLoading } = useQuery<NutritionLog[]>({
    queryKey: ['/api/nutrition/logs'],
    refetchOnWindowFocus: false,
  });
  
  // Delete log mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest({
        method: "DELETE", 
        url: `/api/nutrition/logs/${id}`
      });
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/nutrition/logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/nutrition/stats'] });
      toast({
        title: "Log deleted",
        description: "Your meal log has been removed.",
      });
      setDeleteDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete log",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleDeleteClick = (id: number) => {
    setSelectedLogId(id);
    setDeleteDialogOpen(true);
  };
  
  const handleDeleteConfirm = () => {
    if (selectedLogId !== null) {
      deleteMutation.mutate(selectedLogId);
    }
  };
  
  // Get meal type badge color
  const getMealTypeColor = (mealType: string) => {
    switch (mealType) {
      case "breakfast":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-950 dark:text-yellow-300";
      case "lunch":
        return "bg-green-100 text-green-800 dark:bg-green-950 dark:text-green-300";
      case "dinner":
        return "bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300";
      case "snack":
        return "bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300";
    }
  };
  
  return (
    <>
      <Card className="h-full flex flex-col">
        <CardHeader className="flex flex-row items-start justify-between space-y-0">
          <div>
            <CardTitle>Nutrition Logs</CardTitle>
            <CardDescription>Your meal tracking history</CardDescription>
          </div>
          <Button 
            onClick={() => setAddDialogOpen(true)}
            className="bg-gradient-to-r from-orange-500 to-orange-400 hover:from-orange-600 hover:to-orange-500"
            size="sm"
          >
            <PlusIcon className="w-4 h-4 mr-2" />
            Log Meal
          </Button>
        </CardHeader>
        <CardContent className="flex-grow overflow-auto">
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="w-8 h-8 rounded-full border-4 border-orange-500 border-t-transparent animate-spin"></div>
            </div>
          ) : logs && logs.length > 0 ? (
            <div className="space-y-4">
              {logs.map((log) => (
                <div 
                  key={log.id} 
                  className="flex items-start border-b border-border pb-4 last:border-0 last:pb-0"
                >
                  <div className="w-16 h-16 rounded-md bg-muted overflow-hidden mr-4 flex-shrink-0">
                    {log.imageUrl ? (
                      <img src={log.imageUrl} alt={log.mealType} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-orange-100 dark:bg-orange-950/30">
                        <LeafIcon className="text-orange-500" />
                      </div>
                    )}
                  </div>
                  <div className="flex-grow">
                    <div className="flex justify-between items-start">
                      <div>
                        <Badge variant="outline" className={getMealTypeColor(log.mealType)}>
                          {log.mealType.charAt(0).toUpperCase() + log.mealType.slice(1)}
                        </Badge>
                        <span className="text-sm flex items-center text-muted-foreground mt-1">
                          <CalendarIcon className="w-3 h-3 mr-1" />
                          {format(new Date(log.date), 'PPP')}
                        </span>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-muted-foreground hover:text-destructive"
                        onClick={() => handleDeleteClick(log.id)}
                      >
                        <TrashIcon className="h-4 w-4" />
                      </Button>
                    </div>
                    <p className="text-sm mt-1 line-clamp-2">
                      {log.foodItems.join(', ')}
                    </p>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {log.calories && (
                        <span className="text-xs inline-flex items-center bg-muted px-2 py-1 rounded">
                          <span className="font-medium">{log.calories}</span>
                          <span className="ml-1 text-muted-foreground">kcal</span>
                        </span>
                      )}
                      {log.protein && (
                        <span className="text-xs inline-flex items-center bg-muted px-2 py-1 rounded">
                          <span className="font-medium">{log.protein}g</span>
                          <span className="ml-1 text-muted-foreground">protein</span>
                        </span>
                      )}
                      {log.healthScore && (
                        <span className="text-xs inline-flex items-center bg-muted px-2 py-1 rounded">
                          <span className="font-medium">{log.healthScore}/10</span>
                          <span className="ml-1 text-muted-foreground">health</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <LeafIcon size={36} className="text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No nutrition logs yet</h3>
              <p className="text-muted-foreground mb-6">Start tracking your meals to see your nutrition history</p>
              <Button 
                onClick={() => setAddDialogOpen(true)}
                className="bg-gradient-to-r from-orange-500 to-orange-400 hover:from-orange-600 hover:to-orange-500"
              >
                Log Your First Meal
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Add Meal Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Log a Meal</DialogTitle>
            <DialogDescription>
              Record what you've eaten to track your nutrition progress
            </DialogDescription>
          </DialogHeader>
          <AddNutritionLogForm 
            onSuccess={() => setAddDialogOpen(false)}
            onCancel={() => setAddDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this meal log from your nutrition history.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteConfirm}
              className="bg-red-500 hover:bg-red-600"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}