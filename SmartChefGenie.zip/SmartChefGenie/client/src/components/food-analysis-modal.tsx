import React, { useState, useRef } from "react";
import { Button } from "./ui/button";
import { XIcon, CameraIcon, ChartIcon, LeafIcon } from "./ui/icons";
import { apiRequest } from "../lib/queryClient";
import { useToast } from "../hooks/use-toast";

// Custom AlertCircleIcon removed from icons.tsx to reduce dependencies
const AlertCircleIcon = ({ size = 24, className = "" }: { size?: number, className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <circle cx="12" cy="12" r="10" />
    <line x1="12" y1="8" x2="12" y2="12" />
    <line x1="12" y1="16" x2="12.01" y2="16" />
  </svg>
);

type FoodAnalysisData = {
  foodItems: string[];
  healthAssessment: {
    score: number;
    category: 'Very Healthy' | 'Healthy' | 'Moderate' | 'Unhealthy' | 'Very Unhealthy';
    summary: string;
    nutritionalHighlights: string[];
    healthBenefits: string[];
    concerns: string[];
    alternatives: string[];
  };
};

type ChatMessage = {
  role: 'user' | 'assistant' | 'system';
  content: string;
};

interface FoodAnalysisModalProps {
  imageData: string;
  onClose: () => void;
}

export default function FoodAnalysisModal({ imageData, onClose }: FoodAnalysisModalProps) {
  const [analysis, setAnalysis] = useState<FoodAnalysisData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'analysis' | 'chat'>('analysis');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [sendingMessage, setSendingMessage] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  React.useEffect(() => {
    const analyzeFoodImage = async () => {
      try {
        setLoading(true);
        setError(null);

        // Verify OpenAI API key is configured
        const apiKeyCheck = await apiRequest<{ success: boolean; message: string }>({
          method: "GET",
          url: "/api/openai/verify",
          on401: "throw"
        });

        if (!apiKeyCheck.success) {
          throw new Error(apiKeyCheck.message || "OpenAI API key is not properly configured");
        }

        // Only proceed if the API key verification passed
        const result = await apiRequest<{ success: boolean; analysis: FoodAnalysisData }>({
          method: "POST",
          url: "/api/food/analyze",
          data: { image: imageData },
          on401: "throw"
        });

        if (result.success && result.analysis) {
          setAnalysis(result.analysis);
          
          // Add initial system message about the analyzed food
          const foodItems = result.analysis.foodItems.join(", ");
          setChatMessages([
            {
              role: 'system',
              content: `We've analyzed an image of ${foodItems}. The health score is ${result.analysis.healthAssessment.score}/10, categorized as ${result.analysis.healthAssessment.category}. Ask me anything about this food or nutrition in general!`
            }
          ]);
        } else {
          throw new Error("Failed to analyze the food image");
        }
      } catch (err: any) {
        console.error("Error analyzing food:", err);
        
        // Extract the specific error message from the API response if available
        let errorMessage = "Failed to analyze the food. Please try again.";
        
        if (err.response?.data?.message) {
          errorMessage = err.response.data.message;
        } else if (err.response?.data?.error) {
          errorMessage = err.response.data.error;
        } else if (err.message) {
          errorMessage = err.message;
        }
        
        // Check for API key related errors and provide clearer message
        if (errorMessage.includes("API key") || 
            errorMessage.includes("authentication") || 
            errorMessage.includes("OpenAI") ||
            errorMessage.includes("not configured")) {
          errorMessage = "The OpenAI API key is missing or invalid. Please add your OpenAI API key in the application settings.";
          
          // Show toast with more actionable information
          toast({
            variant: "destructive",
            title: "API Key Required",
            description: "This feature requires a valid OpenAI API key. Please ask the application administrator to configure the API key.",
          });
        } else {
          toast({
            variant: "destructive",
            title: "Analysis failed",
            description: errorMessage,
          });
        }
        
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    };

    analyzeFoodImage();
  }, [imageData, toast]);

  React.useEffect(() => {
    // Scroll to bottom of chat when messages change
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages]);

  const handleSendMessage = async () => {
    if (!newMessage.trim() || sendingMessage) return;

    try {
      setSendingMessage(true);
      
      // Add user message to chat
      const userMessage: ChatMessage = { role: 'user', content: newMessage };
      const updatedMessages = [...chatMessages, userMessage];
      setChatMessages(updatedMessages);
      setNewMessage('');

      // Verify OpenAI API key is configured 
      const apiKeyCheck = await apiRequest<{ success: boolean; message: string }>({
        method: "GET",
        url: "/api/openai/verify",
        on401: "throw"
      });

      if (!apiKeyCheck.success) {
        throw new Error(apiKeyCheck.message || "OpenAI API key is not properly configured");
      }

      // Call API to get AI response
      const result = await apiRequest<{ success: boolean; message: ChatMessage }>({
        method: "POST",
        url: "/api/food/chat",
        data: { messages: updatedMessages },
        on401: "throw"
      });

      if (result.success && result.message) {
        // Add AI response to chat
        setChatMessages([...updatedMessages, result.message]);
      } else {
        throw new Error("Failed to get a response");
      }
    } catch (err: any) {
      console.error("Error sending message:", err);
      
      // Extract the specific error message from the API response if available
      let errorMessage = "There was a problem getting a response. Please try again.";
      
      if (err.response?.data?.message) {
        errorMessage = err.response.data.message;
      } else if (err.response?.data?.error) {
        errorMessage = err.response.data.error;
      } else if (err.message) {
        errorMessage = err.message;
      }
      
      // Check for API key related errors and provide clearer message
      if (errorMessage.includes("API key") || 
          errorMessage.includes("authentication") || 
          errorMessage.includes("OpenAI") ||
          errorMessage.includes("not configured")) {
        errorMessage = "The OpenAI API key is missing or invalid. Please add your OpenAI API key in the application settings.";
        
        // Show toast with more actionable information
        toast({
          variant: "destructive",
          title: "API Key Required",
          description: "This feature requires a valid OpenAI API key. Please ask the application administrator to configure the API key.",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Message failed",
          description: errorMessage,
        });
      }
    } finally {
      setSendingMessage(false);
    }
  };

  // Helper function to determine health score color
  const getHealthScoreColor = (score: number) => {
    if (score >= 8) return "text-green-500";
    if (score >= 6) return "text-lime-500";
    if (score >= 4) return "text-amber-500";
    if (score >= 2) return "text-orange-500";
    return "text-red-500";
  };

  const getHealthCategoryColor = (category: string) => {
    switch (category) {
      case 'Very Healthy': return "bg-green-100 text-green-800";
      case 'Healthy': return "bg-lime-100 text-lime-800";
      case 'Moderate': return "bg-amber-100 text-amber-800";
      case 'Unhealthy': return "bg-orange-100 text-orange-800";
      case 'Very Unhealthy': return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:p-0">
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>
        <div className="relative inline-block align-bottom bg-white rounded-lg overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-2xl sm:w-full">
          <div className="absolute top-0 right-0 pt-4 pr-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="text-gray-400 hover:text-gray-500"
            >
              <XIcon />
            </Button>
          </div>
          
          {/* Modal Header */}
          <div className="bg-gradient-to-r from-primary-500 to-orange-400 px-4 py-4 sm:px-6">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium text-white flex items-center">
                <CameraIcon size={20} className="mr-2" />
                Food Analysis
              </h3>
              
              {/* Tab Navigation */}
              <div className="flex rounded-md overflow-hidden border border-white/20">
                <button
                  onClick={() => setActiveTab('analysis')}
                  className={`px-3 py-1.5 text-xs font-medium flex items-center ${
                    activeTab === 'analysis' 
                      ? 'bg-white text-primary-600' 
                      : 'bg-transparent text-white hover:bg-white/10'
                  }`}
                >
                  <ChartIcon size={16} className="mr-1.5" />
                  Analysis
                </button>
                <button
                  onClick={() => setActiveTab('chat')}
                  className={`px-3 py-1.5 text-xs font-medium flex items-center ${
                    activeTab === 'chat' 
                      ? 'bg-white text-primary-600' 
                      : 'bg-transparent text-white hover:bg-white/10'
                  }`}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={16}
                    height={16}
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="mr-1.5"
                  >
                    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5Z" />
                  </svg>
                  Chat
                </button>
              </div>
            </div>
          </div>
          
          <div className="bg-white overflow-auto max-h-[70vh]">
            {loading ? (
              <div className="flex flex-col items-center justify-center py-12">
                <div className="w-16 h-16 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin mb-4"></div>
                <p className="text-gray-500">Analyzing your food...</p>
              </div>
            ) : error ? (
              <div className="flex flex-col items-center justify-center py-12">
                <div className="w-16 h-16 text-red-500 mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={64}
                    height={64}
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <circle cx="12" cy="12" r="10" />
                    <line x1="12" y1="8" x2="12" y2="12" />
                    <line x1="12" y1="16" x2="12.01" y2="16" />
                  </svg>
                </div>
                <p className="text-gray-700 font-medium mb-2">Analysis Failed</p>
                <p className="text-gray-500 mb-6">{error}</p>
                <Button onClick={onClose}>Close</Button>
              </div>
            ) : (
              <>
                {activeTab === 'analysis' && analysis && (
                  <div className="overflow-auto p-4 sm:p-6">
                    {/* Image and Score Section */}
                    <div className="flex flex-col md:flex-row gap-6 mb-6">
                      <div className="w-full md:w-1/3 rounded-lg overflow-hidden">
                        <img 
                          src={imageData} 
                          alt="Food" 
                          className="w-full h-full object-cover"
                        />
                      </div>
                      
                      <div className="w-full md:w-2/3">
                        <div className="mb-4">
                          <h4 className="text-lg font-medium text-gray-900 mb-2">Detected Food Items</h4>
                          <div className="flex flex-wrap gap-2">
                            {analysis.foodItems.map((item, idx) => (
                              <span 
                                key={idx} 
                                className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800"
                              >
                                {item}
                              </span>
                            ))}
                          </div>
                        </div>
                        
                        <div className="mb-4">
                          <h4 className="text-lg font-medium text-gray-900 mb-2">Health Assessment</h4>
                          
                          <div className="flex items-center mb-4">
                            <div className="w-16 h-16 rounded-full flex items-center justify-center mr-4 bg-gray-100">
                              <span className={`text-2xl font-bold ${getHealthScoreColor(analysis.healthAssessment.score)}`}>
                                {analysis.healthAssessment.score}/10
                              </span>
                            </div>
                            
                            <div>
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-md text-sm font-medium ${getHealthCategoryColor(analysis.healthAssessment.category)}`}>
                                {analysis.healthAssessment.category}
                              </span>
                              <p className="text-gray-700 mt-1">{analysis.healthAssessment.summary}</p>
                            </div>
                          </div>
                          
                          {/* Health Score Bar */}
                          <div className="h-2.5 w-full bg-gray-200 rounded-full mb-2">
                            <div 
                              className="h-2.5 rounded-full bg-gradient-to-r from-red-500 to-green-500"
                              style={{ width: `${(analysis.healthAssessment.score / 10) * 100}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* Detailed Analysis Sections */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Nutritional Highlights */}
                      <div className="bg-green-50 p-4 rounded-lg">
                        <h4 className="text-md font-medium text-green-800 mb-3 flex items-center">
                          <LeafIcon size={18} className="mr-2 text-green-600" />
                          Nutritional Highlights
                        </h4>
                        <ul className="space-y-2">
                          {analysis.healthAssessment.nutritionalHighlights.map((highlight, idx) => (
                            <li key={idx} className="text-sm text-green-700 flex">
                              <span className="mr-2">•</span>
                              <span>{highlight}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      {/* Health Benefits */}
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h4 className="text-md font-medium text-blue-800 mb-3 flex items-center">
                          <ChartIcon size={18} className="mr-2 text-blue-600" />
                          Health Benefits
                        </h4>
                        <ul className="space-y-2">
                          {analysis.healthAssessment.healthBenefits.map((benefit, idx) => (
                            <li key={idx} className="text-sm text-blue-700 flex">
                              <span className="mr-2">•</span>
                              <span>{benefit}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      {/* Concerns */}
                      {analysis.healthAssessment.concerns.length > 0 && (
                        <div className="bg-orange-50 p-4 rounded-lg">
                          <h4 className="text-md font-medium text-orange-800 mb-3 flex items-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width={18}
                              height={18}
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="mr-2 text-orange-600"
                            >
                              <circle cx="12" cy="12" r="10" />
                              <line x1="12" y1="8" x2="12" y2="12" />
                              <line x1="12" y1="16" x2="12.01" y2="16" />
                            </svg>
                            Concerns
                          </h4>
                          <ul className="space-y-2">
                            {analysis.healthAssessment.concerns.map((concern, idx) => (
                              <li key={idx} className="text-sm text-orange-700 flex">
                                <span className="mr-2">•</span>
                                <span>{concern}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      
                      {/* Healthier Alternatives */}
                      {analysis.healthAssessment.alternatives.length > 0 && (
                        <div className="bg-purple-50 p-4 rounded-lg">
                          <h4 className="text-md font-medium text-purple-800 mb-3">
                            Healthier Alternatives
                          </h4>
                          <ul className="space-y-2">
                            {analysis.healthAssessment.alternatives.map((alternative, idx) => (
                              <li key={idx} className="text-sm text-purple-700 flex">
                                <span className="mr-2">•</span>
                                <span>{alternative}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                )}
                
                {activeTab === 'chat' && (
                  <div className="flex flex-col h-[60vh]">
                    {/* Chat Messages */}
                    <div className="flex-1 overflow-y-auto p-4">
                      <div className="space-y-4">
                        {chatMessages.filter(msg => msg.role !== 'system').map((msg, idx) => (
                          <div 
                            key={idx}
                            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                          >
                            <div 
                              className={`max-w-[80%] rounded-lg px-4 py-2 ${
                                msg.role === 'user' 
                                  ? 'bg-primary-500 text-white' 
                                  : 'bg-gray-100 text-gray-800'
                              }`}
                            >
                              {msg.content}
                            </div>
                          </div>
                        ))}
                        {sendingMessage && (
                          <div className="flex justify-start">
                            <div className="bg-gray-100 rounded-lg px-4 py-2 max-w-[80%]">
                              <div className="flex space-x-1">
                                <div className="h-2 w-2 bg-gray-400 rounded-full animate-bounce"></div>
                                <div className="h-2 w-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                                <div className="h-2 w-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                              </div>
                            </div>
                          </div>
                        )}
                        <div ref={messagesEndRef} />
                      </div>
                    </div>
                    
                    {/* Chat Input */}
                    <div className="border-t border-gray-200 p-4">
                      <div className="flex items-center">
                        <input
                          type="text"
                          value={newMessage}
                          onChange={(e) => setNewMessage(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                          placeholder="Ask ChefAI about this food..."
                          className="flex-1 border-2 border-gray-300 rounded-l-md py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        />
                        <Button
                          onClick={handleSendMessage}
                          disabled={!newMessage.trim() || sendingMessage}
                          className="rounded-l-none bg-primary-500 hover:bg-primary-600"
                        >
                          <span className="sr-only">Send</span>
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
                          </svg>
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
          
          <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
            <Button
              type="button"
              onClick={onClose}
              variant="secondary"
              className="w-full sm:w-auto"
            >
              Close
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}