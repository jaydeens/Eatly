import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { NutritionGoal, NutritionLog } from "@shared/schema";
import { format, subDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from "date-fns";

interface NutritionStats {
  totalLogs: number;
  averageHealthScore: number;
  averageCalories: number;
  topFoodItems: Array<{ item: string, count: number }>;
  periodStart?: Date;
  periodEnd?: Date;
}

type PeriodType = "day" | "week" | "month";

export default function NutritionStatsPeriod() {
  const [period, setPeriod] = useState<PeriodType>("day");

  // Build date range for the period
  const today = new Date();
  let periodStart: Date;
  let periodEnd: Date = today;
  
  switch (period) {
    case "day":
      periodStart = today;
      break;
    case "week":
      periodStart = startOfWeek(today, { weekStartsOn: 1 }); // Monday as first day
      periodEnd = endOfWeek(today, { weekStartsOn: 1 });
      break;
    case "month":
      periodStart = startOfMonth(today);
      periodEnd = endOfMonth(today);
      break;
  }
  
  // Format date range for display
  const getDateRangeText = () => {
    if (period === "day") {
      return `Today (${format(today, "MMM d, yyyy")})`;
    } else if (period === "week") {
      return `${format(periodStart, "MMM d")} - ${format(periodEnd, "MMM d, yyyy")}`;
    } else {
      return format(periodStart, "MMMM yyyy");
    }
  };
  
  // Fetch nutrition stats for the period
  const { data: stats, isLoading: statsLoading } = useQuery<NutritionStats>({
    queryKey: ['/api/nutrition/stats', period],
    refetchOnWindowFocus: false,
  });
  
  // Fetch nutrition logs for the period
  const { data: logs, isLoading: logsLoading } = useQuery<NutritionLog[]>({
    queryKey: ['/api/nutrition/logs', period],
    refetchOnWindowFocus: false,
  });
  
  // Fetch nutrition goals
  const { data: goals, isLoading: goalsLoading } = useQuery<NutritionGoal>({
    queryKey: ['/api/nutrition/goals'],
    refetchOnWindowFocus: false,
  });
  
  const isLoading = statsLoading || logsLoading || goalsLoading;
  
  // Calculate progress percentages
  const getProgressPercentage = (current: number | null | undefined, target: number | null | undefined): number => {
    const currentValue = current || 0;
    const targetValue = target || 0;
    
    if (targetValue === 0) return 0;
    
    const percentage = (currentValue / targetValue) * 100;
    return Math.min(100, Math.max(0, percentage)); // Clamp between 0-100
  };
  
  // Calculate periodic averages from logs
  const calculateAverages = () => {
    if (!logs || logs.length === 0) {
      return {
        calories: 0,
        protein: 0,
        carbs: 0,
        fat: 0,
        fiber: 0,
        water: 0,
        healthScore: 0
      };
    }
    
    const totals = logs.reduce((acc, log) => {
      return {
        calories: acc.calories + (log.calories || 0),
        protein: acc.protein + (log.protein || 0),
        carbs: acc.carbs + (log.carbs || 0),
        fat: acc.fat + (log.fat || 0),
        fiber: acc.fiber + (log.fiber || 0),
        water: acc.water + (log.water || 0),
        healthScore: acc.healthScore + (log.healthScore || 0)
      };
    }, {
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      fiber: 0,
      water: 0,
      healthScore: 0
    });
    
    // Calculate number of unique days in logs
    const uniqueDays = new Set(logs.map(log => 
      format(new Date(log.date), 'yyyy-MM-dd')
    )).size;
    
    const divisor = uniqueDays || 1; // Prevent division by zero
    
    return {
      calories: Math.round(totals.calories / divisor),
      protein: Math.round(totals.protein / divisor),
      carbs: Math.round(totals.carbs / divisor),
      fat: Math.round(totals.fat / divisor),
      fiber: Math.round(totals.fiber / divisor),
      water: Math.round(totals.water / divisor),
      healthScore: Number((totals.healthScore / divisor).toFixed(1))
    };
  };
  
  const averages = calculateAverages();
  
  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <CardTitle>Nutrition Analysis</CardTitle>
            <CardDescription>Track your nutritional progress</CardDescription>
          </div>
          <Tabs value={period} onValueChange={(value) => setPeriod(value as PeriodType)} className="mt-2 md:mt-0">
            <TabsList>
              <TabsTrigger value="day">Day</TabsTrigger>
              <TabsTrigger value="week">Week</TabsTrigger>
              <TabsTrigger value="month">Month</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-sm text-muted-foreground mb-4">
          {getDateRangeText()}
        </div>
        
        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="w-8 h-8 rounded-full border-4 border-orange-500 border-t-transparent animate-spin"></div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Health Score */}
            <div className="mb-6">
              <div className="flex justify-between items-end mb-2">
                <div>
                  <h4 className="text-sm font-medium">Health Score</h4>
                  <p className="text-2xl font-bold">{averages.healthScore}/10</p>
                </div>
                {goals?.healthScoreTarget && (
                  <span className="text-sm text-muted-foreground">
                    Target: {goals.healthScoreTarget}/10
                  </span>
                )}
              </div>
              <Progress 
                value={getProgressPercentage(averages.healthScore, goals?.healthScoreTarget || 10) * 10} 
                className="h-2 bg-muted" 
              />
            </div>
            
            {/* Nutrition metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <div className="flex justify-between items-end mb-2">
                  <div>
                    <h4 className="text-sm font-medium">Calories</h4>
                    <p className="text-xl font-bold">{averages.calories} <span className="text-sm font-normal text-muted-foreground">kcal</span></p>
                  </div>
                  {goals?.caloriesTarget && (
                    <span className="text-sm text-muted-foreground">
                      Target: {goals.caloriesTarget} kcal
                    </span>
                  )}
                </div>
                <Progress 
                  value={getProgressPercentage(averages.calories, goals?.caloriesTarget)} 
                  className="h-2 bg-muted" 
                />
              </div>
              
              <div>
                <div className="flex justify-between items-end mb-2">
                  <div>
                    <h4 className="text-sm font-medium">Protein</h4>
                    <p className="text-xl font-bold">{averages.protein} <span className="text-sm font-normal text-muted-foreground">g</span></p>
                  </div>
                  {goals?.proteinTarget && (
                    <span className="text-sm text-muted-foreground">
                      Target: {goals.proteinTarget} g
                    </span>
                  )}
                </div>
                <Progress 
                  value={getProgressPercentage(averages.protein, goals?.proteinTarget)} 
                  className="h-2 bg-muted" 
                />
              </div>
              
              <div>
                <div className="flex justify-between items-end mb-2">
                  <div>
                    <h4 className="text-sm font-medium">Carbs</h4>
                    <p className="text-xl font-bold">{averages.carbs} <span className="text-sm font-normal text-muted-foreground">g</span></p>
                  </div>
                  {goals?.carbsTarget && (
                    <span className="text-sm text-muted-foreground">
                      Target: {goals.carbsTarget} g
                    </span>
                  )}
                </div>
                <Progress 
                  value={getProgressPercentage(averages.carbs, goals?.carbsTarget)} 
                  className="h-2 bg-muted" 
                />
              </div>
              
              <div>
                <div className="flex justify-between items-end mb-2">
                  <div>
                    <h4 className="text-sm font-medium">Fat</h4>
                    <p className="text-xl font-bold">{averages.fat} <span className="text-sm font-normal text-muted-foreground">g</span></p>
                  </div>
                  {goals?.fatTarget && (
                    <span className="text-sm text-muted-foreground">
                      Target: {goals.fatTarget} g
                    </span>
                  )}
                </div>
                <Progress 
                  value={getProgressPercentage(averages.fat, goals?.fatTarget)} 
                  className="h-2 bg-muted" 
                />
              </div>
              
              <div>
                <div className="flex justify-between items-end mb-2">
                  <div>
                    <h4 className="text-sm font-medium">Fiber</h4>
                    <p className="text-xl font-bold">{averages.fiber} <span className="text-sm font-normal text-muted-foreground">g</span></p>
                  </div>
                  {goals?.fiberTarget && (
                    <span className="text-sm text-muted-foreground">
                      Target: {goals.fiberTarget} g
                    </span>
                  )}
                </div>
                <Progress 
                  value={getProgressPercentage(averages.fiber, goals?.fiberTarget)} 
                  className="h-2 bg-muted" 
                />
              </div>
              
              <div>
                <div className="flex justify-between items-end mb-2">
                  <div>
                    <h4 className="text-sm font-medium">Water</h4>
                    <p className="text-xl font-bold">{averages.water} <span className="text-sm font-normal text-muted-foreground">ml</span></p>
                  </div>
                  {goals?.waterTarget && (
                    <span className="text-sm text-muted-foreground">
                      Target: {goals.waterTarget} ml
                    </span>
                  )}
                </div>
                <Progress 
                  value={getProgressPercentage(averages.water, goals?.waterTarget)} 
                  className="h-2 bg-muted" 
                />
              </div>
            </div>
            
            {/* Meal count */}
            <div className="mt-6 pt-6 border-t border-muted">
              <h4 className="text-sm font-medium mb-2">Logs this {period}</h4>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full bg-orange-100 dark:bg-orange-950/50 text-orange-500 flex items-center justify-center mr-3">
                  <span className="text-xl font-bold">{logs?.length || 0}</span>
                </div>
                <div>
                  <p className="text-sm">
                    {logs?.length === 0 ? 
                      `No meals logged for this ${period}` : 
                      `You've logged ${logs?.length} meal${logs?.length !== 1 ? 's' : ''}`}
                  </p>
                  {logs?.length === 0 && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Add meals to see your nutrition stats
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}