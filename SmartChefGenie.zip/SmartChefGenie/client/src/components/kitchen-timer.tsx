import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Plus, 
  Minus, 
  Timer as TimerIcon,
  Volume2,
  VolumeX
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { cn } from "@/lib/utils";

const TIMER_MAX_MINUTES = 60;

interface KitchenTimerProps {
  onComplete?: () => void;
  className?: string;
}

export default function KitchenTimer({ onComplete, className }: KitchenTimerProps) {
  const [timeInSeconds, setTimeInSeconds] = useState(300); // 5 min default
  const [remainingSeconds, setRemainingSeconds] = useState(timeInSeconds);
  const [isRunning, setIsRunning] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [timerComplete, setTimerComplete] = useState(false);
  
  const alarmSoundRef = useRef<HTMLAudioElement | null>(null);
  const tickSoundRef = useRef<HTMLAudioElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  
  // Update remaining time when total time changes
  useEffect(() => {
    if (!isRunning) {
      setRemainingSeconds(timeInSeconds);
    }
  }, [timeInSeconds, isRunning]);
  
  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    
    if (isRunning && remainingSeconds > 0) {
      const startTime = Date.now();
      const initialRemaining = remainingSeconds;
      
      // Use requestAnimationFrame for smoother animation updates
      const updateTimer = () => {
        const elapsedSeconds = Math.floor((Date.now() - startTime) / 1000);
        const newRemaining = Math.max(0, initialRemaining - elapsedSeconds);
        
        setRemainingSeconds(newRemaining);
        
        // Play tick sound on whole seconds
        if (!isMuted && tickSoundRef.current && newRemaining !== initialRemaining && newRemaining % 1 === 0) {
          // Don't play tick on last 3 seconds to avoid overlap with alarm
          if (newRemaining > 3) {
            tickSoundRef.current.currentTime = 0;
            tickSoundRef.current.play().catch(error => console.log("Error playing tick sound:", error));
          }
        }
        
        if (newRemaining > 0 && isRunning) {
          animationFrameRef.current = requestAnimationFrame(updateTimer);
        } else if (newRemaining === 0) {
          handleTimerComplete();
        }
      };
      
      animationFrameRef.current = requestAnimationFrame(updateTimer);
      
      return () => {
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
        }
      };
    }
  }, [isRunning, isMuted]);
  
  // Handle timer complete
  const handleTimerComplete = () => {
    setIsRunning(false);
    setTimerComplete(true);
    
    if (!isMuted && alarmSoundRef.current) {
      alarmSoundRef.current.currentTime = 0;
      alarmSoundRef.current.play().catch(error => console.log("Error playing alarm sound:", error));
      
      // Vibrate if supported
      if (navigator.vibrate) {
        navigator.vibrate([300, 100, 300, 100, 300]);
      }
    }
    
    if (onComplete) {
      onComplete();
    }
  };
  
  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };
  
  // Calculate progress percentage
  const getProgressPercentage = () => {
    return ((timeInSeconds - remainingSeconds) / timeInSeconds) * 100;
  };
  
  // Toggle the timer
  const toggleTimer = () => {
    if (timerComplete) {
      resetTimer();
      setIsRunning(true);
    } else {
      setIsRunning(!isRunning);
    }
  };
  
  // Reset the timer
  const resetTimer = () => {
    setIsRunning(false);
    setRemainingSeconds(timeInSeconds);
    setTimerComplete(false);
    
    if (alarmSoundRef.current) {
      alarmSoundRef.current.pause();
      alarmSoundRef.current.currentTime = 0;
    }
  };
  
  // Adjust time with buttons
  const adjustTime = (seconds: number) => {
    const newTime = Math.max(0, Math.min(TIMER_MAX_MINUTES * 60, timeInSeconds + seconds));
    setTimeInSeconds(newTime);
  };
  
  // Handle slider change
  const handleSliderChange = (values: number[]) => {
    const newMinutes = values[0];
    setTimeInSeconds(newMinutes * 60);
  };
  
  return (
    <Card className={cn("w-full max-w-md mx-auto overflow-hidden", className)}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-xl flex items-center gap-2">
              <TimerIcon className="h-5 w-5" />
              Kitchen Timer
            </CardTitle>
            <CardDescription>Set a timer for your cooking</CardDescription>
          </div>
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => setIsMuted(!isMuted)}
            className="h-8 w-8"
          >
            {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </Button>
        </div>
      </CardHeader>

      <CardContent className="pb-2">
        {/* Timer Display */}
        <div 
          className={cn(
            "relative flex flex-col items-center justify-center rounded-full mx-auto mb-6",
            "w-48 h-48 border-8",
            timerComplete 
              ? "border-red-500 animate-pulse" 
              : isRunning 
                ? "border-orange-500" 
                : "border-orange-200 dark:border-orange-900"
          )}
        >
          {/* Progress Circle */}
          <svg className="absolute inset-0 w-full h-full -rotate-90">
            <circle
              cx="50%"
              cy="50%"
              r="43%"
              fill="none"
              stroke="currentColor"
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray="100 100"
              strokeDashoffset={100 - getProgressPercentage()}
              className={cn(
                "text-orange-500 transition-all duration-300",
                timerComplete && "text-red-500"
              )}
            />
          </svg>
          
          {/* Animations */}
          {isRunning && !timerComplete && (
            <>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-40 h-40 rounded-full border-4 border-orange-200 opacity-40 animate-ping" />
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-32 h-32 rounded-full border-4 border-orange-300 opacity-30 animate-ping animation-delay-300" />
              </div>
            </>
          )}
          
          {timerComplete && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-full h-full rounded-full bg-red-500/10 animate-ping" />
              <div className="w-3/4 h-3/4 rounded-full bg-red-500/10 animate-ping animation-delay-200" />
              <div className="w-1/2 h-1/2 rounded-full bg-red-500/10 animate-ping animation-delay-400" />
            </div>
          )}
          
          {/* Time Display */}
          <span className="text-4xl font-bold">
            {formatTime(remainingSeconds)}
          </span>
          
          <span className="text-sm text-muted-foreground mt-1">
            {isRunning 
              ? "Timer running..." 
              : timerComplete 
                ? "Time's up!" 
                : "Ready to start"}
          </span>
        </div>
        
        {/* Time Adjustment */}
        <div className="space-y-4">
          <div className="flex justify-between items-center mb-2">
            <Button 
              variant="outline" 
              size="icon" 
              onClick={() => adjustTime(-60)}
              disabled={isRunning || timeInSeconds <= 60}
            >
              <Minus className="h-4 w-4" />
            </Button>
            
            <div className="text-center">
              <span className="text-lg font-medium">
                {Math.floor(timeInSeconds / 60)} {Math.floor(timeInSeconds / 60) === 1 ? 'minute' : 'minutes'}
              </span>
            </div>
            
            <Button 
              variant="outline" 
              size="icon" 
              onClick={() => adjustTime(60)}
              disabled={isRunning || timeInSeconds >= TIMER_MAX_MINUTES * 60}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          
          <Slider
            defaultValue={[5]}
            value={[Math.floor(timeInSeconds / 60)]}
            min={1}
            max={TIMER_MAX_MINUTES}
            step={1}
            onValueChange={handleSliderChange}
            disabled={isRunning}
            className="py-2"
          />
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between pt-2">
        <Button 
          variant="outline" 
          onClick={resetTimer}
          disabled={isRunning && remainingSeconds > 0 && !timerComplete}
        >
          <RotateCcw className="h-4 w-4 mr-2" />
          Reset
        </Button>
        
        <Button 
          onClick={toggleTimer}
          className={cn(
            "transition-all min-w-28",
            timerComplete ? 
              "bg-gradient-to-r from-orange-500 to-orange-400 hover:from-orange-600 hover:to-orange-500" :
              isRunning ? 
                "bg-red-500 hover:bg-red-600" : 
                "bg-gradient-to-r from-orange-500 to-orange-400 hover:from-orange-600 hover:to-orange-500"
          )}
        >
          {timerComplete ? (
            <>
              <RotateCcw className="h-4 w-4 mr-2" />
              Restart
            </>
          ) : isRunning ? (
            <>
              <Pause className="h-4 w-4 mr-2" />
              Pause
            </>
          ) : (
            <>
              <Play className="h-4 w-4 mr-2" />
              Start
            </>
          )}
        </Button>
      </CardFooter>
      
      {/* Hidden audio elements */}
      <audio 
        ref={alarmSoundRef}
        src="/sounds/timer-alarm.mp3" 
        preload="auto"
      />
      <audio
        ref={tickSoundRef}
        src="/sounds/timer-tick.mp3"
        preload="auto"
      />
    </Card>
  );
}