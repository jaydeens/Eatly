import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    try {
      // Try to parse JSON error response
      const errorData = await res.json();
      const error = new Error(errorData.message || `${res.status}: ${res.statusText}`);
      // Attach the response data to the error object for more detailed error handling
      (error as any).response = { data: errorData, status: res.status };
      throw error;
    } catch (e) {
      // If JSON parsing fails, fallback to text
      const text = await res.text().catch(() => res.statusText);
      const error = new Error(`${res.status}: ${text}`);
      (error as any).response = { status: res.status, text };
      throw error;
    }
  }
}

export async function apiRequest<T = any>({
  url,
  method,
  data,
  on401 = 'throw',
}: {
  url: string;
  method: string;
  data?: unknown;
  on401?: UnauthorizedBehavior;
}): Promise<T> {
  try {
    console.log(`API Request: ${method} ${url}`);
    const res = await fetch(url, {
      method,
      headers: {
        ...(data ? { "Content-Type": "application/json" } : {}),
        // Add cache control to prevent caching of authenticated requests
        "Cache-Control": "no-cache, no-store, max-age=0, must-revalidate",
        "Pragma": "no-cache",
      },
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include", // Important: include cookies for session authentication
      // Add cache control at request level too
      cache: "no-cache",
    });

    // Check for redirects which often indicate auth issues
    if (res.redirected) {
      console.warn(`Request redirected from ${url} to ${res.url}`);
      // If redirected to auth page with error, throw appropriate error
      if (res.url.includes('/auth') && res.url.includes('error=')) {
        const errorParam = new URL(res.url).searchParams.get('error');
        throw new Error(`Authentication error: ${errorParam || 'unknown'}`);
      }
    }

    // Handle 401 Unauthorized based on the specified behavior
    if (res.status === 401) {
      console.log(`401 Unauthorized response for ${url}, on401=${on401}`);
      if (on401 === "returnNull") {
        return null as any;
      } else {
        throw new Error("Not authenticated");
      }
    }

    await throwIfResNotOk(res);
    
    // For 204 No Content responses
    if (res.status === 204) {
      return null as any;
    }
    
    return await res.json();
  } catch (error) {
    console.error(`API Request error for ${url}:`, error);
    throw error;
  }
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    try {
      const url = queryKey[0] as string;
      console.log(`Query function for ${url}`);
      const res = await fetch(url, {
        headers: {
          // Add cache control to prevent caching of authenticated requests
          "Cache-Control": "no-cache, no-store, max-age=0, must-revalidate",
          "Pragma": "no-cache",
        },
        credentials: "include", // Important: include cookies for session authentication
        // Add cache control at request level too
        cache: "no-cache",
      });

      // Handle redirects which often indicate auth issues
      if (res.redirected) {
        console.warn(`Query redirected from ${url} to ${res.url}`);
        // If redirected to auth page with error, throw appropriate error
        if (res.url.includes('/auth') && res.url.includes('error=')) {
          const errorParam = new URL(res.url).searchParams.get('error');
          throw new Error(`Authentication error: ${errorParam || 'unknown'}`);
        }
      }

      // Handle 401 based on the specified behavior
      if (res.status === 401) {
        console.log(`401 Unauthorized response for ${url}, unauthorizedBehavior=${unauthorizedBehavior}`);
        if (unauthorizedBehavior === "returnNull") {
          return null;
        } else {
          throw new Error("Not authenticated");
        }
      }

      await throwIfResNotOk(res);
      
      // For 204 No Content responses
      if (res.status === 204) {
        return null as any;
      }
      
      return await res.json();
    } catch (error) {
      console.error(`Query function error:`, error);
      throw error;
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
