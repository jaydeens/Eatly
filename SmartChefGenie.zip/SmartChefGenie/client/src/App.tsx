import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Preferences from "@/pages/preferences";
import Account from "@/pages/account";
import Nutrition from "@/pages/nutrition";
import Health from "@/pages/health";
import EatlyChatPage from "@/pages/chat";
import AuthPage from "@/pages/auth";
import SavedRecipes from "@/pages/saved-recipes";
import CookingPage from "@/pages/cooking";
import AchievementsPage from "@/pages/achievements";
import MainLayout from "@/components/layouts/main-layout";
import { AuthProvider } from "@/hooks/use-auth";
import { ThemeProvider } from "@/providers/theme-provider";
import { HelmetProvider } from 'react-helmet-async';

import { ProtectedRoute } from "@/components/protected-route";

// Router with authentication requirements
function Router() {
  return (
    <Switch>
      <Route path="/auth">
        <AuthPage />
      </Route>
      
      <ProtectedRoute path="/">
        <MainLayout>
          <Home />
        </MainLayout>
      </ProtectedRoute>
      
      <ProtectedRoute path="/saved-recipes">
        <MainLayout>
          <SavedRecipes />
        </MainLayout>
      </ProtectedRoute>
      
      <ProtectedRoute path="/preferences">
        <MainLayout>
          <Preferences />
        </MainLayout>
      </ProtectedRoute>
      
      <ProtectedRoute path="/nutrition">
        <MainLayout>
          <Nutrition />
        </MainLayout>
      </ProtectedRoute>
      
      <ProtectedRoute path="/account">
        <MainLayout>
          <Account />
        </MainLayout>
      </ProtectedRoute>
      
      <ProtectedRoute path="/chat">
        <MainLayout>
          <EatlyChatPage />
        </MainLayout>
      </ProtectedRoute>
      
      <ProtectedRoute path="/health">
        <MainLayout>
          <Health />
        </MainLayout>
      </ProtectedRoute>
      
      <ProtectedRoute path="/cooking">
        <CookingPage />
      </ProtectedRoute>
      
      <ProtectedRoute path="/achievements">
        <MainLayout>
          <AchievementsPage />
        </MainLayout>
      </ProtectedRoute>
      
      <Route path="*">
        <MainLayout>
          <NotFound />
        </MainLayout>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <HelmetProvider>
        <ThemeProvider>
          <AuthProvider>
            <Router />
            <Toaster />
          </AuthProvider>
        </ThemeProvider>
      </HelmetProvider>
    </QueryClientProvider>
  );
}

export default App;
