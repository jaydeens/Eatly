import { useState } from "react";

export type DietaryFilter = {
  name: string;
  active: boolean;
  icon: string;
};

export type CuisineType = {
  name: string;
  active: boolean;
};

export function useIngredients() {
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [cuisineTypes, setCuisineTypes] = useState<CuisineType[]>([
    { name: "Italian", active: false },
    { name: "Mexican", active: false },
    { name: "Chinese", active: false },
    { name: "Japanese", active: false },
    { name: "Indian", active: false },
    { name: "Thai", active: false },
    { name: "Mediterranean", active: false },
    { name: "American", active: false },
    { name: "Korean", active: false },
    { name: "French", active: false },
    { name: "Middle Eastern", active: false }
  ]);
  const [dietaryFilters, setDietaryFilters] = useState<DietaryFilter[]>([
    { name: "Vegetarian", active: false, icon: "leaf" },
    { name: "Vegan", active: false, icon: "plant" },
    { name: "Gluten-Free", active: false, icon: "wheat-off" },
    { name: "Dairy-Free", active: false, icon: "milk-off" },
    { name: "Low-Carb", active: false, icon: "bread-off" },
    { name: "Low-Calorie", active: false, icon: "scale" },
    { name: "High-Protein", active: false, icon: "meat" },
    { name: "Nut-Free", active: false, icon: "allergy" }
  ]);

  const addIngredient = (ingredient: string) => {
    if (ingredient.trim() !== "" && !ingredients.includes(ingredient.trim())) {
      setIngredients([...ingredients, ingredient.trim()]);
    }
  };

  const removeIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  const toggleDietaryFilter = (index: number) => {
    const updatedFilters = [...dietaryFilters];
    updatedFilters[index].active = !updatedFilters[index].active;
    setDietaryFilters(updatedFilters);
  };

  const resetDietaryFilters = () => {
    setDietaryFilters(dietaryFilters.map(filter => ({ ...filter, active: false })));
  };
  
  const toggleCuisineType = (index: number) => {
    // Only allow one cuisine type to be active at a time
    const updatedCuisines = cuisineTypes.map((cuisine, i) => ({
      ...cuisine,
      active: i === index ? !cuisine.active : false
    }));
    setCuisineTypes(updatedCuisines);
  };
  
  const getActiveCuisine = (): string | undefined => {
    const activeCuisine = cuisineTypes.find(cuisine => cuisine.active);
    return activeCuisine?.name;
  };
  
  const resetCuisineTypes = () => {
    setCuisineTypes(cuisineTypes.map(cuisine => ({ ...cuisine, active: false })));
  };

  return {
    ingredients,
    dietaryFilters,
    cuisineTypes,
    addIngredient,
    removeIngredient,
    toggleDietaryFilter,
    resetDietaryFilters,
    toggleCuisineType,
    getActiveCuisine,
    resetCuisineTypes
  };
}
