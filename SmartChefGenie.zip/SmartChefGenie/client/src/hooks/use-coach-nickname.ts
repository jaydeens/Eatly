import { useState, useEffect } from 'react';

/**
 * Custom hook for managing the personal coach nickname
 * @returns The coach nickname and a function to update it
 */
export function useCoachNickname() {
  const [nickname, setNickname] = useState<string>('PC');
  
  // Load nickname from localStorage on mount
  useEffect(() => {
    const savedNickname = localStorage.getItem('coachNickname');
    if (savedNickname) {
      setNickname(savedNickname);
    }
  }, []);
  
  // Function to update nickname in state and localStorage
  const updateNickname = (newNickname: string) => {
    setNickname(newNickname);
    localStorage.setItem('coachNickname', newNickname);
  };
  
  return { nickname, updateNickname };
}