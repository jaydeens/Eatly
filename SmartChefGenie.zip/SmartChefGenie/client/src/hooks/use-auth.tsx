import React, { createContext, useContext, useState, useEffect } from 'react';
import { LoginFormValues, RegisterFormValues, User } from '@shared/schema';
import { useToast } from './use-toast';
import { apiRequest } from '@/lib/queryClient';

interface AuthResponseType {
  message: string;
  user: User;
  usernameChanged?: boolean;
  error?: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (data: LoginFormValues) => Promise<void>;
  register: (data: RegisterFormValues) => Promise<void>; 
  logout: () => Promise<void>;
  updateUserData: (userData: User) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const { toast } = useToast();
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true); // Start with loading true
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Check if user is already authenticated on component mount
  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const response = await apiRequest<{ user: User }>({
          method: 'GET',
          url: '/api/user'
        });
        
        if (response?.user) {
          setUser(response.user);
          setIsAuthenticated(true);
        }
      } catch (error) {
        // User is not authenticated, that's okay
        console.log('User is not authenticated');
      } finally {
        setIsLoading(false);
      }
    };
    
    checkAuthStatus();
  }, []);

  // Real login function with API call
  const login = async (data: LoginFormValues) => {
    try {
      setIsLoading(true);
      
      const response = await apiRequest<{ message: string; user: User }>({
        method: 'POST',
        url: '/api/login',
        data
      });
      
      if (response?.user) {
        setUser(response.user);
        setIsAuthenticated(true);
        
        toast({
          title: "Login successful",
          description: "Welcome back!",
        });
      } else {
        throw new Error('Login failed');
      }
    } catch (error: any) {
      console.error('Login error:', error);
      
      // Better categorized error messages
      let errorMessage = "There was a problem logging in";
      let errorTitle = "Login Failed";
      
      if (error.response) {
        // Server returned an error response with detailed information
        if (error.response.data && error.response.data.error) {
          const errorCode = error.response.data.error;
          
          if (errorCode === 'account_not_found') {
            errorTitle = "Account Not Found";
            errorMessage = error.response.data.message || "We couldn't find an account with this email address.";
          } else if (errorCode === 'invalid_credentials') {
            errorTitle = "Invalid Password";
            errorMessage = error.response.data.message || "The password you entered is incorrect.";
          } else {
            // Use server-provided message if available
            errorMessage = error.response.data.message || errorMessage;
          }
        } else if (error.response.status === 404) {
          errorTitle = "Account Not Found";
          errorMessage = "We couldn't find an account with this email address.";
        } else if (error.response.status === 401) {
          errorTitle = "Invalid Credentials";
          errorMessage = "The email or password you entered is incorrect.";
        }
      } else if (error.message) {
        // Use error message if available
        errorMessage = error.message;
      }
      
      toast({
        title: errorTitle,
        description: errorMessage,
        variant: "destructive",
        duration: 5000
      });
      
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Real register function with API call
  const register = async (data: RegisterFormValues): Promise<void> => {
    try {
      setIsLoading(true);
      
      const response = await apiRequest<{ 
        message: string; 
        user: User; 
        usernameChanged?: boolean;
        error?: string;
      }>({
        method: 'POST',
        url: '/api/register',
        data
      });
      
      if (response?.user) {
        setUser(response.user);
        setIsAuthenticated(true);
        
        // Check if the username was changed by the server
        if (response.usernameChanged) {
          toast({
            title: "Account Created",
            description: `Your account has been created. Note: Your username was changed to "${response.user.username}" as the original was already taken.`,
            duration: 5000
          });
        } else {
          toast({
            title: "Registration successful",
            description: "Welcome to Eatly!",
          });
        }
      } else {
        throw new Error(response.error || 'Registration failed: Unknown error');
      }
    } catch (error: any) {
      console.error('Registration error:', error);
      
      // Better categorized error messages
      let errorMessage = "There was an error creating your account";
      let errorTitle = "Registration Failed";
      
      if (error.response) {
        // Server returned an error response with detailed information
        if (error.response.data && error.response.data.error) {
          const errorCode = error.response.data.error;
          
          if (errorCode === 'email_exists') {
            errorTitle = "Email Already Registered";
            errorMessage = error.response.data.message || "This email is already registered. Please use a different email or try logging in.";
          } else if (errorCode === 'username_exists') {
            errorTitle = "Username Taken";
            errorMessage = error.response.data.message || "This username is already taken. Please choose a different username.";
          } else if (errorCode === 'password_validation') {
            errorTitle = "Password Requirements";
            errorMessage = error.response.data.message || "Your password doesn't meet our requirements. Please create a stronger password.";
          } else {
            // Use server-provided message if available
            errorMessage = error.response.data.message || errorMessage;
          }
        } else if (error.response.status === 409) {
          errorTitle = "Username or Email Already Exists";
          errorMessage = "This username or email is already in use. Please choose different credentials.";
        } else if (error.response.status === 400) {
          errorTitle = "Invalid Information";
          errorMessage = "Please check your information and try again.";
        } else if (error.response.status === 422) {
          errorTitle = "Validation Error";
          errorMessage = "Please make sure your password meets the requirements.";
        } else if (error.response.status === 500) {
          errorTitle = "Server Error";
          errorMessage = "Our server encountered a problem. Please try again later.";
        }
      } else if (error.message) {
        // Custom error message
        errorMessage = error.message;
      }
      
      toast({
        title: errorTitle,
        description: errorMessage,
        variant: "destructive",
        duration: 5000
      });
      
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Real logout function with API call
  const logout = async () => {
    try {
      setIsLoading(true);
      
      await apiRequest({
        method: 'POST',
        url: '/api/logout'
      });
      
      setUser(null);
      setIsAuthenticated(false);
      
      toast({
        title: "Logged out",
        description: "You have been logged out successfully",
      });
    } catch (error) {
      console.error('Logout error:', error);
      toast({
        title: "Logout failed",
        description: "There was an error logging out",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };
  
  // This function allows direct updates to the user state in the context
  // without having to call the API
  const updateUserData = (userData: User) => {
    console.log("Updating user data in context:", userData);
    setUser(userData);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated,
        login,
        register,
        logout,
        updateUserData,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// Named function to make it compatible with Fast Refresh
function useAuthHook() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

// Export the hook
export const useAuth = useAuthHook;