import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { type Recipe } from "@shared/schema";
import { type DietaryFilter, type CuisineType } from "./use-ingredients";

export function useRecipeGeneration() {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const { toast } = useToast();
  
  // Flag to determine which API to use for recipe generation
  // We'll prioritize Spoonacular, but fall back to OpenAI if needed
  const [useSpoonacular, setUseSpoonacular] = useState(true);

  const { mutate: mutateSpoonacular, isPending: isGeneratingSpoonacular } = useMutation({
    mutationFn: async (params: { ingredients: string[], dietaryFilters: DietaryFilter[], cuisineType?: string, servings?: number }) => {
      const result = await apiRequest({
        method: "POST",
        url: "/api/spoonacular/recipes", 
        data: params,
        on401: "throw"
      });
      
      if (!result.success) {
        throw new Error(result.message || "Failed to generate recipes");
      }
      
      return { result, params };
    },
    onSuccess: (response) => {
      const { result } = response;
      if (result.recipes && Array.isArray(result.recipes)) {
        setRecipes(result.recipes);
        toast({
          title: "Recipes generated!",
          description: `Found ${result.recipes.length} recipes with your ingredients.`,
          variant: "default",
        });
      } else {
        // In case the response format is unexpected
        toast({
          title: "Unexpected response",
          description: "Received an unexpected response format from the server.",
          variant: "destructive",
        });
      }
    },
    onError: (error: any, variables) => {
      console.error("Spoonacular recipe generation error:", error);
      
      // Extract meaningful error message
      let errorMessage = "Please try again later";
      
      if (error?.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error?.response?.data?.error) {
        errorMessage = error.response.data.error;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      // If Spoonacular fails, try using OpenAI as backup
      setUseSpoonacular(false);
      
      // Check for API key related errors
      if (errorMessage.includes("API key") || 
          errorMessage.includes("authentication") || 
          errorMessage.includes("Spoonacular") ||
          errorMessage.includes("not configured")) {
        
        toast({
          title: "Spoonacular API Key Issue",
          description: "Falling back to OpenAI for recipe generation...",
          variant: "default",
        });
      } else {
        toast({
          title: "Failed to generate recipes with Spoonacular",
          description: "Trying with OpenAI instead...",
          variant: "default",
        });
      }
      
      // Try with OpenAI instead
      checkOpenAIAndGenerate(variables.ingredients, variables.dietaryFilters, variables.cuisineType, variables.servings);
    },
  });
  
  const { mutate: mutateOpenAI, isPending: isGeneratingOpenAI } = useMutation({
    mutationFn: async (params: { ingredients: string[], dietaryFilters: DietaryFilter[], cuisineType?: string, servings?: number }) => {
      const result = await apiRequest({
        method: "POST",
        url: "/api/recipes/generate", 
        data: params,
        on401: "throw"
      });
      
      if (!result.success) {
        throw new Error(result.message || "Failed to generate recipes");
      }
      
      return { result, params };
    },
    onSuccess: (response) => {
      const { result } = response;
      if (result.recipes && Array.isArray(result.recipes)) {
        setRecipes(result.recipes);
        toast({
          title: "Recipes generated!",
          description: `Generated ${result.recipes.length} recipes with your ingredients using AI.`,
          variant: "default",
        });
      } else {
        // In case the response format is unexpected
        toast({
          title: "Unexpected response",
          description: "Received an unexpected response format from the server.",
          variant: "destructive",
        });
      }
    },
    onError: (error: any, variables) => {
      console.error("OpenAI recipe generation error:", error);
      
      // Extract meaningful error message
      let errorMessage = "Please try again later";
      
      if (error?.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error?.response?.data?.error) {
        errorMessage = error.response.data.error;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      // Check for API key related errors and provide a more user-friendly message
      if (errorMessage.includes("API key") || 
          errorMessage.includes("authentication") || 
          errorMessage.includes("OpenAI") ||
          errorMessage.includes("not configured")) {
        
        toast({
          title: "API Key Required",
          description: "Recipe generation requires a valid OpenAI API key. Please ask the application administrator to configure the API key.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Failed to generate recipes",
          description: errorMessage,
          variant: "destructive",
        });
      }
    },
  });

  const checkSpoonacularAndGenerate = async (ingredients: string[], dietaryFilters: DietaryFilter[], cuisineType?: string, servings: number = 2) => {
    try {
      // Verify Spoonacular API key is configured
      const apiKeyCheck = await apiRequest<{ success: boolean; message: string }>({
        method: "GET",
        url: "/api/spoonacular/verify",
        on401: "throw"
      });

      if (!apiKeyCheck.success) {
        toast({
          title: "Spoonacular API Key Issue",
          description: "Falling back to OpenAI for recipe generation...",
          variant: "default",
        });
        
        // Try with OpenAI instead
        setUseSpoonacular(false);
        checkOpenAIAndGenerate(ingredients, dietaryFilters, cuisineType, servings);
        return;
      }
      
      // Proceed with Spoonacular generation if API key is valid
      mutateSpoonacular({ ingredients, dietaryFilters, cuisineType, servings });
    } catch (error) {
      console.error("Spoonacular API key verification error:", error);
      
      // Try with OpenAI instead
      setUseSpoonacular(false);
      checkOpenAIAndGenerate(ingredients, dietaryFilters, cuisineType, servings);
    }
  };
  
  const checkOpenAIAndGenerate = async (ingredients: string[], dietaryFilters: DietaryFilter[], cuisineType?: string, servings: number = 2) => {
    try {
      // Verify OpenAI API key is configured
      const apiKeyCheck = await apiRequest<{ success: boolean; message: string }>({
        method: "GET",
        url: "/api/openai/verify",
        on401: "throw"
      });

      if (!apiKeyCheck.success) {
        toast({
          title: "API Key Required",
          description: "Recipe generation requires a valid OpenAI API key. Please ask the application administrator to configure the API key.",
          variant: "destructive",
        });
        return;
      }
      
      // Proceed with OpenAI generation if API key is valid
      mutateOpenAI({ ingredients, dietaryFilters, cuisineType, servings });
    } catch (error) {
      console.error("OpenAI API key verification error:", error);
      
      toast({
        title: "API Key Required",
        description: "Recipe generation requires a valid OpenAI API key. Please ask the application administrator to configure the API key.",
        variant: "destructive",
      });
    }
  };
  
  const generateRecipes = async (ingredients: string[], dietaryFilters: DietaryFilter[], cuisineType?: string, servings: number = 2) => {
    if (ingredients.length === 0) {
      toast({
        title: "No ingredients provided",
        description: "Please add at least one ingredient to generate recipes",
        variant: "destructive",
      });
      return;
    }
    
    // Choose the appropriate API based on our flag
    if (useSpoonacular) {
      checkSpoonacularAndGenerate(ingredients, dietaryFilters, cuisineType, servings);
    } else {
      checkOpenAIAndGenerate(ingredients, dietaryFilters, cuisineType, servings);
    }
  };

  return {
    recipes,
    isGenerating: isGeneratingSpoonacular || isGeneratingOpenAI,
    generateRecipes,
  };
}
