import { useEffect, useState } from "react";
import { useLocation, useRoute } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { type Recipe } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { 
  ClockIcon, 
  UsersIcon, 
  FlameIcon, 
  ChartIcon,
  CheckIcon,
  PrinterIcon,
  ShareIcon,
  BookmarkIcon,
  HomeIcon
} from "@/components/ui/icons";

export default function RecipeDetail() {
  const [match, params] = useRoute('/recipe/:id');
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [recipe, setRecipe] = useState<Recipe | null>(null);

  // Fetch recipe data
  const { data, isLoading, error } = useQuery({
    queryKey: [`/api/recipes/${params?.id}`],
    enabled: !!params?.id,
  });

  // Save recipe functionality
  const { mutate: saveRecipe } = useMutation({
    mutationFn: async (recipeToSave: Recipe) => {
      const res = await apiRequest("POST", "/api/recipes", recipeToSave);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Recipe saved!",
        description: "You can find this recipe in your saved recipes.",
        variant: "default",
      });
    },
    onError: (err) => {
      toast({
        title: "Failed to save recipe",
        description: err instanceof Error ? err.message : "Please try again later",
        variant: "destructive",
      });
    },
  });

  // Update recipe state when data is fetched
  useEffect(() => {
    if (data) {
      setRecipe(data);
    }
  }, [data]);

  // Redirect if there's an error
  useEffect(() => {
    if (error) {
      toast({
        title: "Recipe not found",
        description: "The recipe you're looking for doesn't exist or couldn't be loaded.",
        variant: "destructive",
      });
      navigate("/");
    }
  }, [error, navigate, toast]);

  // Loading state
  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mt-6">
          <Skeleton className="h-64 sm:h-72 w-full mb-6 rounded-lg" />
          <div className="flex flex-wrap gap-4 justify-between mb-6">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-14 w-24 rounded-md" />
            ))}
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-1">
              <Skeleton className="h-8 w-40 mb-4" />
              <div className="space-y-2">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <Skeleton key={i} className="h-6 w-full" />
                ))}
              </div>
            </div>
            <div className="md:col-span-2">
              <Skeleton className="h-8 w-40 mb-4" />
              <div className="space-y-6">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="space-y-2">
                    <Skeleton className="h-6 w-full" />
                    <Skeleton className="h-6 w-11/12" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  // No recipe state
  if (!recipe && !isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
        <h2 className="text-2xl font-display font-bold mb-4">Recipe Not Found</h2>
        <p className="text-gray-600 mb-6">The recipe you're looking for doesn't exist or couldn't be loaded.</p>
        <Button onClick={() => navigate("/")} className="inline-flex items-center">
          <HomeIcon className="mr-2" size={16} />
          Return Home
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {recipe && (
        <div className="mt-6">
          <div className="relative h-64 sm:h-72 bg-gray-200 rounded-t-lg overflow-hidden">
            <img
              src={recipe.image}
              className="w-full h-full object-cover"
              alt={recipe.title}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
              <div className="p-6">
                <h2 className="text-white text-2xl sm:text-3xl font-display font-bold">
                  {recipe.title}
                </h2>
                <div className="flex flex-wrap gap-2 mt-2">
                  {recipe.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-white/20 text-white backdrop-blur-sm"
                    >
                      <span>{tag}</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-b-lg shadow-md p-6">
            <div className="flex flex-wrap gap-4 justify-between mb-6">
              <div className="flex items-center">
                <ClockIcon className="text-primary-500 mr-2" size={20} />
                <div>
                  <div className="font-medium text-gray-900">{recipe.time}</div>
                  <div className="text-xs text-gray-500">Cooking Time</div>
                </div>
              </div>
              <div className="flex items-center">
                <UsersIcon className="text-primary-500 mr-2" size={20} />
                <div>
                  <div className="font-medium text-gray-900">{`${recipe.servings} ${
                    recipe.servings > 1 ? "servings" : "serving"
                  }`}</div>
                  <div className="text-xs text-gray-500">Yield</div>
                </div>
              </div>
              <div className="flex items-center">
                <FlameIcon className="text-primary-500 mr-2" size={20} />
                <div>
                  <div className="font-medium text-gray-900">{`${recipe.calories} kcal`}</div>
                  <div className="text-xs text-gray-500">Per Serving</div>
                </div>
              </div>
              <div className="flex items-center">
                <ChartIcon className="text-primary-500 mr-2" size={20} />
                <div>
                  <div className="font-medium text-gray-900">{`${recipe.difficulty}`}</div>
                  <div className="text-xs text-gray-500">Difficulty</div>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="md:col-span-1">
                <h3 className="text-lg font-display font-bold mb-4 text-gray-900">Ingredients</h3>
                <ul className="space-y-2">
                  {recipe.ingredients.map((ingredient, i) => (
                    <li key={i} className="flex items-start">
                      <span className="h-5 w-5 mt-0.5 rounded-full bg-primary-50 text-primary-700 flex items-center justify-center">
                        <CheckIcon size={12} />
                      </span>
                      <span className="ml-2 text-gray-700">{ingredient}</span>
                    </li>
                  ))}
                </ul>

                <h3 className="text-lg font-display font-bold mb-4 mt-8 text-gray-900">
                  Nutrition Information
                </h3>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Calories</span>
                      <span className="font-medium text-gray-900">{`${recipe.calories} kcal`}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Protein</span>
                      <span className="font-medium text-gray-900">{`${recipe.nutrition.protein}g`}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Carbohydrates</span>
                      <span className="font-medium text-gray-900">{`${recipe.nutrition.carbs}g`}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Fat</span>
                      <span className="font-medium text-gray-900">{`${recipe.nutrition.fat}g`}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Fiber</span>
                      <span className="font-medium text-gray-900">{`${recipe.nutrition.fiber}g`}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="md:col-span-2">
                <h3 className="text-lg font-display font-bold mb-4 text-gray-900">Instructions</h3>
                <ol className="space-y-6">
                  {recipe.instructions.map((step, i) => (
                    <li key={i} className="relative pl-8">
                      <div className="absolute left-0 top-0 flex items-center justify-center h-6 w-6 rounded-full bg-primary-500 text-white text-sm font-medium">
                        <span>{i + 1}</span>
                      </div>
                      <p className="text-gray-700">{step}</p>
                    </li>
                  ))}
                </ol>

                <div className="mt-8">
                  <h3 className="text-lg font-display font-bold mb-4 text-gray-900">
                    Chef's Tips
                  </h3>
                  <div className="bg-primary-50 rounded-lg p-4 border border-primary-100">
                    <p className="text-gray-700">{recipe.tips}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 flex justify-between items-center flex-wrap gap-4">
              <Button
                onClick={() => navigate("/")}
                className="relative group overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-orange-400 group-hover:from-orange-500 group-hover:to-orange-300"></div>
                <div className="relative z-10 flex items-center text-white">
                  <HomeIcon className="mr-2" size={16} />
                  Back to Recipes
                </div>
              </Button>
              
              <div className="flex space-x-3">
                <Button
                  variant="outline"
                  className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
                  onClick={() => window.print()}
                >
                  <PrinterIcon className="mr-2" size={16} />
                  Print
                </Button>
                <Button
                  variant="outline"
                  className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
                >
                  <ShareIcon className="mr-2" size={16} />
                  Share
                </Button>
                <Button 
                  className="relative group overflow-hidden"
                  onClick={() => saveRecipe(recipe)}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-orange-400 group-hover:from-orange-500 group-hover:to-orange-300"></div>
                  <div className="relative z-10 flex items-center text-white">
                    <BookmarkIcon className="mr-2" size={16} />
                    Save Recipe
                  </div>
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
