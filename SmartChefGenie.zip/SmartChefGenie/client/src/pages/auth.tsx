import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { LoginForm } from '@/components/auth/login-form';
import { RegisterForm } from '@/components/auth/register-form';
import { ChefHatIcon, MoonIcon, SunIcon } from '@/components/ui/icons';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useTheme } from '@/providers/theme-provider';

type AuthView = 'login' | 'register';

export default function AuthPage() {
  const [view, setView] = useState<AuthView>('login');
  const [, navigate] = useLocation();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();
  
  // Check for error params in URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const error = params.get('error');
    
    if (error) {
      let errorMessage = "Authentication failed.";
      
      if (error === 'provider_not_configured') {
        errorMessage = "OAuth provider is not properly configured. Please contact the administrator.";
      } else if (error === 'provider_not_supported') {
        errorMessage = "This OAuth provider is not supported.";
      } else if (error === 'oauth_failed') {
        errorMessage = "Authentication failed. Please try again or use another sign-in method.";
      } else if (error === 'oauth_missing_params') {
        errorMessage = "Missing required OAuth parameters. Please try again.";
      }
      
      toast({
        title: "Authentication Error",
        description: errorMessage,
        variant: "destructive",
      });
      
      // Remove the error from the URL to prevent showing the error again on page refresh
      window.history.replaceState({}, document.title, '/auth');
    }
  }, [toast]);
  
  useEffect(() => {
    // Redirect if user is already authenticated
    if (isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);
  
  const handleSuccess = () => {
    navigate('/');
  };
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row relative">
      {/* Theme Toggle Button */}
      <button 
        onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
        className="absolute top-4 right-4 p-2 rounded-full bg-card border border-border flex items-center justify-center shadow-lg z-50"
        aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
      >
        {theme === 'dark' ? (
          <SunIcon className="text-orange-500" size={20} />
        ) : (
          <MoonIcon className="text-orange-500" size={20} />
        )}
      </button>
      
      {/* Left section (features/branding) - hidden on mobile */}
      <div className="hidden md:block md:w-1/2 relative overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 bg-orange-50 pattern-food opacity-10"></div>
        
        {/* Background image overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-orange-500/90 to-orange-600/90"></div>
        
        {/* Content */}
        <div className="relative h-full flex flex-col items-center justify-center p-12 text-white z-10">
          <div className="max-w-md mx-auto flex flex-col items-center text-center">
            {/* Decorative image elements */}
            <div className="absolute -top-12 -left-12 w-48 h-48 rounded-full bg-orange-300/20 backdrop-blur-sm flex items-center justify-center overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=200&h=200&q=80" 
                alt=""
                className="w-40 h-40 object-cover rounded-full opacity-75"
              />
            </div>
            
            <div className="absolute -bottom-8 -right-8 w-40 h-40 rounded-full bg-orange-300/20 backdrop-blur-sm flex items-center justify-center overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1511690743698-d9d85f2fbf38?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=200&h=200&q=80" 
                alt=""
                className="w-32 h-32 object-cover rounded-full opacity-75"
              />
            </div>
            
            <div className="absolute top-1/4 -right-20 w-36 h-36 rounded-full bg-orange-300/20 backdrop-blur-sm flex items-center justify-center overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=200&h=200&q=80" 
                alt=""
                className="w-32 h-32 object-cover rounded-full opacity-75"
              />
            </div>
            
            <div className="rounded-full bg-white/10 backdrop-blur-md p-6">
              <ChefHatIcon size={80} className="text-white" />
            </div>
            
            <h1 className="text-4xl font-bold mt-8 mb-4">Welcome to <span className="text-black">Eat</span><span className="text-orange-300">ly</span></h1>
            <p className="text-xl mb-10 text-white/90">Your AI-powered Personal Coach (PC)</p>
            
            <div className="space-y-8 text-left w-full max-w-sm backdrop-blur-sm bg-white/10 p-6 rounded-xl">
              <div className="flex items-start">
                <div className="flex-shrink-0 bg-white/20 rounded-full p-2 mr-4">
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold">Smart Recipe Suggestions</h3>
                  <p className="opacity-90 text-sm mt-1">Get personalized recipes based on ingredients you already have</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 bg-white/20 rounded-full p-2 mr-4">
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path>
                    <polyline points="9 22 9 12 15 12 15 22"></polyline>
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold">Camera Ingredient Detection</h3>
                  <p className="opacity-90 text-sm mt-1">Simply scan your pantry or fridge to identify ingredients</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 bg-white/20 rounded-full p-2 mr-4">
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M12 2.69l5.66 5.66a8 8 0 11-11.31 0z"></path>
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold">Dietary Preferences</h3>
                  <p className="opacity-90 text-sm mt-1">Set your dietary needs and get perfectly tailored recipes</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Food pattern background styling - no JSX required */}
      <style dangerouslySetInnerHTML={{
        __html: `
        .pattern-food {
          background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23e76f51' fill-opacity='0.2'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        }
      `
      }} />
      
      {/* Right section (auth forms) */}
      <div className="flex-1 flex flex-col items-center justify-center bg-background p-6 sm:p-10">
        <div className="max-w-md w-full">
          {/* Only show logo on mobile where left panel is hidden */}
          <div className="md:hidden flex flex-col items-center mb-8">
            <div className="rounded-full bg-orange-100 dark:bg-orange-950/30 p-4 mb-4">
              <ChefHatIcon size={48} className="text-orange-500" />
            </div>
            <h1 className="text-3xl font-bold text-center">
              <span className="dark:text-white text-black">Eat</span><span className="text-orange-500">ly</span>
            </h1>
            <p className="text-muted-foreground text-center mt-2">
              AI-powered meal suggestions
            </p>
          </div>
          
          <div className="bg-card rounded-xl shadow-sm border border-border p-6">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-foreground">
                {view === 'login' ? 'Sign in to your account' : 'Create your account'}
              </h2>
              <p className="mt-2 text-muted-foreground text-sm">
                {view === 'login' ? (
                  <>
                    New to <span className="dark:text-white text-black">Eat</span><span className="text-orange-500">ly</span>?{' '}
                    <button
                      type="button"
                      className="font-medium text-orange-600 hover:text-orange-500"
                      onClick={() => setView('register')}
                    >
                      Create an account
                    </button>
                  </>
                ) : (
                  <>
                    Already have an account?{' '}
                    <button
                      type="button"
                      className="font-medium text-orange-600 hover:text-orange-500"
                      onClick={() => setView('login')}
                    >
                      Sign in
                    </button>
                  </>
                )}
              </p>
            </div>
            
            {view === 'login' ? (
              <LoginForm 
                onSuccess={handleSuccess} 
                onRegisterClick={() => setView('register')} 
              />
            ) : (
              <RegisterForm 
                onSuccess={handleSuccess} 
                onLoginClick={() => setView('login')} 
              />
            )}
          </div>
          
          <div className="mt-8 text-center text-sm text-muted-foreground">
            By continuing, you agree to <span className="dark:text-white text-black">Eat</span><span className="text-orange-600">ly</span>'s{' '}
            <a href="#" className="text-orange-600 hover:text-orange-500">
              Terms of Service
            </a>{' '}
            and{' '}
            <a href="#" className="text-orange-600 hover:text-orange-500">
              Privacy Policy
            </a>
          </div>
          
          <div className="mt-6 text-center">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/')}
              className="text-muted-foreground hover:text-foreground"
            >
              ← Back to home
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}