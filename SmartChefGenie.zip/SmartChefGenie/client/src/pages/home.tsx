import { useState, useEffect, useRef } from "react";
import IngredientInput from "@/components/ingredient-input";
import RecipeGrid from "@/components/recipe-grid";
import RecipeDetailModal from "@/components/recipe-detail-modal";
import CameraModal from "@/components/camera-modal";
import { useIngredients } from "@/hooks/use-ingredients";
import { useRecipeGeneration } from "@/hooks/use-recipe-generation";
import { type Recipe } from "@shared/schema";
import { ChefHatIcon, WandIcon, LeafIcon, CameraIcon, SaladIcon, SparklesIcon } from "@/components/ui/icons";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function Home() {
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [firstLoad, setFirstLoad] = useState(true);
  const [servings, setServings] = useState(2);
  
  const { 
    ingredients, 
    addIngredient, 
    removeIngredient,
    dietaryFilters,
    toggleDietaryFilter,
    resetDietaryFilters,
    cuisineTypes,
    toggleCuisineType,
    getActiveCuisine
  } = useIngredients();
  
  const {
    recipes,
    isGenerating,
    generateRecipes
  } = useRecipeGeneration();
  
  const { user } = useAuth();

  // Once recipes are generated, mark first load as false
  useEffect(() => {
    if (recipes.length > 0 && firstLoad) {
      setFirstLoad(false);
    }
  }, [recipes, firstLoad]);

  const handleScanComplete = (scannedIngredients: string[]) => {
    for (const ingredient of scannedIngredients) {
      addIngredient(ingredient);
    }
    setIsScanning(false);
  };

  const handleViewRecipe = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
  };

  const handleGenerateRecipes = () => {
    const activeCuisine = getActiveCuisine();
    generateRecipes(ingredients, dietaryFilters, activeCuisine, servings);
    setFirstLoad(false);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  
  // Demo data for recipe imagery
  const foodImageUrls = [
    "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1760&q=80",
    "https://images.unsplash.com/photo-1504674900247-0877df9cc836?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80",
    "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80",
    "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1828&q=80",
  ];

  // Particle animation elements for AI effect
  const particleClasses = [
    "animate-float-1 bg-orange-500/30 dark:bg-orange-600/20",
    "animate-float-2 bg-orange-400/20 dark:bg-orange-500/15",
    "animate-float-3 bg-orange-300/15 dark:bg-orange-400/10",
    "animate-float-4 bg-orange-200/10 dark:bg-orange-300/10",
    "animate-float-5 bg-orange-100/10 dark:bg-orange-200/5"
  ];

  return (
    <main className="flex-grow bg-background relative overflow-hidden">
      {/* AI Particle Effects */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {particleClasses.map((cls, i) => (
          <div 
            key={i}
            className={cn(
              "absolute rounded-full opacity-70 blur-xl",
              cls,
              i % 2 === 0 ? "w-72 h-72" : "w-96 h-96"
            )}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              transform: `translate(-50%, -50%)`
            }}
          />
        ))}
      </div>

      {/* Hero Section */}
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-600/20 to-orange-400/10 dark:from-orange-950/30 dark:to-orange-800/10 backdrop-blur-sm pointer-events-none"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20 relative">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="relative z-10">
              <div className="inline-flex items-center mb-6 bg-white/10 dark:bg-black/30 backdrop-blur-md rounded-full pl-1.5 pr-4 py-1.5">
                <div className="bg-gradient-to-r from-orange-500 to-orange-400 rounded-full p-2 mr-3 shadow-md">
                  <ChefHatIcon size={20} className="text-white" />
                </div>
                <div className="flex items-center">
                  <span className="animate-pulse-ring bg-green-500 h-2 w-2 rounded-full mr-2"></span>
                  <p className="text-sm font-medium text-foreground">
                    {user ? `Welcome back, ${user.name || user.username}!` : 'AI-Powered Chef Assistant'}
                  </p>
                </div>
              </div>
              
              <h1 className="text-4xl md:text-6xl font-bold mb-4 leading-tight">
                <span className="ai-gradient-text">Intelligent</span> recipe <br className="hidden sm:block" />suggestions
              </h1>
              
              <p className="text-lg text-foreground/80 dark:text-foreground/70 mb-8 max-w-lg">
                Eatly uses advanced artificial intelligence to transform your ingredients into personalized culinary creations.
              </p>
              
              <div className="flex gap-3 flex-wrap mb-6">
                <div className="inline-flex items-center gap-1.5 bg-white/10 dark:bg-black/30 backdrop-blur-md rounded-full px-3 py-1.5 text-sm border border-orange-500/20">
                  <WandIcon size={14} className="text-orange-500" />
                  <span>AI Recipe Generation</span>
                </div>
                <div className="inline-flex items-center gap-1.5 bg-white/10 dark:bg-black/30 backdrop-blur-md rounded-full px-3 py-1.5 text-sm border border-orange-500/20">
                  <CameraIcon size={14} className="text-orange-500" />
                  <span>Ingredient Detection</span>
                </div>
                <div className="inline-flex items-center gap-1.5 bg-white/10 dark:bg-black/30 backdrop-blur-md rounded-full px-3 py-1.5 text-sm border border-orange-500/20">
                  <LeafIcon size={14} className="text-orange-500" />
                  <span>Dietary Analysis</span>
                </div>
              </div>
              
              <Button 
                onClick={() => {
                  const recipeSection = document.querySelector('.ingredient-input-section');
                  if (recipeSection) {
                    recipeSection.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                className="bg-gradient-to-r from-orange-500 to-orange-400 hover:from-orange-600 hover:to-orange-500 text-white shadow-lg"
                size="lg"
              >
                Start Cooking
              </Button>
            </div>
            
            <div className="hidden md:block relative">
              <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-orange-400/5 dark:from-orange-950/20 dark:to-orange-800/10 rounded-3xl blur-2xl transform -rotate-6 scale-105"></div>
              
              <div className="relative grid grid-cols-2 gap-6">
                {foodImageUrls.map((url, i) => (
                  <div 
                    key={i} 
                    className={cn(
                      "rounded-2xl overflow-hidden shadow-xl transform transition-all duration-500",
                      `animate-float-${(i % 5) + 1}`,
                      i % 2 ? 'translate-y-8' : ''
                    )}
                  >
                    <div className="relative group">
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-60 transition-opacity group-hover:opacity-80" />
                      <img 
                        src={url} 
                        alt="Food" 
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute bottom-0 left-0 p-3">
                        <div className="text-xs text-white/70 mb-1">AI Generated</div>
                        <div className="text-sm font-medium text-white">Recipe #{i+1}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="absolute -bottom-6 -right-6 bg-card rounded-xl shadow-xl p-4 w-52 border border-orange-500/20 backdrop-blur-lg dark:bg-black/50">
                <div className="flex items-center gap-2 mb-2">
                  <div className="relative">
                    <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                    <div className="absolute inset-0 w-3 h-3 bg-green-500 rounded-full animate-ping opacity-75"></div>
                  </div>
                  <p className="text-xs font-medium ai-gradient-text">AI-Powered Assistant</p>
                </div>
                <p className="text-sm text-foreground/70">Eatly adapts to your tastes and preferences for smarter cooking suggestions</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* AI Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 ai-gradient-text">Powered by Advanced AI</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Eatly combines cutting-edge artificial intelligence with culinary expertise
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {/* AI Feature Card 1 */}
          <div className="bg-card dark:bg-black/40 backdrop-blur-lg p-6 rounded-2xl shadow-lg border border-orange-500/20 relative overflow-hidden group hover:shadow-xl transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-b from-orange-500/5 to-orange-400/10 dark:from-orange-950/20 dark:to-orange-800/10 opacity-50 group-hover:opacity-80 transition-opacity"></div>
            <div className="absolute top-0 right-0 w-24 h-24 bg-orange-500/10 dark:bg-orange-600/20 rounded-full blur-2xl transform -translate-y-1/2 translate-x-1/2"></div>
            
            <div className="relative z-10">
              <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-orange-500 to-orange-400 flex items-center justify-center text-white shadow-lg mb-4">
                <SparklesIcon size={28} />
              </div>
              <h3 className="text-xl font-bold mb-3">Neural Recipe Generation</h3>
              <p className="text-muted-foreground mb-4">
                Our advanced neural networks analyze thousands of recipe combinations to create personalized dish suggestions based on your available ingredients.
              </p>
              <div className="flex items-center text-sm text-orange-500 font-medium">
                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M8 10L12 14L16 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M12 2V14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M20 16V21C20 21.5523 19.5523 22 19 22H5C4.44772 22 4 21.5523 4 21V16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                Transformative Technology
              </div>
            </div>
          </div>
          
          {/* AI Feature Card 2 */}
          <div className="bg-card dark:bg-black/40 backdrop-blur-lg p-6 rounded-2xl shadow-lg border border-orange-500/20 relative overflow-hidden group hover:shadow-xl transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-b from-orange-500/5 to-orange-400/10 dark:from-orange-950/20 dark:to-orange-800/10 opacity-50 group-hover:opacity-80 transition-opacity"></div>
            <div className="absolute top-0 right-0 w-24 h-24 bg-orange-500/10 dark:bg-orange-600/20 rounded-full blur-2xl transform -translate-y-1/2 translate-x-1/2"></div>
            
            <div className="relative z-10">
              <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-purple-500 to-blue-400 flex items-center justify-center text-white shadow-lg mb-4">
                <CameraIcon size={28} />
              </div>
              <h3 className="text-xl font-bold mb-3">Computer Vision Analysis</h3>
              <p className="text-muted-foreground mb-4">
                Our vision AI can identify ingredients from photos, making it easy to add items to your cooking inventory with just your camera.
              </p>
              <div className="flex items-center text-sm text-purple-500 font-medium">
                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="2"/>
                  <path d="M20.188 10.9343C20.5762 11.4056 20.7703 11.6412 20.7703 12C20.7703 12.3588 20.5762 12.5944 20.188 13.0657C18.7679 14.7899 15.6357 18 12 18C8.36427 18 5.23206 14.7899 3.81197 13.0657C3.42381 12.5944 3.22973 12.3588 3.22973 12C3.22973 11.6412 3.42381 11.4056 3.81197 10.9343C5.23206 9.21014 8.36427 6 12 6C15.6357 6 18.7679 9.21014 20.188 10.9343Z" stroke="currentColor" strokeWidth="2"/>
                </svg>
                Visual Intelligence
              </div>
            </div>
          </div>
          
          {/* AI Feature Card 3 */}
          <div className="bg-card dark:bg-black/40 backdrop-blur-lg p-6 rounded-2xl shadow-lg border border-orange-500/20 relative overflow-hidden group hover:shadow-xl transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-b from-orange-500/5 to-orange-400/10 dark:from-orange-950/20 dark:to-orange-800/10 opacity-50 group-hover:opacity-80 transition-opacity"></div>
            <div className="absolute top-0 right-0 w-24 h-24 bg-orange-500/10 dark:bg-orange-600/20 rounded-full blur-2xl transform -translate-y-1/2 translate-x-1/2"></div>
            
            <div className="relative z-10">
              <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-green-500 to-emerald-400 flex items-center justify-center text-white shadow-lg mb-4">
                <LeafIcon size={28} />
              </div>
              <h3 className="text-xl font-bold mb-3">Nutritional Intelligence</h3>
              <p className="text-muted-foreground mb-4">
                Our system analyzes the nutritional profile of each recipe, providing detailed health insights and tailoring suggestions to your dietary needs.
              </p>
              <div className="flex items-center text-sm text-green-500 font-medium">
                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" strokeWidth="2"/>
                  <path d="M12 7V12L15 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                Real-time Analysis
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Ingredient Input Section */}
      <div className="ingredient-input-section max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-6 relative z-10">
        <div className="bg-card dark:bg-black/40 backdrop-blur-lg p-8 rounded-3xl shadow-lg border border-orange-500/20 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-orange-500/5 to-orange-400/5 dark:from-orange-950/10 dark:to-orange-800/5"></div>
          
          <div className="relative z-10">
            <IngredientInput
              ingredients={ingredients}
              addIngredient={addIngredient}
              removeIngredient={removeIngredient}
              dietaryFilters={dietaryFilters}
              cuisineTypes={cuisineTypes}
              servings={servings}
              setServings={setServings}
              toggleDietaryFilter={toggleDietaryFilter}
              toggleCuisineType={toggleCuisineType}
              onScan={() => setIsScanning(true)}
              onGenerate={handleGenerateRecipes}
              isGenerating={isGenerating}
            />
          </div>
        </div>
      </div>
      
      {/* Ingredient Input Section - Full Width */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 relative z-10">

        {/* Recipe Generation Loading State or Recipes */}
        <div className="mt-12">
          <RecipeGrid
            recipes={recipes}
            isGenerating={isGenerating}
            firstLoad={firstLoad}
            onViewRecipe={handleViewRecipe}
            scrollToTop={scrollToTop}
          />
        </div>
      </div>

      {/* Modals */}
      {selectedRecipe && (
        <RecipeDetailModal
          recipe={selectedRecipe}
          onClose={() => setSelectedRecipe(null)}
        />
      )}

      {isScanning && (
        <CameraModal
          onClose={() => setIsScanning(false)}
          onScanComplete={handleScanComplete}
        />
      )}
    </main>
  );
}
