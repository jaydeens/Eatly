import { useState } from "react";
import { useLocation } from "wouter";
import KitchenTimer from "@/components/kitchen-timer";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  ChefHat,
  Clock,
  MessageCircle,
  Utensils,
  Check,
  ChevronLeft
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function CookingPage() {
  const [location, setLocation] = useLocation();
  const [currentTab, setCurrentTab] = useState("instructions");
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const { toast } = useToast();

  // Mock recipe data - in a real app, this would come from context or URL parameters
  const recipe = {
    id: 123,
    title: "Grilled Chicken with Roasted Vegetables",
    image: "https://images.unsplash.com/photo-1432139555190-58524dae6a55?q=80&w=600",
    cookingTime: 45,
    servings: 2,
    ingredients: [
      "2 chicken breasts",
      "1 zucchini, sliced",
      "1 red bell pepper, sliced",
      "1 yellow bell pepper, sliced",
      "1 red onion, sliced",
      "2 tablespoons olive oil",
      "2 cloves garlic, minced",
      "1 teaspoon dried oregano",
      "1 teaspoon dried thyme",
      "Salt and pepper to taste",
    ],
    instructions: [
      "Preheat the oven to 425°F (220°C).",
      "Season chicken breasts with salt, pepper, and half of the dried herbs.",
      "In a large bowl, toss the vegetables with olive oil, garlic, and remaining herbs.",
      "Place the vegetables on a baking sheet and roast for 15 minutes.",
      "Heat a grill pan over medium-high heat and cook the chicken for 6-7 minutes per side.",
      "Add the chicken to the vegetable tray and continue roasting for 10 more minutes.",
      "Check that the chicken has reached an internal temperature of 165°F (74°C).",
      "Let the chicken rest for 5 minutes before slicing.",
      "Serve the chicken with the roasted vegetables."
    ],
    nutrition: {
      calories: 420,
      protein: 38,
      carbs: 12,
      fat: 23
    }
  };

  const handleStepToggle = (index: number) => {
    setCompletedSteps(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index) 
        : [...prev, index]
    );
  };

  const handleTimerComplete = () => {
    toast({
      title: "Timer Complete!",
      description: "Your cooking timer has finished.",
      variant: "default",
    });
  };

  const handleCookingComplete = () => {
    toast({
      title: "Cooking Complete!",
      description: "Don't forget to log this meal to your nutrition tracker.",
      variant: "default",
    });
    
    // In a real app, you would navigate to the nutrition log page and pre-fill the form
    setTimeout(() => {
      setLocation("/nutrition");
    }, 2000);
  };
  
  const renderProgress = () => {
    const totalSteps = recipe.instructions.length;
    const completedStepsCount = completedSteps.length;
    const progressPercentage = Math.round((completedStepsCount / totalSteps) * 100);
    
    return (
      <div className="flex flex-col gap-2 items-center">
        <div className="w-full bg-muted rounded-full h-2.5 mt-4">
          <div 
            className="bg-gradient-to-r from-orange-500 to-orange-400 h-2.5 rounded-full transition-all duration-300" 
            style={{ width: `${progressPercentage}%` }}
          ></div>
        </div>
        <p className="text-sm text-muted-foreground">
          {completedStepsCount} of {totalSteps} steps completed ({progressPercentage}%)
        </p>
      </div>
    );
  };

  return (
    <div className="container px-4 py-6 max-w-3xl mx-auto">
      {/* Header with back button */}
      <div className="flex items-center gap-2 mb-4">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => setLocation("/")} 
          className="mr-2"
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Back
        </Button>
        
        <h1 className="text-2xl font-bold flex-1 ai-gradient-text">
          <ChefHat className="inline-block mr-2 h-6 w-6" />
          Cooking Mode
        </h1>
      </div>
      
      {/* Recipe header */}
      <Card className="mb-6">
        <CardHeader className="pb-2">
          <CardTitle>{recipe.title}</CardTitle>
          <CardDescription className="flex items-center gap-2">
            <Clock className="h-4 w-4" /> {recipe.cookingTime} minutes | 
            <Utensils className="h-4 w-4 ml-2" /> {recipe.servings} servings
          </CardDescription>
        </CardHeader>
        <CardContent className="pb-0">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <img 
              src={recipe.image} 
              alt={recipe.title} 
              className="w-full md:w-1/3 h-48 object-cover rounded-md" 
            />
            <div className="flex-1">
              <h3 className="text-lg font-semibold mb-2">Nutrition Facts (per serving)</h3>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <p className="text-sm font-medium">Calories</p>
                  <p className="text-2xl font-bold">{recipe.nutrition.calories}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Protein</p>
                  <p className="text-2xl font-bold">{recipe.nutrition.protein}g</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Carbs</p>
                  <p className="text-2xl font-bold">{recipe.nutrition.carbs}g</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Fat</p>
                  <p className="text-2xl font-bold">{recipe.nutrition.fat}g</p>
                </div>
              </div>
            </div>
          </div>
          
          {renderProgress()}
        </CardContent>
      </Card>
      
      {/* Cooking interface with tabs */}
      <Tabs 
        defaultValue="instructions" 
        value={currentTab}
        onValueChange={setCurrentTab}
        className="w-full"
      >
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="instructions" className="text-sm">
            Instructions
          </TabsTrigger>
          <TabsTrigger value="ingredients" className="text-sm">
            Ingredients
          </TabsTrigger>
          <TabsTrigger value="timer" className="text-sm">
            Timer
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="instructions" className="space-y-4">
          <div className="space-y-4">
            <h2 className="text-xl font-bold">Cooking Instructions</h2>
            <ul className="space-y-3">
              {recipe.instructions.map((step, index) => (
                <li key={index} className="flex gap-3 items-start">
                  <Button
                    variant={completedSteps.includes(index) ? "default" : "outline"}
                    size="icon"
                    className={`mt-0.5 h-6 w-6 ${
                      completedSteps.includes(index) 
                        ? "bg-green-500 hover:bg-green-600" 
                        : ""
                    }`}
                    onClick={() => handleStepToggle(index)}
                  >
                    {completedSteps.includes(index) ? (
                      <Check className="h-4 w-4" />
                    ) : (
                      <span className="text-xs">{index + 1}</span>
                    )}
                  </Button>
                  <span className={completedSteps.includes(index) ? "line-through opacity-70" : ""}>
                    {step}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </TabsContent>
        
        <TabsContent value="ingredients" className="space-y-4">
          <div className="space-y-4">
            <h2 className="text-xl font-bold">Ingredients</h2>
            <ul className="space-y-2">
              {recipe.ingredients.map((ingredient, index) => (
                <li key={index} className="flex items-start gap-2">
                  <div className="h-2 w-2 rounded-full bg-orange-500 mt-2"></div>
                  <span>{ingredient}</span>
                </li>
              ))}
            </ul>
          </div>
        </TabsContent>
        
        <TabsContent value="timer">
          <div className="space-y-4">
            <h2 className="text-xl font-bold">Kitchen Timer</h2>
            <p className="text-muted-foreground">
              Set timers for different steps of your cooking process.
            </p>
            <KitchenTimer onComplete={handleTimerComplete} />
          </div>
        </TabsContent>

        <Separator className="my-6" />
        
        <div className="flex justify-between">
          <Button 
            variant="outline" 
            onClick={() => setCurrentTab(
              currentTab === "instructions" ? "ingredients" :
              currentTab === "ingredients" ? "timer" : "instructions"
            )}
          >
            {currentTab === "timer" ? "Instructions" : currentTab === "instructions" ? "Ingredients" : "Timer"}
          </Button>
          
          <Button 
            onClick={handleCookingComplete} 
            className="bg-gradient-to-r from-orange-500 to-orange-400 hover:from-orange-600 hover:to-orange-500"
          >
            <Check className="mr-2 h-4 w-4" />
            Mark as Cooked
          </Button>
        </div>
      </Tabs>
    </div>
  );
}