import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { Award, Calendar, CheckCircle, Clock, Trophy } from 'lucide-react';
import { Helmet } from 'react-helmet-async';

// Define types for our badges and challenges
interface UserBadge {
  id: number;
  name: string;
  description: string;
  icon: string;
  category: string;
  points: number;
  tier: number | null;
  earnedAt: string; // ISO date string
  progress: number; // 0-100
}

interface Challenge {
  id: number;
  title: string;
  description: string;
  season: string;
  startDate: string; // ISO date string
  endDate: string; // ISO date string
  image: string | null;
  points: number;
  progress: number; // 0-100
  isCompleted: boolean;
}

export default function AchievementsPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('badges');

  const {
    data: userBadges,
    isLoading: isLoadingBadges,
    error: badgesError
  } = useQuery<UserBadge[]>({
    queryKey: ['/api/users', user?.id, 'badges'],
    enabled: !!user
  });

  const {
    data: userChallenges,
    isLoading: isLoadingChallenges,
    error: challengesError
  } = useQuery<Challenge[]>({
    queryKey: ['/api/users', user?.id, 'challenges'],
    enabled: !!user
  });

  const {
    data: activeChallenges,
    isLoading: isLoadingActive,
    error: activeError
  } = useQuery<Challenge[]>({
    queryKey: ['/api/challenges'],
    enabled: !!user
  });

  // Calculate stats
  const totalEarnedBadges = userBadges?.length || 0;
  const totalPoints = userBadges?.reduce((sum, badge) => sum + badge.points, 0) || 0;
  const completedChallenges = userChallenges?.filter(c => c.isCompleted).length || 0;

  const getIconComponent = (iconName: string) => {
    // Map icon names to Lucide icons
    switch (iconName) {
      case 'award':
        return <Award className="h-6 w-6" />;
      case 'trophy':
        return <Trophy className="h-6 w-6" />;
      case 'calendar':
        return <Calendar className="h-6 w-6" />;
      case 'clock':
        return <Clock className="h-6 w-6" />;
      default:
        return <Award className="h-6 w-6" />;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getBadgeColor = (category: string) => {
    switch (category.toLowerCase()) {
      case 'cooking':
        return 'bg-orange-500 hover:bg-orange-600';
      case 'nutrition':
        return 'bg-green-500 hover:bg-green-600';
      case 'health':
        return 'bg-blue-500 hover:bg-blue-600';
      case 'special':
        return 'bg-purple-500 hover:bg-purple-600';
      default:
        return 'bg-gray-500 hover:bg-gray-600';
    }
  };

  const getChallengeStatus = (challenge: Challenge) => {
    if (challenge.isCompleted) {
      return <Badge className="bg-green-500">Completed</Badge>;
    }
    
    const endDate = new Date(challenge.endDate);
    const now = new Date();
    
    if (endDate < now) {
      return <Badge className="bg-red-500">Expired</Badge>;
    }
    
    const daysLeft = Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    if (daysLeft <= 3) {
      return <Badge className="bg-orange-500">{daysLeft} days left</Badge>;
    }
    
    return <Badge className="bg-blue-500">Active</Badge>;
  };

  return (
    <div className="container px-4 py-6 max-w-6xl mx-auto">
      <Helmet>
        <title>Achievements | Eatly</title>
      </Helmet>

      <div className="flex flex-col space-y-8">
        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Achievements</h1>
          <p className="text-muted-foreground">
            Track your cooking journey and challenge progress
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 grid-cols-1 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Badges</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalEarnedBadges}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Points</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalPoints}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Challenges Completed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{completedChallenges}</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="badges" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="badges">Badges</TabsTrigger>
            <TabsTrigger value="challenges">Challenges</TabsTrigger>
          </TabsList>

          {/* Badges Tab */}
          <TabsContent value="badges" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Your Badges</h2>
            </div>

            {isLoadingBadges && (
              <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3].map((i) => (
                  <Card key={i}>
                    <CardHeader>
                      <Skeleton className="h-5 w-1/2" />
                      <Skeleton className="h-4 w-3/4" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-20 w-full" />
                    </CardContent>
                    <CardFooter>
                      <Skeleton className="h-4 w-full" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}

            {badgesError && (
              <Card className="bg-red-50">
                <CardHeader>
                  <CardTitle>Error Loading Badges</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>There was an error loading your badges. Please try again later.</p>
                </CardContent>
              </Card>
            )}

            {!isLoadingBadges && !badgesError && (
              <>
                {userBadges && userBadges.length > 0 ? (
                  <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                    {userBadges.map((badge) => (
                      <Card key={badge.id} className="overflow-hidden">
                        <CardHeader className="pb-2">
                          <div className="flex justify-between">
                            <Badge className={getBadgeColor(badge.category)}>
                              {badge.category}
                            </Badge>
                            {badge.tier && (
                              <div className="flex">
                                {Array(badge.tier).fill(0).map((_, i) => (
                                  <Trophy key={i} className="h-4 w-4 text-yellow-500" />
                                ))}
                              </div>
                            )}
                          </div>
                          <CardTitle className="flex items-center gap-2 mt-2">
                            {getIconComponent(badge.icon)}
                            <span>{badge.name}</span>
                          </CardTitle>
                          <CardDescription>{badge.description}</CardDescription>
                        </CardHeader>
                        <CardContent className="pb-2">
                          {badge.progress < 100 ? (
                            <>
                              <Progress value={badge.progress} className="h-2 mt-1" />
                              <p className="text-xs text-right mt-1 text-muted-foreground">
                                {badge.progress}% Complete
                              </p>
                            </>
                          ) : (
                            <div className="flex items-center gap-2 text-green-600 font-medium">
                              <CheckCircle className="h-5 w-5" />
                              <span>Earned on {formatDate(badge.earnedAt)}</span>
                            </div>
                          )}
                        </CardContent>
                        <CardFooter className="pt-2">
                          <p className="text-sm font-medium">
                            {badge.points} points
                          </p>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card className="bg-muted/40">
                    <CardHeader>
                      <CardTitle>No Badges Yet</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p>Complete cooking tasks and nutrition goals to earn badges!</p>
                    </CardContent>
                    <CardFooter>
                      <Button variant="outline" onClick={() => window.location.href = '/cooking'}>
                        Start Cooking
                      </Button>
                    </CardFooter>
                  </Card>
                )}
              </>
            )}
          </TabsContent>

          {/* Challenges Tab */}
          <TabsContent value="challenges" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Active Challenges</h2>
            </div>

            {isLoadingActive && (
              <div className="space-y-4">
                {[1, 2].map((i) => (
                  <Card key={i}>
                    <CardHeader>
                      <Skeleton className="h-5 w-1/2" />
                      <Skeleton className="h-4 w-3/4" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-20 w-full" />
                    </CardContent>
                    <CardFooter>
                      <Skeleton className="h-10 w-1/4" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}

            {activeError && (
              <Card className="bg-red-50">
                <CardHeader>
                  <CardTitle>Error Loading Challenges</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>There was an error loading active challenges. Please try again later.</p>
                </CardContent>
              </Card>
            )}

            {!isLoadingActive && !activeError && (
              <>
                {activeChallenges && activeChallenges.length > 0 ? (
                  <div className="space-y-4">
                    {activeChallenges.map((challenge) => (
                      <Card key={challenge.id}>
                        <CardHeader>
                          <div className="flex justify-between items-center">
                            <Badge>{challenge.season}</Badge>
                            {getChallengeStatus(challenge)}
                          </div>
                          <CardTitle className="mt-2">{challenge.title}</CardTitle>
                          <CardDescription>{challenge.description}</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>Progress</span>
                              <span>{challenge.progress}%</span>
                            </div>
                            <Progress value={challenge.progress} className="h-2" />
                            <div className="flex justify-between text-xs text-muted-foreground">
                              <span>Started: {formatDate(challenge.startDate)}</span>
                              <span>Ends: {formatDate(challenge.endDate)}</span>
                            </div>
                          </div>
                        </CardContent>
                        <CardFooter>
                          <div className="flex justify-between w-full items-center">
                            <p className="text-sm font-medium">
                              {challenge.points} points to earn
                            </p>
                            <Button size="sm" variant="outline" onClick={() => window.location.href = '/cooking'}>
                              Continue Challenge
                            </Button>
                          </div>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card className="bg-muted/40">
                    <CardHeader>
                      <CardTitle>No Active Challenges</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p>There are no active challenges right now. Check back soon!</p>
                    </CardContent>
                  </Card>
                )}
              </>
            )}

            <div className="mt-8">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Your Challenge History</h2>
              </div>

              {isLoadingChallenges && (
                <div className="mt-4 space-y-4">
                  {[1, 2].map((i) => (
                    <Card key={i}>
                      <CardHeader>
                        <Skeleton className="h-5 w-1/2" />
                      </CardHeader>
                      <CardContent>
                        <Skeleton className="h-12 w-full" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {challengesError && (
                <Card className="bg-red-50 mt-4">
                  <CardHeader>
                    <CardTitle>Error Loading Challenge History</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>There was an error loading your challenge history. Please try again later.</p>
                  </CardContent>
                </Card>
              )}

              {!isLoadingChallenges && !challengesError && (
                <>
                  {userChallenges && userChallenges.length > 0 ? (
                    <div className="mt-4 space-y-4">
                      {userChallenges.map((challenge) => (
                        <Card key={challenge.id} className={`${challenge.isCompleted ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}>
                          <CardHeader className="pb-2">
                            <div className="flex justify-between items-center">
                              <CardTitle className="text-base">{challenge.title}</CardTitle>
                              <Badge className={challenge.isCompleted ? 'bg-green-500' : 'bg-red-500'}>
                                {challenge.isCompleted ? 'Completed' : 'Not Completed'}
                              </Badge>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <div className="text-sm">
                              <p>{challenge.description}</p>
                              <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                                <span>Season: {challenge.season}</span>
                                <span>{formatDate(challenge.startDate)} - {formatDate(challenge.endDate)}</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <Card className="mt-4 bg-muted/40">
                      <CardHeader>
                        <CardTitle>No Challenge History</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p>You haven't participated in any challenges yet.</p>
                      </CardContent>
                    </Card>
                  )}
                </>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}