import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Line } from "recharts";
import { useMutation, useQuery } from "@tanstack/react-query";

import MainLayout from "@/components/layouts/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { ActivityIcon, ClockIcon, ChartIcon, TrendingUpIcon } from "@/components/ui/icons";
import { Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { ResponsiveContainer, LineChart, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";

// Define schema for weight log form
const weightLogSchema = z.object({
  weight: z.coerce
    .number()
    .positive({ message: "Weight must be a positive number" })
    .max(500, { message: "Weight seems too high" }),
  date: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: "Please provide a valid date",
  }),
});

type WeightLogFormValues = z.infer<typeof weightLogSchema>;

// Interface for weight log data
interface WeightLog {
  id: number;
  userId: number;
  weight: number;
  date: string;
  createdAt: string;
}

// Interface for health assessment data
interface HealthAssessment {
  bmi: number;
  status: string;
  weightTrend: 'gaining' | 'losing' | 'stable';
  recommendation: string;
  prediction: {
    estimatedWeightIn30Days: number;
    confidence: number;
  };
}

export default function HealthPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [currentTab, setCurrentTab] = useState("overview");

  // Get weight logs
  const { 
    data: weightLogsResponse, 
    isLoading: isLoadingLogs,
    refetch: refetchWeightLogs
  } = useQuery<{success: boolean, weightLogs: WeightLog[]}>({
    queryKey: ['/api/weight/logs'],
    enabled: !!user,
  });
  
  // Extract the actual weight logs array from the response
  const weightLogs = weightLogsResponse?.weightLogs || [];

  // Get latest weight log
  const { 
    data: latestWeightResponse,
    isLoading: isLoadingLatestWeight 
  } = useQuery<{success: boolean, weightLog: WeightLog}>({
    queryKey: ['/api/weight/latest'],
    enabled: !!user,
  });
  
  // Extract the actual latest weight log from the response
  const latestWeight = latestWeightResponse?.weightLog;

  // Get health assessment
  const { 
    data: healthAssessment,
    isLoading: isLoadingAssessment 
  } = useQuery<{ success: boolean; assessment: HealthAssessment }>({
    queryKey: ['/api/health/assessment'],
    enabled: !!user && weightLogs && weightLogs.length > 0,
  });

  // Create form for adding weight log
  const form = useForm<WeightLogFormValues>({
    resolver: zodResolver(weightLogSchema),
    defaultValues: {
      weight: latestWeight?.weight || undefined,
      date: new Date().toISOString().split('T')[0],
    }
  });

  // Mutation for adding weight log
  const weightLogMutation = useMutation({
    mutationFn: async (values: WeightLogFormValues) => {
      const response = await fetch('/api/weight/log', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(values),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to log weight');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Weight recorded",
        description: "Your weight has been successfully recorded",
      });
      form.reset({
        weight: undefined,
        date: new Date().toISOString().split('T')[0],
      });
      refetchWeightLogs();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to record weight",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  function onSubmit(values: WeightLogFormValues) {
    weightLogMutation.mutate(values);
  }

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  // Chart data preparation
  const chartData = weightLogs && weightLogs.length > 0 
    ? weightLogs.map(log => ({
        date: formatDate(log.date),
        weight: log.weight,
      })).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    : [];

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'underweight':
        return 'text-blue-500';
      case 'normal weight':
        return 'text-green-500';
      case 'overweight':
        return 'text-orange-500';
      case 'obese':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'gaining':
        return 'text-orange-500';
      case 'losing':
        return 'text-green-500';
      case 'stable':
        return 'text-blue-500';
      default:
        return 'text-gray-500';
    }
  };

  const getConfidenceBadge = (confidence: number) => {
    if (confidence >= 0.8) return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400';
    if (confidence >= 0.6) return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400';
    return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-400';
  };

  return (
    <MainLayout>
      <div className="container max-w-6xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Weight Management</h1>
              <p className="text-muted-foreground mt-1">Monitor your progress and get personalized health insights</p>
            </div>
          </div>

          <Tabs defaultValue="overview" value={currentTab} onValueChange={setCurrentTab} className="w-full">
            <TabsList className="grid grid-cols-2 mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="log">Weight Log</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base font-medium flex items-center">
                      <ActivityIcon className="mr-2 h-4 w-4 text-orange-500" />
                      Current Status
                    </CardTitle>
                    <CardDescription>Your health metrics</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingAssessment || isLoadingLatestWeight ? (
                      <div className="flex items-center justify-center py-6">
                        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                      </div>
                    ) : latestWeight ? (
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <div className="text-sm text-muted-foreground">Current Weight</div>
                          <div className="text-2xl font-bold">{latestWeight.weight} kg</div>
                          <div className="text-xs text-muted-foreground">
                            Updated on {formatDate(latestWeight.date)}
                          </div>
                        </div>
                        
                        {healthAssessment?.assessment && (
                          <>
                            <Separator />
                            <div className="space-y-2">
                              <div className="text-sm text-muted-foreground">BMI</div>
                              <div className="text-2xl font-bold">{healthAssessment.assessment.bmi.toFixed(1)}</div>
                              <div className={`text-sm font-medium ${getStatusColor(healthAssessment.assessment.status)}`}>
                                {healthAssessment.assessment.status}
                              </div>
                            </div>
                          </>
                        )}
                      </div>
                    ) : (
                      <div className="py-6 text-center">
                        <p className="text-muted-foreground">No weight data available</p>
                        <Button 
                          variant="link" 
                          className="mt-2 text-orange-500 hover:text-orange-600"
                          onClick={() => setCurrentTab("log")}
                        >
                          Log your weight
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base font-medium flex items-center">
                      <TrendingUpIcon className="mr-2 h-4 w-4 text-orange-500" />
                      Weight Trend
                    </CardTitle>
                    <CardDescription>Your weight progression</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingLogs ? (
                      <div className="flex items-center justify-center py-6">
                        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                      </div>
                    ) : weightLogs && weightLogs.length > 1 ? (
                      <div className="h-[180px] mt-2">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart
                            data={chartData}
                            margin={{ top: 5, right: 5, left: 5, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                            <XAxis 
                              dataKey="date" 
                              tick={{ fontSize: 10 }} 
                              tickFormatter={(value) => value.split(' ')[0]}
                            />
                            <YAxis domain={['dataMin - 1', 'dataMax + 1']} tick={{ fontSize: 10 }} />
                            <Tooltip />
                            <Line
                              type="monotone"
                              dataKey="weight"
                              stroke="#f97316"
                              strokeWidth={2}
                              activeDot={{ r: 6 }}
                            />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    ) : (
                      <div className="py-6 text-center">
                        <p className="text-muted-foreground">Not enough data to show trend</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Log your weight regularly to see progression
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base font-medium flex items-center">
                      <ChartIcon className="mr-2 h-4 w-4 text-orange-500" />
                      Health Assessment
                    </CardTitle>
                    <CardDescription>AI-powered insights</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingAssessment ? (
                      <div className="flex items-center justify-center py-6">
                        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                      </div>
                    ) : healthAssessment?.assessment ? (
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <div className="text-sm text-muted-foreground">Weight Trend</div>
                            <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getTrendColor(healthAssessment.assessment.weightTrend)}`}>
                              {healthAssessment.assessment.weightTrend}
                            </span>
                          </div>
                          <p className="text-sm">{healthAssessment.assessment.recommendation}</p>
                        </div>
                        
                        <Separator />
                        
                        <div className="space-y-2">
                          <div className="text-sm text-muted-foreground">30-Day Prediction</div>
                          <div className="text-2xl font-bold">
                            {healthAssessment.assessment.prediction.estimatedWeightIn30Days.toFixed(1)} kg
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getConfidenceBadge(healthAssessment.assessment.prediction.confidence)}`}>
                              {(healthAssessment.assessment.prediction.confidence * 100).toFixed(0)}% confidence
                            </span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="py-6 text-center">
                        <p className="text-muted-foreground">Not enough data for assessment</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Log your weight regularly to get health insights
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {healthAssessment?.assessment && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Personalized Health Insights</CardTitle>
                    <CardDescription>
                      Based on your weight history and trends
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <h3 className="font-medium">Health Status</h3>
                      <p>
                        Your BMI of {healthAssessment.assessment.bmi.toFixed(1)} puts you in the <span className={`font-medium ${getStatusColor(healthAssessment.assessment.status)}`}>{healthAssessment.assessment.status}</span> category.
                      </p>
                      <p>
                        Your weight trend shows you are <span className={`font-medium ${getTrendColor(healthAssessment.assessment.weightTrend)}`}>{healthAssessment.assessment.weightTrend}</span> weight.
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <h3 className="font-medium">Recommendation</h3>
                      <p>{healthAssessment.assessment.recommendation}</p>
                    </div>
                    
                    <div className="space-y-2">
                      <h3 className="font-medium">30-Day Prediction</h3>
                      <p>
                        Based on your current trend, your estimated weight in 30 days will be approximately <span className="font-medium">{healthAssessment.assessment.prediction.estimatedWeightIn30Days.toFixed(1)} kg</span>.
                      </p>
                      <p className="text-sm text-muted-foreground">
                        This prediction has a confidence level of {(healthAssessment.assessment.prediction.confidence * 100).toFixed(0)}%, which means it should be used as a general guideline rather than an exact forecast.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="log" className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Log Your Weight</CardTitle>
                    <CardDescription>Keep track of your weight journey</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                          control={form.control}
                          name="weight"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Weight (kg)</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  step="0.1"
                                  placeholder="Enter your weight in kg"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                Enter your current weight in kilograms
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="date"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Date</FormLabel>
                              <FormControl>
                                <Input
                                  type="date"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                Date of measurement
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button 
                          type="submit"
                          className="w-full"
                          disabled={weightLogMutation.isPending}
                        >
                          {weightLogMutation.isPending ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Recording...
                            </>
                          ) : (
                            <>Record Weight</>
                          )}
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <div>
                      <CardTitle className="text-lg">Weight History</CardTitle>
                      <CardDescription>Your recorded weight over time</CardDescription>
                    </div>
                    {!isLoadingLogs && weightLogs && weightLogs.length > 0 && (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => refetchWeightLogs()}
                      >
                        Refresh
                      </Button>
                    )}
                  </CardHeader>
                  <CardContent>
                    {isLoadingLogs ? (
                      <div className="flex items-center justify-center py-6">
                        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                      </div>
                    ) : weightLogs && weightLogs.length > 0 ? (
                      <div className="space-y-4">
                        {weightLogs
                          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                          .map((log) => (
                            <div key={log.id} className="flex items-center justify-between border-b border-border pb-3 last:border-0 last:pb-0 pt-1">
                              <div className="flex items-center gap-3">
                                <ClockIcon className="h-5 w-5 text-orange-500" />
                                <div>
                                  <div className="font-medium">{formatDate(log.date)}</div>
                                  <div className="text-sm text-muted-foreground">
                                    {new Date(log.createdAt).toLocaleTimeString('en-US', {
                                      hour: '2-digit',
                                      minute: '2-digit',
                                    })}
                                  </div>
                                </div>
                              </div>
                              <div className="text-xl font-semibold">
                                {log.weight} <span className="text-sm font-normal text-muted-foreground">kg</span>
                              </div>
                            </div>
                          ))}
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-10 text-center">
                        <ActivityIcon className="h-12 w-12 text-muted-foreground mb-3" />
                        <h3 className="text-lg font-medium mb-1">No weight logs yet</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          Start tracking your weight to see your progress over time
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </MainLayout>
  );
}