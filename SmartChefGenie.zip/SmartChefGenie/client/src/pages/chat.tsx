import React, { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ChefHatIcon } from "@/components/ui/icons";
import { Separator } from "@/components/ui/separator";
import { useCoachNickname } from "@/hooks/use-coach-nickname";

type ChatMessage = {
  role: 'user' | 'assistant' | 'system';
  content: string;
};

type ChatTopic = 'nutrition' | 'recipes' | 'diet-plans' | 'lifestyle';

export default function EatlyChatPage() {
  const { nickname } = useCoachNickname();
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      content: `Hello! I'm your ${nickname}. How can I help you today? You can ask me about recipes, nutrition advice, meal planning, dietary questions, or anything food-related!`
    }
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [sendingMessage, setSendingMessage] = useState(false);
  const [activeTopic, setActiveTopic] = useState<ChatTopic>('nutrition');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Suggestions for different topics
  const suggestions = {
    'nutrition': [
      "How many calories are in an avocado?",
      "What foods are high in vitamin D?",
      "Is dark chocolate healthy?",
      "What's the nutritional difference between white and brown rice?"
    ],
    'recipes': [
      "I have chicken, rice, and broccoli. What can I make?",
      "What's a quick vegan dinner recipe?",
      "How do I make a good pasta sauce from scratch?",
      "Suggest a healthy breakfast that I can prep the night before."
    ],
    'diet-plans': [
      "What's a good meal plan for weight loss?",
      "How can I build a balanced vegetarian diet?",
      "What should I eat to build muscle?",
      "Help me plan a low-carb diet for the week."
    ],
    'lifestyle': [
      "How can I maintain healthy eating habits while traveling?",
      "What foods help with better sleep?",
      "How do I balance my diet as a busy professional?",
      "What kind of diet helps with reducing stress?"
    ]
  };

  useEffect(() => {
    // Scroll to bottom of chat when messages change
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages]);

  const handleSendMessage = async () => {
    if (!newMessage.trim() || sendingMessage) return;

    try {
      setSendingMessage(true);
      
      // Add user message to chat
      const userMessage: ChatMessage = { role: 'user', content: newMessage };
      const updatedMessages = [...chatMessages, userMessage];
      setChatMessages(updatedMessages);
      setNewMessage('');

      // Verify OpenAI API key is configured 
      const apiKeyCheck = await apiRequest<{ success: boolean; message: string }>({
        method: "GET",
        url: "/api/openai/verify"
      });

      if (!apiKeyCheck.success) {
        throw new Error(apiKeyCheck.message || "OpenAI API key is not properly configured");
      }

      // Call API to get AI response
      const result = await apiRequest<{ success: boolean; message: ChatMessage }>({
        method: "POST",
        url: "/api/food/chat",
        data: { messages: updatedMessages }
      });

      if (result?.message) {
        // Process the message content to replace button placeholder with actual button
        const processedMessage = {
          ...result.message,
          content: result.message.content.replace(
            '<RecipeGeneratorButton />',
            '<button class="inline-flex items-center px-3 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors" onclick="window.location.href=\'/#recipe-generation\'">Go to Recipe Generator</button>'
          )
        };
        setChatMessages([...updatedMessages, processedMessage]);
      } else {
        throw new Error("Failed to get response from AI");
      }
    } catch (error) {
      toast({
        title: "Chat Error",
        description: (error as Error).message || "Failed to send message",
        variant: "destructive",
      });
    } finally {
      setSendingMessage(false);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setNewMessage(suggestion);
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-4xl">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-full bg-gradient-to-br from-orange-400 to-orange-600">
          <ChefHatIcon className="h-8 w-8 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold">{nickname}</h1>
          <p className="text-muted-foreground">Your personal culinary and nutrition expert</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left sidebar with chat topics on larger screens */}
        <Card className="hidden lg:block">
          <CardHeader>
            <CardTitle>Chat Topics</CardTitle>
            <CardDescription>Select a topic to get specialized assistance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <button
                onClick={() => setActiveTopic('nutrition')}
                className={`w-full text-left px-4 py-3 rounded-lg transition ${
                  activeTopic === 'nutrition'
                    ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/20 dark:text-orange-400'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                <div className="font-medium">Nutrition</div>
                <div className="text-sm text-muted-foreground">Food values, nutrients, health facts</div>
              </button>
              
              <button
                onClick={() => setActiveTopic('recipes')}
                className={`w-full text-left px-4 py-3 rounded-lg transition ${
                  activeTopic === 'recipes'
                    ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/20 dark:text-orange-400'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                <div className="font-medium">Recipes</div>
                <div className="text-sm text-muted-foreground">Cooking ideas, ingredients, techniques</div>
              </button>
              
              <button
                onClick={() => setActiveTopic('diet-plans')}
                className={`w-full text-left px-4 py-3 rounded-lg transition ${
                  activeTopic === 'diet-plans'
                    ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/20 dark:text-orange-400'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                <div className="font-medium">Diet Plans</div>
                <div className="text-sm text-muted-foreground">Meal planning, diet restrictions, guidance</div>
              </button>
              
              <button
                onClick={() => setActiveTopic('lifestyle')}
                className={`w-full text-left px-4 py-3 rounded-lg transition ${
                  activeTopic === 'lifestyle'
                    ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/20 dark:text-orange-400'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                <div className="font-medium">Lifestyle</div>
                <div className="text-sm text-muted-foreground">Healthy habits, food routines, wellbeing</div>
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Mobile tabs - shown only on mobile/tablet */}
        <div className="lg:hidden w-full mb-4">
          <Tabs defaultValue="nutrition" onValueChange={(value) => setActiveTopic(value as ChatTopic)}>
            <TabsList className="grid grid-cols-4 mb-4">
              <TabsTrigger value="nutrition">Nutrition</TabsTrigger>
              <TabsTrigger value="recipes">Recipes</TabsTrigger>
              <TabsTrigger value="diet-plans">Diet Plans</TabsTrigger>
              <TabsTrigger value="lifestyle">Lifestyle</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        
        {/* Main chat interface - takes more space on desktop */}
        <Card className="lg:col-span-2 h-[75vh] flex flex-col">
          <CardHeader className="px-6 py-4">
            <CardTitle>{nickname}</CardTitle>
            <CardDescription>
              Ask me anything about food, cooking, and nutrition
            </CardDescription>
          </CardHeader>
          <CardContent className="flex-1 overflow-hidden flex flex-col p-0">
            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto px-6 py-4">
              <div className="space-y-4">
                {chatMessages.map((msg, idx) => (
                  <div 
                    key={idx}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div 
                      className={`max-w-[85%] rounded-lg px-4 py-3 ${
                        msg.role === 'user' 
                          ? 'bg-orange-500 text-white ml-12' 
                          : 'bg-gray-100 dark:bg-gray-800 mr-12'
                      }`}
                    >
                      <div 
                        className="whitespace-pre-wrap" 
                        dangerouslySetInnerHTML={{ __html: msg.content }}
                      />
                    </div>
                  </div>
                ))}
                {sendingMessage && (
                  <div className="flex justify-start">
                    <div className="bg-gray-100 dark:bg-gray-800 rounded-lg px-4 py-3 max-w-[85%]">
                      <div className="flex flex-col space-y-2">
                        <div className="flex space-x-2">
                          <div className="h-2 w-2 bg-gray-400 rounded-full animate-bounce"></div>
                          <div className="h-2 w-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                          <div className="h-2 w-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                        </div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">Hold on now, let me cook</div>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            </div>
            
            <Separator />
            
            {/* Suggested questions */}
            <div className="px-6 py-3 overflow-x-auto">
              <div className="flex space-x-2">
                {suggestions[activeTopic].map((suggestion, index) => (
                  <button
                    key={index}
                    onClick={() => handleSuggestionClick(suggestion)}
                    className="px-3 py-1.5 text-xs whitespace-nowrap rounded-full border border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 transition"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
            
            <Separator />
            
            {/* Chat Input */}
            <div className="p-4 mt-auto">
              <div className="flex items-center">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder={`Ask your ${nickname} anything about food and nutrition...`}
                  className="flex-1 border-2 border-gray-300 dark:border-gray-700 rounded-l-md py-3 px-4 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent dark:bg-gray-800"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!newMessage.trim() || sendingMessage}
                  className="rounded-l-none bg-orange-500 hover:bg-orange-600"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 0l-3 3a1 1 0 001.414 1.414L9 9.414V13a1 1 0 102 0V9.414l1.293 1.293a1 1 0 001.414-1.414z" clipRule="evenodd" />
                  </svg>
                </Button>
              </div>
              <p className="mt-2 text-xs text-center text-muted-foreground">
                {nickname} is powered by artificial intelligence and may provide incorrect information.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}