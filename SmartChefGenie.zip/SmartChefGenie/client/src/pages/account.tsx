import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";
import { User } from "@shared/schema";
import { 
  UserIcon, 
  ChartIcon, 
  AppleIcon, 
  SparklesIcon,
  TrendingUpIcon,
  CalendarIcon,
  AlarmClockIcon,
  HistoryIcon,
  PlusIcon
} from "@/components/ui/icons";
import { apiRequest } from "@/lib/queryClient";
import { Progress } from "@/components/ui/progress";
import { queryClient } from "@/lib/queryClient";

export default function Account() {
  const { toast } = useToast();
  const { user, isLoading: authLoading, updateUserData } = useAuth();
  const [localUser, setLocalUser] = useState<User | null>(null);

  // Initialize local user when user data is loaded
  useEffect(() => {
    if (user) {
      setLocalUser(user);
    }
  }, [user]);

  const [profileForm, setProfileForm] = useState({
    name: "",
    email: "",
    username: "",
    dateOfBirth: "",
  });

  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [nutritionData, setNutritionData] = useState<{
    totalLogs: number;
    averageHealthScore: number;
    averageCalories: number;
    topFoodItems: {item: string, count: number}[];
    recentLogs: any[];
  }>({
    totalLogs: 0,
    averageHealthScore: 0,
    averageCalories: 0,
    topFoodItems: [],
    recentLogs: []
  });

  const [aiSuggestion, setAiSuggestion] = useState<string>("");
  const [loadingStats, setLoadingStats] = useState(true);
  const [loadingSuggestion, setLoadingSuggestion] = useState(true);

  // Update form values when user data changes
  useEffect(() => {
    if (user) {
      setProfileForm({
        name: user.name || "",
        email: user.email || "",
        username: user.username || "",
        dateOfBirth: user.dateOfBirth ? new Date(user.dateOfBirth).toISOString().split('T')[0] : "",
      });
    }
  }, [user]);

  // Update local display when local user changes
  useEffect(() => {
    if (localUser) {
      setProfileForm({
        name: localUser.name || "",
        email: localUser.email || "",
        username: localUser.username || "",
        dateOfBirth: localUser.dateOfBirth ? new Date(localUser.dateOfBirth).toISOString().split('T')[0] : "",
      });
    }
  }, [localUser]);

  // Fetch nutrition data
  useEffect(() => {
    if (!user) return;

    const fetchNutritionData = async () => {
      try {
        setLoadingStats(true);
        // Mock data since we don't have this endpoint yet
        setTimeout(() => {
          setNutritionData({
            totalLogs: 12,
            averageHealthScore: 7.2,
            averageCalories: 1860,
            topFoodItems: [
              { item: "Vegetables", count: 9 },
              { item: "Chicken", count: 7 },
              { item: "Rice", count: 6 },
              { item: "Pasta", count: 4 },
              { item: "Eggs", count: 3 }
            ],
            recentLogs: [
              { id: 1, date: new Date(Date.now() - 86400000), mealType: "Lunch", foodItems: ["Salad", "Grilled Chicken", "Brown Rice"], calories: 620, healthScore: 9 },
              { id: 2, date: new Date(Date.now() - 172800000), mealType: "Dinner", foodItems: ["Pasta", "Tomato Sauce", "Cheese"], calories: 850, healthScore: 6 },
              { id: 3, date: new Date(Date.now() - 259200000), mealType: "Breakfast", foodItems: ["Oatmeal", "Banana", "Honey"], calories: 410, healthScore: 8 }
            ]
          });
          setLoadingStats(false);
        }, 1000);
      } catch (error) {
        console.error("Error fetching nutrition data:", error);
        toast({
          title: "Failed to load nutrition data",
          description: "Please try again later.",
          variant: "destructive",
        });
        setLoadingStats(false);
      }
    };

    const fetchAiSuggestion = async () => {
      try {
        setLoadingSuggestion(true);
        // Simulate AI suggestion
        setTimeout(() => {
          setAiSuggestion("Based on your recent eating patterns, I suggest adding more leafy greens to your diet and reducing pasta consumption. Your protein intake is good, but consider incorporating more plant-based proteins like legumes and tofu. Try to maintain your water intake and consider eating smaller, more frequent meals to keep energy levels consistent throughout the day.");
          setLoadingSuggestion(false);
        }, 1500);
      } catch (error) {
        console.error("Error fetching AI suggestion:", error);
        setLoadingSuggestion(false);
      }
    };

    fetchNutritionData();
    fetchAiSuggestion();
  }, [user, toast]);

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProfileForm((prev) => ({ ...prev, [name]: value }));
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleUpdateProfile = async () => {
    try {
      // Only send fields that have actually changed
      const updates: any = {};
      if (profileForm.username !== user?.username) updates.username = profileForm.username;
      if (profileForm.name !== user?.name) updates.fullName = profileForm.name;
      if (profileForm.email !== user?.email) updates.email = profileForm.email;
      
      // Check if dateOfBirth has changed - convert to same format before comparing
      const currentDateOfBirth = user?.dateOfBirth ? new Date(user.dateOfBirth).toISOString().split('T')[0] : "";
      if (profileForm.dateOfBirth !== currentDateOfBirth) {
        updates.dateOfBirth = profileForm.dateOfBirth;
      }

      // Don't make API call if nothing changed
      if (Object.keys(updates).length === 0) {
        toast({
          title: "No changes detected",
          description: "Please make some changes before saving.",
        });
        return;
      }

      // Updating user profile on the server
      const updateResponse = await apiRequest<{ success: boolean; message: string; user: User }>({
        method: 'POST',
        url: '/api/user/update',
        data: updates
      });

      // Get the updated user data from the response
      const updatedUser = updateResponse.user;

      // Update the local user state first for immediate UI update
      setLocalUser(updatedUser);

      // Also update the user data in the auth context so other components will receive the update
      updateUserData(updatedUser);

      // Show success message with the updated values
      toast({
        title: "Profile updated",
        description: `Your profile was updated to: 
          Username: ${updatedUser?.username || profileForm.username},
          Name: ${updatedUser?.name || profileForm.name},
          Email: ${updatedUser?.email || profileForm.email},
          ${profileForm.dateOfBirth ? `Date of Birth: ${profileForm.dateOfBirth}` : ''}`,
      });

      // Also invalidate the query to ensure fresh data for the next page load
      queryClient.invalidateQueries({
        queryKey: ['/api/auth/user'],
      });

    } catch (error: any) {
      console.error("Error updating profile:", error);
      
      // Access the error response data properly
      const responseData = error.response?.data;
      console.log("Error response data:", responseData);
      
      let errorMessage = "There was a problem updating your profile.";
      
      // Check for specific error codes
      if (responseData && responseData.error === 'username_already_taken') {
        errorMessage = "Username already taken. Please choose a different username.";
      }

      toast({
        title: "Update failed",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const handleUpdatePassword = () => {
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please ensure your new password and confirmation match.",
        variant: "destructive",
      });
      return;
    }

    // In a real app, this would update the user's password on the server
    setTimeout(() => {
      toast({
        title: "Password updated",
        description: "Your password has been updated successfully.",
      });
      setPasswordForm({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
    }, 500);
  };

  const getInitials = (name: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', { 
      month: 'short', 
      day: 'numeric' 
    }).format(date);
  };
  
  const calculateAge = (birthDate: Date): number => {
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    return age;
  };

  // Determine which user data to display (localUser takes precedence for immediate UI updates)
  const displayUser = localUser || user;

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <h1 className="text-3xl font-bold mb-6">Account Settings</h1>

      <div className="flex flex-col md:flex-row gap-8 mb-8">
        <div className="md:w-1/3">
          <Card className="text-center p-6 bg-card border border-border">
            <div className="flex flex-col items-center">
              <Avatar className="h-24 w-24 mb-4">
                <AvatarImage src={displayUser?.image || ""} alt={displayUser?.name || "User"} />
                <AvatarFallback className="bg-orange-100 text-orange-800 text-xl">
                  {getInitials(displayUser?.name || displayUser?.username || "")}
                </AvatarFallback>
              </Avatar>
              <h2 className="text-xl font-semibold mb-1 text-foreground">{displayUser?.name || displayUser?.username}</h2>
              <p className="text-muted-foreground text-sm mb-4 font-medium">{displayUser?.email}</p>
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full"
                onClick={() => toast({
                  title: "Not implemented",
                  description: "This feature is not available yet.",
                })}
              >
                Change Avatar
              </Button>
            </div>
          </Card>
        </div>

        <div className="md:w-2/3">
          <Tabs defaultValue="profile" className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="profile" className="flex items-center gap-2">
                <UserIcon size={16} />
                Profile
              </TabsTrigger>
              <TabsTrigger value="security" className="flex items-center gap-2">
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="3" y="11" width="18" height="11" rx="2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M7 11V7C7 4.23858 9.23858 2 12 2C14.7614 2 17 4.23858 17 7V11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Security
              </TabsTrigger>
              <TabsTrigger value="connected" className="flex items-center gap-2">
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 6L20 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M3.5 12H13.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M9 18L20 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Connected Accounts
              </TabsTrigger>
            </TabsList>

            <TabsContent value="profile">
              <Card>
                <CardHeader>
                  <CardTitle>Profile Information</CardTitle>
                  <CardDescription>
                    Update your account details and personal information.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        name="name"
                        value={profileForm.name}
                        onChange={handleProfileChange}
                        placeholder="Enter your full name"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="username">Username</Label>
                      <Input
                        id="username"
                        name="username"
                        value={profileForm.username}
                        onChange={handleProfileChange}
                        placeholder="Enter your username"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={profileForm.email}
                      onChange={handleProfileChange}
                      placeholder="Enter your email"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="dateOfBirth">Date of Birth</Label>
                    <Input
                      id="dateOfBirth"
                      name="dateOfBirth"
                      type="date"
                      value={profileForm.dateOfBirth}
                      onChange={handleProfileChange}
                    />
                    {profileForm.dateOfBirth && (
                      <div className="text-sm text-muted-foreground">
                        Age: {calculateAge(new Date(profileForm.dateOfBirth))} years old
                      </div>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="justify-end">
                  <Button onClick={handleUpdateProfile} className="bg-gradient-to-r from-orange-500 to-orange-400">
                    Save Changes
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="security">
              <Card>
                <CardHeader>
                  <CardTitle>Password</CardTitle>
                  <CardDescription>
                    Update your password to keep your account secure.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="currentPassword">Current Password</Label>
                    <Input
                      id="currentPassword"
                      name="currentPassword"
                      type="password"
                      value={passwordForm.currentPassword}
                      onChange={handlePasswordChange}
                      placeholder="Enter your current password"
                    />
                  </div>

                  <Separator />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="newPassword">New Password</Label>
                      <Input
                        id="newPassword"
                        name="newPassword"
                        type="password"
                        value={passwordForm.newPassword}
                        onChange={handlePasswordChange}
                        placeholder="Enter your new password"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">Confirm New Password</Label>
                      <Input
                        id="confirmPassword"
                        name="confirmPassword"
                        type="password"
                        value={passwordForm.confirmPassword}
                        onChange={handlePasswordChange}
                        placeholder="Confirm your new password"
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="justify-end">
                  <Button 
                    onClick={handleUpdatePassword} 
                    className="bg-gradient-to-r from-orange-500 to-orange-400"
                    disabled={!passwordForm.currentPassword || !passwordForm.newPassword || !passwordForm.confirmPassword}
                  >
                    Update Password
                  </Button>
                </CardFooter>
              </Card>

              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Login Sessions</CardTitle>
                  <CardDescription>
                    Manage your active login sessions on different devices.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border">
                    <div className="flex items-center p-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <svg className="w-5 h-5 text-green-500" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                            <path d="M16.28 13.61C15.15 14.74 13.53 15.09 12.1 14.64L9.51 17.22C9.33 17.41 8.96 17.53 8.69 17.49L7.49 17.33C7.09 17.28 6.73 16.9 6.67 16.51L6.51 15.31C6.47 15.05 6.6 14.68 6.78 14.49L9.36 11.91C8.92 10.48 9.26 8.86 10.39 7.73C12.01 6.11 14.65 6.11 16.28 7.73C17.9 9.34 17.9 11.98 16.28 13.61Z" stroke="currentColor" strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
                            <path d="M10.45 16.28L9.6 15.42" stroke="currentColor" strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
                            <path d="M13.3945 10.7H13.4035" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                          </svg>
                          <span className="font-medium">Current Session</span>
                          <span className="bg-green-100 text-green-800 text-xs font-medium px-2 py-0.5 rounded">Active</span>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1 font-medium">Last active just now</p>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          toast({
                            title: "Not your device?",
                            description: "If you don't recognize this device, you should log out and change your password immediately.",
                          });
                        }}
                      >
                        This Device
                      </Button>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="justify-end">
                  <Button 
                    variant="outline" 
                    className="text-red-600 hover:text-red-700 border-red-200 hover:border-red-300 hover:bg-red-50"
                    onClick={() => {
                      toast({
                        title: "All other sessions terminated",
                        description: "You've been logged out from all other devices.",
                      });
                    }}
                  >
                    Log Out of All Other Devices
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="connected">
              <Card>
                <CardHeader>
                  <CardTitle>Connected Accounts</CardTitle>
                  <CardDescription>
                    Connect your accounts to sign in more easily.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between py-3 border-b">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#4285F4] flex items-center justify-center text-white">
                        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                          <path d="M12 11V8L15 5H18L15 8H18L15 11H12Z" />
                          <path d="M12.0001 11V8L9.00008 5H6.00008L9.00008 8H6.00008L9.00008 11H12.0001Z" />
                          <path d="M12 13V16L9.00001 19H6.00001L9.00001 16H6.00001L9.00001 13H12Z" />
                          <path d="M12 13V16L15 19H18L15 16H18L15 13H12Z" />
                        </svg>
                      </div>
                      <div>
                        <p className="font-medium">Google</p>
                        <p className="text-sm text-muted-foreground font-medium">Sign in with Google</p>
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        toast({
                          title: "Coming soon",
                          description: "Google Sign In will be available soon.",
                        });
                      }}
                    >
                      Connect
                    </Button>
                  </div>

                  <div className="flex items-center justify-between py-3 border-b">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-black flex items-center justify-center text-white">
                        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                          <path d="M17.5641 12.9151C17.5641 10.9879 19.1035 9.37589 21.0307 9.37589C21.1749 9.37589 21.3173 9.38475 21.457 9.40149V5.74829C21.457 4.20349 20.2059 2.95239 18.661 2.95239H5.33771C3.79291 2.95239 2.54181 4.20349 2.54181 5.74829V18.2493C2.54181 19.7941 3.79291 21.0452 5.33771 21.0452H18.661C20.2059 21.0452 21.457 19.7941 21.457 18.2493V14.5226C21.3173 14.5394 21.1749 14.5482 21.0307 14.5482C19.1035 14.5482 17.5641 12.9362 17.5641 10.9879V12.9151Z" />
                          <path d="M21.0308 14.1245C19.3263 14.1245 17.9519 12.7501 17.9519 11.0457C17.9519 9.34125 19.3263 7.96681 21.0308 7.96681C22.7353 7.96681 24.1097 9.34125 24.1097 11.0457C24.1097 12.7501 22.7353 14.1245 21.0308 14.1245Z" />
                        </svg>
                      </div>
                      <div>
                        <p className="font-medium">Apple</p>
                        <p className="text-sm text-muted-foreground font-medium">Sign in with Apple</p>
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        toast({
                          title: "Coming soon",
                          description: "Apple Sign In will be available soon.",
                        });
                      }}
                    >
                      Connect
                    </Button>
                  </div>
                </CardContent>
                <CardFooter>
                  <p className="text-xs text-muted-foreground font-medium">
                    Connecting an account allows you to sign in using that provider in the future.
                  </p>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}