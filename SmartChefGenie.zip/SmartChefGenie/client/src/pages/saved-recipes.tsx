import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import RecipeCard from "@/components/recipe-card";
import RecipeDetailModal from "@/components/recipe-detail-modal";
import { type Recipe } from "@shared/schema";
import { BookmarkIcon, ChefHatIcon } from "@/components/ui/icons";
import { getQueryFn } from "@/lib/queryClient";

export default function SavedRecipes() {
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const { toast } = useToast();

  // Fetch saved recipes
  const { data: savedRecipes, isLoading, error, refetch } = useQuery<Recipe[]>({
    queryKey: ['/api/user/recipes'],
  });

  // Handle view recipe
  const handleViewRecipe = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
  };

  // Close recipe modal
  const handleCloseModal = () => {
    setSelectedRecipe(null);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="flex flex-col items-center">
          <div className="relative h-12 w-12">
            <div className="absolute inset-0 rounded-full border-4 border-t-transparent border-orange-500 animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <ChefHatIcon size={20} className="text-orange-500" />
            </div>
          </div>
          <p className="mt-4 text-muted-foreground">Loading your saved recipes...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-center p-6">
        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
          <svg className="w-8 h-8 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
          </svg>
        </div>
        <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">Error loading saved recipes</h3>
        <p className="text-muted-foreground mb-4">
          We couldn't load your saved recipes. Please try again.
        </p>
        <Button onClick={() => refetch()}>
          Retry
        </Button>
      </div>
    );
  }

  if (!savedRecipes || savedRecipes.length === 0) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white">Your Saved Recipes</h1>
        <div className="bg-card rounded-lg shadow-sm text-center py-16 px-6">
          <div className="text-orange-500 mb-4">
            <BookmarkIcon className="w-16 h-16 mx-auto" />
          </div>
          <h2 className="text-xl font-medium mb-2 text-gray-900 dark:text-white">No saved recipes yet</h2>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            When you save recipes you love, they will appear here for easy access later.
          </p>
          <Link to="/">
            <Button className="relative group overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-orange-400 group-hover:from-orange-500 group-hover:to-orange-300"></div>
              <span className="relative z-10 flex items-center">
                <ChefHatIcon className="mr-2" size={16} />
                Discover Recipes
              </span>
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-2 text-gray-900 dark:text-white">Your Saved Recipes</h1>
      <p className="text-muted-foreground mb-8">Your favorite recipes saved for easy access</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {savedRecipes.map((recipe, index) => (
          <RecipeCard
            key={`${recipe.id || ''}-${index}`}
            recipe={recipe}
            onViewRecipe={() => handleViewRecipe(recipe)}
          />
        ))}
      </div>

      {selectedRecipe && (
        <RecipeDetailModal
          recipe={selectedRecipe}
          onClose={handleCloseModal}
        />
      )}
    </div>
  );
}