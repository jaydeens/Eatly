import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChartIcon, LeafIcon, AlarmClockIcon, TrendingUpIcon, LockIcon } from "../components/ui/icons";
import { Progress } from "@/components/ui/progress";
import { NutritionLog } from "@shared/schema";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import NutritionGoalsForm from "@/components/nutrition-goals-form";
import NutritionStatsPeriod from "@/components/nutrition-stats-period";
import NutritionLogsList from "@/components/nutrition-logs-list";
import AddNutritionLogForm from "@/components/add-nutrition-log-form";

// Types for the nutrition data
interface NutritionStats {
  totalLogs: number;
  averageHealthScore: number;
  averageCalories: number;
  topFoodItems: Array<{item: string, count: number}>;
}

export default function Nutrition() {
  const [addLogDialogOpen, setAddLogDialogOpen] = useState(false);
  const [goalsDialogOpen, setGoalsDialogOpen] = useState(false);
  const [, navigate] = useLocation();
  const { isAuthenticated, user } = useAuth();
  
  // Only fetch data if user is authenticated
  const { data: nutritionStats, isLoading: statsLoading } = useQuery<NutritionStats>({
    queryKey: ['/api/nutrition/stats'],
    enabled: isAuthenticated
  });
  
  const { data: nutritionLogs, isLoading: logsLoading } = useQuery<NutritionLog[]>({
    queryKey: ['/api/nutrition/logs'],
    enabled: isAuthenticated
  });
  
  const isLoading = isAuthenticated && (statsLoading || logsLoading);
  
  // When not authenticated, show a login prompt
  if (!isAuthenticated) {
    return (
      <div className="container py-8 max-w-6xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Nutrition Dashboard</h1>
          <p className="text-muted-foreground">
            Track your nutritional habits and health progress
          </p>
        </div>
        
        <div className="flex flex-col items-center justify-center bg-card dark:bg-black/40 backdrop-blur-lg p-12 rounded-3xl shadow-lg border border-orange-500/20 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-orange-500/5 to-orange-400/5 dark:from-orange-950/10 dark:to-orange-800/5"></div>
          
          <div className="relative z-10 text-center max-w-md">
            <div className="inline-flex p-4 rounded-full bg-orange-100 dark:bg-orange-950/50 text-orange-500 mb-6">
              <LockIcon size={32} />
            </div>
            
            <h2 className="text-2xl font-bold mb-4">Sign In Required</h2>
            <p className="text-muted-foreground mb-8">
              Please sign in to access your personalized nutrition dashboard. Track your meals, analyze your diet, and get customized health insights.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button onClick={() => navigate('/auth')} className="bg-gradient-to-r from-orange-500 to-orange-400 hover:from-orange-600 hover:to-orange-500">
                Sign In
              </Button>
              <Button onClick={() => navigate('/')} variant="outline">
                Return to Recipes
              </Button>
            </div>
            
            <div className="mt-8 pt-8 border-t border-border">
              <p className="text-sm text-muted-foreground">
                "Let food be thy medicine and medicine be thy food." — Hippocrates
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-8 max-w-6xl">
      <div className="flex flex-col md:flex-row justify-between items-start mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Nutrition Dashboard</h1>
          <p className="text-muted-foreground">
            Track your nutritional habits and health progress
          </p>
        </div>
        
        <div className="flex flex-wrap gap-2 mt-4 md:mt-0">
          <Button 
            onClick={() => setAddLogDialogOpen(true)}
            className="bg-gradient-to-r from-orange-500 to-orange-400 hover:from-orange-600 hover:to-orange-500"
          >
            <LeafIcon className="mr-2 h-4 w-4" />
            Log a Meal
          </Button>
          <Button 
            variant="outline" 
            onClick={() => setGoalsDialogOpen(true)}
          >
            <TrendingUpIcon className="mr-2 h-4 w-4" />
            Set Goals
          </Button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="flex flex-col items-center">
            <div className="h-12 w-12 rounded-full border-4 border-orange-500 border-t-transparent animate-spin mb-4"></div>
            <p className="text-muted-foreground">Loading nutrition data...</p>
          </div>
        </div>
      ) : (
        <>
          {/* Nutrition Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatCard 
              title="Health Score" 
              value={nutritionStats?.averageHealthScore || 0} 
              suffix="/10"
              description="Average health rating" 
              icon={<ChartIcon className="h-5 w-5 text-green-500" />}
              trend={+5}
            />
            <StatCard 
              title="Calories" 
              value={nutritionStats?.averageCalories || 0} 
              suffix="kcal"
              description="Daily average intake" 
              icon={<AlarmClockIcon className="h-5 w-5 text-orange-500" />}
              trend={-120}
            />
            <StatCard 
              title="Nutrition Logs" 
              value={nutritionStats?.totalLogs || 0} 
              description="Total meals tracked" 
              icon={<LeafIcon className="h-5 w-5 text-emerald-500" />}
            />
            <StatCard 
              title="Progress" 
              value={75} 
              suffix="%"
              description="Towards your goal" 
              icon={<TrendingUpIcon className="h-5 w-5 text-blue-500" />}
              showProgress={true}
            />
          </div>
          
          {/* Detailed Nutrition Analysis */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            <div className="lg:col-span-2">
              <NutritionStatsPeriod />
            </div>
            <div className="lg:col-span-1">
              <NutritionGoalsForm />
            </div>
          </div>
          
          {/* Nutrition Logs */}
          <div className="mb-8">
            <NutritionLogsList />
          </div>
          
          {/* Nutrition Tips */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Meal Planning Tips</CardTitle>
                <CardDescription>Strategies for healthier eating</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="p-4 rounded-lg bg-orange-50 dark:bg-orange-900/20 border border-orange-100 dark:border-orange-800/30">
                  <h4 className="font-medium text-orange-700 dark:text-orange-300 mb-1">Balance Your Plate</h4>
                  <p className="text-sm text-orange-600/80 dark:text-orange-400/80">
                    Aim for half your plate to be vegetables, a quarter protein, and a quarter whole grains.
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Hydration</CardTitle>
                <CardDescription>Stay properly hydrated</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800/30">
                  <h4 className="font-medium text-blue-700 dark:text-blue-300 mb-1">Stay Hydrated</h4>
                  <p className="text-sm text-blue-600/80 dark:text-blue-400/80">
                    Drink water throughout the day, especially before meals to help with portion control.
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Recipe Integration</CardTitle>
                <CardDescription>Connect with our recipes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="p-4 rounded-lg bg-green-50 dark:bg-green-900/20 border border-green-100 dark:border-green-800/30">
                  <h4 className="font-medium text-green-700 dark:text-green-300 mb-1">Connect with AI Recipes</h4>
                  <p className="text-sm text-green-600/80 dark:text-green-400/80">
                    When you pick a recipe from our AI generator, we'll automatically add it to your nutrition log!
                  </p>
                </div>
                <Button variant="outline" className="w-full mt-4" onClick={() => navigate('/')}>
                  Find AI-Powered Recipes
                </Button>
              </CardContent>
            </Card>
          </div>
        </>
      )}
      
      {/* Add Meal Dialog */}
      <Dialog open={addLogDialogOpen} onOpenChange={setAddLogDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Log a Meal</DialogTitle>
            <DialogDescription>
              Record what you've eaten to track your nutrition progress
            </DialogDescription>
          </DialogHeader>
          <AddNutritionLogForm 
            onSuccess={() => setAddLogDialogOpen(false)}
            onCancel={() => setAddLogDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
      
      {/* Goals Dialog */}
      <Dialog open={goalsDialogOpen} onOpenChange={setGoalsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nutrition Goals</DialogTitle>
            <DialogDescription>
              Set your nutrition targets to track your progress
            </DialogDescription>
          </DialogHeader>
          <NutritionGoalsForm />
        </DialogContent>
      </Dialog>
    </div>
  );
}

interface StatCardProps {
  title: string;
  value: number;
  suffix?: string;
  description: string;
  icon: React.ReactNode;
  trend?: number;
  showProgress?: boolean;
}

function StatCard({ title, value, suffix = "", description, icon, trend, showProgress }: StatCardProps) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
            <div className="flex items-baseline">
              <h3 className="text-2xl font-bold">{value}</h3>
              {suffix && <span className="text-muted-foreground ml-1 text-sm">{suffix}</span>}
            </div>
            <p className="text-xs text-muted-foreground mt-1">{description}</p>
          </div>
          <div className="p-2 rounded-full bg-primary/10">
            {icon}
          </div>
        </div>
        
        {trend !== undefined && (
          <div className="mt-3 flex items-center">
            <div 
              className={`flex items-center text-xs font-medium ${
                trend > 0 ? 'text-green-500' : 'text-red-500'
              }`}
            >
              {trend > 0 ? '↑' : '↓'} {Math.abs(trend)}%
            </div>
            <span className="text-xs text-muted-foreground ml-1">from last week</span>
          </div>
        )}
        
        {showProgress && (
          <div className="mt-4">
            <Progress value={value} className="h-2" />
          </div>
        )}
      </CardContent>
    </Card>
  );
}