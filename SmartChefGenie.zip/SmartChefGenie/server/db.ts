import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Create a connection pool with additional options for better stability
export const pool = new Pool({ 
  connectionString: process.env.DATABASE_URL,
  max: 20, // Maximum number of clients in the pool
  idleTimeoutMillis: 30000, // How long a client is allowed to remain idle before being closed
  connectionTimeoutMillis: 5000, // How long to wait for a connection
});

// Set up event handlers for the pool
pool.on('error', (err, client) => {
  console.error('Unexpected error on idle client', err);
  // Don't crash the server, just log the error
});

pool.on('connect', (client) => {
  console.log('New database connection established');
});

// Function to check and reconnect to database if connection is lost
export async function checkDatabaseConnection() {
  const MAX_RETRIES = 3;
  let retries = 0;
  
  while (retries < MAX_RETRIES) {
    try {
      const client = await pool.connect();
      await client.query('SELECT 1');
      client.release();
      console.log('Database connection check: Success');
      return true;
    } catch (err) {
      console.error(`Database connection check failed (attempt ${retries + 1}/${MAX_RETRIES}):`, err);
      retries++;
      
      if (retries >= MAX_RETRIES) {
        console.error('All database connection attempts failed, using fallback storage');
        return false;
      }
      
      // Wait before retrying (exponential backoff)
      const backoffMs = Math.min(100 * Math.pow(2, retries), 3000);
      console.log(`Retrying database connection in ${backoffMs}ms...`);
      await new Promise(resolve => setTimeout(resolve, backoffMs));
    }
  }
  
  return false;
}

// Ping the database every minute to keep the connection alive
setInterval(async () => {
  try {
    const client = await pool.connect();
    await client.query('SELECT 1');
    client.release();
    console.log('Database connection check: OK');
  } catch (err) {
    console.error('Database ping failed:', err);
  }
}, 60000);

// Helper function for database operations with retries
export async function withRetry<T>(operation: () => Promise<T>, maxRetries = 3): Promise<T> {
  let lastError: any;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error: any) {
      lastError = error;
      
      // Check if this is a connection error that we should retry
      const isConnectionError = 
        error.code === '57P01' || // admin_shutdown
        error.code === '08006' || // connection_failure 
        error.code === '08001' || // sqlclient_unable_to_establish_sqlconnection
        error.code === '08004';   // sqlserver_rejected_establishment_of_sqlconnection
      
      if (!isConnectionError || attempt >= maxRetries) {
        console.error(`Database operation failed after ${attempt} attempts:`, error);
        throw error;
      }
      
      // Wait before retrying (exponential backoff)
      const backoffMs = Math.min(100 * Math.pow(2, attempt), 2000);
      console.log(`Database operation failed (attempt ${attempt}/${maxRetries}), retrying in ${backoffMs}ms...`);
      await new Promise(resolve => setTimeout(resolve, backoffMs));
    }
  }
  
  // This should never happen as the loop above should either return or throw
  throw lastError;
}

// Create the drizzle instance
export const db = drizzle({ client: pool, schema });
