import axios from 'axios';
import { GeneratedRecipes } from '@shared/schema';

const SPOONACULAR_API_KEY = process.env.SPOONACULAR_API_KEY;
const SPOONACULAR_API_URL = 'https://api.spoonacular.com';

if (!SPOONACULAR_API_KEY) {
  console.error("SPOONACULAR_API_KEY environment variable is not set. Spoonacular features will not work.");
}

// Interface for recipe search response
interface SpoonacularRecipe {
  id: number;
  title: string;
  image: string;
  imageType: string;
  usedIngredientCount: number;
  missedIngredientCount: number;
  missedIngredients: any[];
  usedIngredients: any[];
  unusedIngredients: any[];
  likes: number;
}

// Interface for detailed recipe information
interface SpoonacularRecipeInfo {
  id: number;
  title: string;
  image: string;
  readyInMinutes: number;
  servings: number;
  summary: string;
  instructions: string;
  analyzedInstructions: Array<{
    name: string;
    steps: Array<{
      number: number;
      step: string;
      ingredients: any[];
      equipment: any[];
    }>;
  }>;
  vegetarian: boolean;
  vegan: boolean;
  glutenFree: boolean;
  dairyFree: boolean;
  sustainable: boolean;
  lowFodmap: boolean;
  weightWatcherSmartPoints: number;
  dishTypes: string[];
  diets: string[];
  extendedIngredients?: Array<{
    id: number;
    name: string;
    amount: number;
    unit: string;
    original: string;
  }>;
  nutrition?: {
    nutrients: Array<{
      name: string;
      amount: number;
      unit: string;
      percentOfDailyNeeds: number;
    }>;
  };
}

// Search for recipes by ingredients using complexSearch endpoint for better filtering
export async function searchRecipesByIngredients(
  ingredients: string[],
  dietaryPreferences: string[] = [],
  number: number = 20,
  cuisineType?: string
): Promise<SpoonacularRecipe[]> {
  if (!SPOONACULAR_API_KEY) {
    throw new Error("SPOONACULAR_API_KEY environment variable is not set");
  }

  try {
    // Use complexSearch endpoint when cuisine filtering is needed
    if (cuisineType) {
      console.log(`Using complexSearch endpoint with cuisine type: ${cuisineType}`);
      
      const params = new URLSearchParams({
        apiKey: SPOONACULAR_API_KEY,
        includeIngredients: ingredients.join(','),
        number: (number * 2).toString(), // Request more recipes to ensure we get enough matches
        addRecipeInformation: 'true', // Include basic recipe info in response
        fillIngredients: 'true', // Include ingredients in response
        sort: 'max-used-ingredients', // Maximize use of provided ingredients
        sortDirection: 'desc', // Most ingredient matches first
        instructionsRequired: 'true' // Ensure recipes have instructions
      });
      
      // Add dietary preferences to query parameters
      if (dietaryPreferences.length > 0) {
        params.append('diet', dietaryPreferences.join(','));
      }
      
      // Add cuisine type - complexSearch handles this correctly
      params.append('cuisine', cuisineType);
      
      const response = await axios.get(`${SPOONACULAR_API_URL}/recipes/complexSearch`, {
        params
      });
      
      // Transform results to match our expected format
      if (response.data && response.data.results) {
        const transformedResults = response.data.results.map((recipe: any) => ({
          id: recipe.id,
          title: recipe.title,
          image: recipe.image,
          imageType: recipe.imageType || 'jpg',
          usedIngredientCount: recipe.usedIngredientCount || ingredients.length,
          missedIngredientCount: 0,
          missedIngredients: [],
          usedIngredients: [],
          unusedIngredients: [],
          likes: recipe.likes || 0
        }));
        
        return transformedResults;
      }
      
      return [];
    } else {
      // Use findByIngredients for normal ingredient-based search without cuisine filtering
      const params = new URLSearchParams({
        apiKey: SPOONACULAR_API_KEY,
        ingredients: ingredients.join(','),
        number: number.toString(),
        ranking: '2', // maximize used ingredients
        ignorePantry: 'true', // ignore typical pantry items like salt, oil
      });

      // Add dietary preferences to query parameters
      if (dietaryPreferences.length > 0) {
        params.append('diet', dietaryPreferences.join(','));
      }
      
      const response = await axios.get(`${SPOONACULAR_API_URL}/recipes/findByIngredients`, {
        params
      });

      return response.data;
    }
  } catch (error) {
    console.error("Failed to search recipes by ingredients:", error);
    
    if (axios.isAxiosError(error)) {
      const statusCode = error.response?.status;
      const errorMessage = error.response?.data?.message || error.message;
      
      if (statusCode === 401 || statusCode === 403) {
        throw new Error(`API key is invalid or has insufficient permissions. Please check your Spoonacular API key settings.`);
      } else if (statusCode === 429) {
        throw new Error("API request limit exceeded. Please try again later.");
      }
      
      throw new Error(`Spoonacular API error (${statusCode}): ${errorMessage}`);
    }
    
    throw new Error(`Failed to search recipes: ${(error as Error).message}`);
  }
}

// Get detailed recipe information
export async function getRecipeInformation(
  recipeId: number,
  includeNutrition: boolean = true
): Promise<SpoonacularRecipeInfo> {
  if (!SPOONACULAR_API_KEY) {
    throw new Error("SPOONACULAR_API_KEY environment variable is not set");
  }

  try {
    const response = await axios.get(
      `${SPOONACULAR_API_URL}/recipes/${recipeId}/information`, 
      {
        params: {
          apiKey: SPOONACULAR_API_KEY,
          includeNutrition: includeNutrition
        }
      }
    );

    return response.data;
  } catch (error) {
    console.error(`Failed to get recipe information for ID ${recipeId}:`, error);
    
    if (axios.isAxiosError(error)) {
      const statusCode = error.response?.status;
      const errorMessage = error.response?.data?.message || error.message;
      
      if (statusCode === 401 || statusCode === 403) {
        throw new Error(`API key is invalid or has insufficient permissions. Please check your Spoonacular API key settings.`);
      } else if (statusCode === 429) {
        throw new Error("API request limit exceeded. Please try again later.");
      } else if (statusCode === 404) {
        throw new Error(`Recipe with ID ${recipeId} not found.`);
      }
      
      throw new Error(`Spoonacular API error (${statusCode}): ${errorMessage}`);
    }
    
    throw new Error(`Failed to get recipe information: ${(error as Error).message}`);
  }
}

// Get nutritional information for multiple ingredients
export async function getNutritionalInformation(
  ingredients: string[]
): Promise<any> {
  if (!SPOONACULAR_API_KEY) {
    throw new Error("SPOONACULAR_API_KEY environment variable is not set");
  }

  try {
    const response = await axios.post(
      `${SPOONACULAR_API_URL}/recipes/parseIngredients`, 
      new URLSearchParams({
        ingredientList: ingredients.join('\n'),
        servings: '1',
        includeNutrition: 'true'
      }),
      {
        params: {
          apiKey: SPOONACULAR_API_KEY
        },
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }
    );

    return response.data;
  } catch (error) {
    console.error("Failed to get nutritional information:", error);
    
    if (axios.isAxiosError(error)) {
      const statusCode = error.response?.status;
      const errorMessage = error.response?.data?.message || error.message;
      
      if (statusCode === 401 || statusCode === 403) {
        throw new Error(`API key is invalid or has insufficient permissions. Please check your Spoonacular API key settings.`);
      } else if (statusCode === 429) {
        throw new Error("API request limit exceeded. Please try again later.");
      }
      
      throw new Error(`Spoonacular API error (${statusCode}): ${errorMessage}`);
    }
    
    throw new Error(`Failed to get nutritional information: ${(error as Error).message}`);
  }
}

// Generate recipes with Spoonacular API
export async function generateRecipesWithSpoonacular(
  ingredients: string[],
  dietaryFilters: string[] = [],
  cuisineType?: string,
  servings: number = 2
): Promise<GeneratedRecipes> {
  try {
    console.log(`Generating recipes with Spoonacular API:`);
    console.log(`- Ingredients: ${ingredients.join(', ')}`);
    console.log(`- Dietary filters: ${dietaryFilters.length ? dietaryFilters.join(', ') : 'none'}`);
    console.log(`- Cuisine type: ${cuisineType || 'not specified'}`);
    
    // First search for recipes matching the ingredients
    const recipeResults = await searchRecipesByIngredients(ingredients, dietaryFilters, 20, cuisineType);
    
    if (!recipeResults || recipeResults.length === 0) {
      throw new Error("No recipes found with the provided ingredients.");
    }
    
    console.log(`Found ${recipeResults.length} initial recipe matches`);
    
    // Get detailed information for each recipe, increased to 12 recipes for more options
    const detailedRecipes = await Promise.all(
      recipeResults.slice(0, 12).map(recipe => getRecipeInformation(recipe.id))
    );
    
    console.log(`Got detailed information for ${detailedRecipes.length} recipes`);
    
    // Transform Spoonacular recipe format to our app's recipe format
    const recipes = detailedRecipes.map(spoonacularRecipe => {
      // Extract nutrients and adjust based on servings
      const nutrients = spoonacularRecipe.nutrition?.nutrients || [];
      // Calculate ratio for nutrition adjustment
      const servingsRatio = servings / spoonacularRecipe.servings;
      // Adjust nutrients based on servings ratio
      const protein = (nutrients.find(n => n.name === "Protein")?.amount || 0) * servingsRatio;
      const carbs = (nutrients.find(n => n.name === "Carbohydrates")?.amount || 0) * servingsRatio;
      const fat = (nutrients.find(n => n.name === "Fat")?.amount || 0) * servingsRatio;
      const fiber = (nutrients.find(n => n.name === "Fiber")?.amount || 0) * servingsRatio;
      const calories = (nutrients.find(n => n.name === "Calories")?.amount || 0) * servingsRatio;
      
      // Extract instructions from analyzed instructions or from the HTML instructions
      const instructions = spoonacularRecipe.analyzedInstructions?.[0]?.steps?.map((step: { step: string }) => step.step) || 
                           (spoonacularRecipe.instructions ? 
                              spoonacularRecipe.instructions
                                .replace(/<[^>]*>/g, '') // Remove HTML tags
                                .split(/\.\s+/) // Split on periods
                                .filter(Boolean) // Remove empty strings
                                .map((s: string) => s.trim() + '.') // Add back periods and trim whitespace
                            : []);
      
      // Extract ingredients and adjust quantities based on requested servings
      const ingredients = spoonacularRecipe.extendedIngredients?.map(
        (ingredient: { amount: number; unit: string; name: string }) => {
          // Calculate the adjusted amount based on the ratio of requested servings to original servings
          const servingsRatio = servings / spoonacularRecipe.servings;
          const adjustedAmount = ingredient.amount * servingsRatio;
          // Format the amount to 1 decimal place if it's not a whole number
          const formattedAmount = Number.isInteger(adjustedAmount) 
            ? adjustedAmount 
            : adjustedAmount.toFixed(1);
          return `${formattedAmount} ${ingredient.unit} ${ingredient.name}`;
        }
      ) || [];
      
      // Determine difficulty based on time and steps
      let difficulty = "Easy";
      if (spoonacularRecipe.readyInMinutes > 45 || instructions.length > 7) {
        difficulty = "Medium";
      }
      if (spoonacularRecipe.readyInMinutes > 90 || instructions.length > 12) {
        difficulty = "Hard";
      }
      
      // Create tags from diets and dish types
      const tags = [
        ...(spoonacularRecipe.diets || []),
        ...(spoonacularRecipe.dishTypes || [])
      ];
      
      // Add dietary tags based on recipe properties
      if (spoonacularRecipe.vegetarian) tags.push("Vegetarian");
      if (spoonacularRecipe.vegan) tags.push("Vegan");
      if (spoonacularRecipe.glutenFree) tags.push("Gluten-Free");
      if (spoonacularRecipe.dairyFree) tags.push("Dairy-Free");
      
      // Add cuisine type to tags if specified (prioritize over other tags)
      if (cuisineType) {
        // Remove any existing cuisine tags to avoid duplication
        const cuisineTag = cuisineType.charAt(0).toUpperCase() + cuisineType.slice(1);
        tags.unshift(cuisineTag); // Add to beginning of array to prioritize
      }
      
      // Remove duplicates and limit to 5 tags (without using Set)
      const uniqueTags = tags.filter((tag, index) => tags.indexOf(tag) === index).slice(0, 5);
      
      // Format the recipe according to our schema
      return {
        title: spoonacularRecipe.title,
        description: spoonacularRecipe.summary
          ? spoonacularRecipe.summary.replace(/<[^>]*>/g, '').substring(0, 150) + '...'
          : 'A delicious recipe using your selected ingredients.',
        time: `${spoonacularRecipe.readyInMinutes} mins`,
        servings: servings, // Use the servings parameter instead of the original recipe servings
        calories: Math.round(calories),
        difficulty,
        tags: uniqueTags, // Using the uniqueTags array instead of Set
        ingredients,
        instructions,
        nutrition: {
          protein: Math.round(protein),
          carbs: Math.round(carbs),
          fat: Math.round(fat),
          fiber: Math.round(fiber)
        },
        tips: "For best results, follow the recipe exactly as written and taste as you go.",
        image: spoonacularRecipe.image
      };
    });
    
    console.log(`Successfully transformed ${recipes.length} Spoonacular recipes`);
    if (cuisineType) {
      const cuisineTagCount = recipes.filter(recipe => 
        recipe.tags && recipe.tags.some((tag: string) => 
          tag.toLowerCase() === cuisineType.toLowerCase()
        )
      ).length;
      console.log(`${cuisineTagCount} of ${recipes.length} recipes have the ${cuisineType} cuisine tag`);
    }
    
    return { recipes };
  } catch (error) {
    console.error("Failed to generate recipes with Spoonacular:", error);
    throw error;
  }
}