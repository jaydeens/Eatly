import axios from 'axios';
import { FoodAnalysisResult } from './openai';

const CLARIFAI_API_KEY = process.env.CLARIFAI_API_KEY;
const CLARIFAI_API_URL = 'https://api.clarifai.com/v2';

// Food detection model ID (Clarifai Food model)
const FOOD_MODEL_ID = 'bd367be194cf45149e75f01d59f77ba7';

if (!CLARIFAI_API_KEY) {
  console.error("CLARIFAI_API_KEY environment variable is not set. Food detection features will not work properly.");
}

interface ClarifaiConcept {
  id: string;
  name: string;
  value: number; // Confidence score (0-1)
}

// Analyze food image using Clarifai's food model
export async function analyzeFoodImageWithClarifai(base64Image: string): Promise<string[]> {
  if (!CLARIFAI_API_KEY) {
    throw new Error("CLARIFAI_API_KEY environment variable is not set");
  }

  try {
    // Strip data URI prefix if present
    const base64Data = base64Image.replace(/^data:image\/(png|jpeg|jpg);base64,/, '');

    const response = await axios.post(
      `${CLARIFAI_API_URL}/models/${FOOD_MODEL_ID}/outputs`,
      {
        inputs: [
          {
            data: {
              image: {
                base64: base64Data
              }
            }
          }
        ]
      },
      {
        headers: {
          'Authorization': `Key ${CLARIFAI_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    // Extract concepts from Clarifai response
    const concepts: ClarifaiConcept[] = response.data.outputs[0].data.concepts;

    // Filter concepts with confidence > 0.6 and map to food names
    const detectedFood = concepts
      .filter(concept => concept.value > 0.6)
      .map(concept => concept.name);

    return detectedFood;
  } catch (error) {
    console.error("Failed to analyze image with Clarifai:", error);

    let errorMessage = "Failed to analyze food image";
    
    if (axios.isAxiosError(error)) {
      const statusCode = error.response?.status;
      const errorData = error.response?.data;
      
      if (statusCode === 401 || statusCode === 403) {
        errorMessage = "API key is invalid or has insufficient permissions. Please check your Clarifai API key settings.";
      } else if (statusCode === 429) {
        errorMessage = "API request limit exceeded. Please try again later.";
      } else if (errorData?.status?.description) {
        errorMessage = `Clarifai API error: ${errorData.status.description}`;
      }
    } else if (error instanceof Error) {
      errorMessage = error.message;
    }
    
    throw new Error(errorMessage);
  }
}

// Hybrid approach: Clarifai for food detection + OpenAI for nutritional analysis
export async function analyzeFoodImageHybrid(
  base64Image: string,
  analyzeNutritionFn: (foodItems: string[]) => Promise<FoodAnalysisResult>
): Promise<FoodAnalysisResult> {
  try {
    // Step 1: Detect food items with Clarifai
    const detectedFoodItems = await analyzeFoodImageWithClarifai(base64Image);
    
    if (!detectedFoodItems || detectedFoodItems.length === 0) {
      throw new Error("No food items detected in the image. Please try a clearer image of food.");
    }
    
    console.log("Detected food items:", detectedFoodItems);
    
    // Step 2: Use OpenAI for nutritional analysis of the detected food items
    const nutritionalAnalysis = await analyzeNutritionFn(detectedFoodItems);
    
    return nutritionalAnalysis;
  } catch (error) {
    console.error("Hybrid food image analysis failed:", error);
    throw error;
  }
}