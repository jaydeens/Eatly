import session from 'express-session';
import { Express } from 'express';
import { storage } from './storage';

declare module 'express-session' {
  interface SessionData {
    userId?: number;
    isAuthenticated?: boolean;
    isAdmin?: boolean;
  }
}

export function setupSession(app: Express) {
  // Use the sessionStore from the storage interface
  // This will use PostgreSQL if available, otherwise fallback to memory store
  const sessionStore = storage.sessionStore;

  // Enable trust proxy for session cookies when behind a proxy like Replit
  app.set('trust proxy', 1);

  // Add error handling for session store
  sessionStore.on('error', function(error) {
    console.error('Session store error:', error);
  });

  // Configure express-session
  app.use(
    session({
      secret: process.env.SESSION_SECRET || 'chef-bot-secret',
      resave: false, // Only save if session was modified
      saveUninitialized: false, // Don't save uninitialized sessions (reduces storage usage)
      store: sessionStore,
      cookie: {
        secure: false, // Must be false for development/Replit for cookies to be set
        maxAge: 1000 * 60 * 60 * 24 * 7, // 1 week
        sameSite: 'lax',
        httpOnly: true, // Ensures the cookie is sent only over HTTP(S), not client JS
        path: '/', // Ensure cookie is available for all paths
      },
      // Add rolling sessions to keep the user logged in during active use
      rolling: true,
      name: 'eatly.sid' // Custom name to avoid conflicts
    })
  );

  // Debug session middleware for all API routes
  app.use((req, res, next) => {
    if (req.path.startsWith('/api/')) {
      console.log(`Session debug [${req.method} ${req.path}]:`, {
        sessionID: req.sessionID,
        hasSession: !!req.session,
        isAuthenticated: req.session?.isAuthenticated,
        userId: req.session?.userId,
      });
    }
    next();
  });
}