import { 
  recipes, type Recipe, type InsertRecipe, 
  users, type User, type InsertUser,
  nutritionLogs, type NutritionLog, type InsertNutritionLog,
  nutritionGoals, type NutritionGoal, type InsertNutritionGoal,
  weightLogs, type WeightLog, type InsertWeightLog,
  notificationPreferences, type NotificationPreferences, type InsertNotificationPreferences,
  timerSettings, type TimerSettings, type InsertTimerSettings,
  cookingProgress, type CookingProgress, type InsertCookingProgress,
  badges, type Badge, type InsertBadge,
  userBadges, type UserBadge, type InsertUserBadge,
  cookingChallenges, type CookingChallenge, type InsertCookingChallenge,
  userChallengeProgress, type UserChallengeProgress, type InsertUserChallengeProgress
} from "@shared/schema";
import { drizzle } from "drizzle-orm/postgres-js";
import { eq, sql, desc, count } from "drizzle-orm";
import pg from "pg";
import connectPgSimple from "connect-pg-simple";
import session from "express-session";
import dotenv from "dotenv";
import memorystore from "memorystore";

const { Pool, Client } = pg;

dotenv.config();

const databaseUrl = process.env.DATABASE_URL;

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByProviderId(provider: string, providerId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User>;
  getRecipes(): Promise<Recipe[]>;
  getRecipe(id: number): Promise<Recipe | undefined>;
  saveRecipe(recipe: InsertRecipe): Promise<Recipe>;
  getUserSavedRecipes(userId: number): Promise<Recipe[]>;
  
  // Nutrition tracking methods
  getNutritionLogs(userId: number, startDate?: Date, endDate?: Date): Promise<NutritionLog[]>;
  getNutritionLog(id: number): Promise<NutritionLog | undefined>;
  saveNutritionLog(log: InsertNutritionLog): Promise<NutritionLog>;
  getNutritionLogsByRecipe(recipeId: number): Promise<NutritionLog[]>;
  getUserNutritionStats(userId: number, period?: 'day' | 'week' | 'month'): Promise<{
    totalLogs: number;
    averageHealthScore: number;
    averageCalories: number;
    topFoodItems: {item: string, count: number}[];
    periodStart?: Date;
    periodEnd?: Date;
  }>;
  
  // Nutrition goals methods
  getNutritionGoals(userId: number): Promise<NutritionGoal | undefined>;
  saveNutritionGoals(goals: InsertNutritionGoal): Promise<NutritionGoal>;
  updateNutritionGoals(userId: number, goals: Partial<NutritionGoal>): Promise<NutritionGoal>;
  
  // Weight tracking methods
  getWeightLogs(userId: number, startDate?: Date, endDate?: Date): Promise<WeightLog[]>;
  getLatestWeightLog(userId: number): Promise<WeightLog | undefined>;
  saveWeightLog(log: InsertWeightLog): Promise<WeightLog>;
  
  // Notification preferences methods
  getNotificationPreferences(userId: number): Promise<NotificationPreferences | undefined>;
  saveNotificationPreferences(prefs: InsertNotificationPreferences): Promise<NotificationPreferences>;
  updateNotificationPreferences(userId: number, prefs: Partial<NotificationPreferences>): Promise<NotificationPreferences>;
  getUsersForDailyNotifications(): Promise<User[]>;
  
  // Health assessment method
  getHealthAssessment(userId: number): Promise<{
    bmi: number;
    status: string;
    weightTrend: 'gaining' | 'losing' | 'stable';
    recommendation: string;
    prediction: {
      estimatedWeightIn30Days: number;
      confidence: number;
    };
  }>;
  
  // Kitchen Timer methods
  getTimerSettings(userId: number): Promise<TimerSettings[]>;
  getTimerSetting(id: number): Promise<TimerSettings | undefined>;
  saveTimerSetting(setting: InsertTimerSettings): Promise<TimerSettings>;
  updateTimerSetting(id: number, setting: Partial<TimerSettings>): Promise<TimerSettings>;
  deleteTimerSetting(id: number): Promise<boolean>;
  
  // Cooking Progress methods
  getCookingProgresses(userId: number): Promise<CookingProgress[]>;
  getCookingProgress(id: number): Promise<CookingProgress | undefined>;
  getCookingProgressByRecipe(userId: number, recipeId: number): Promise<CookingProgress | undefined>;
  saveCookingProgress(progress: InsertCookingProgress): Promise<CookingProgress>;
  updateCookingProgress(id: number, progress: Partial<CookingProgress>): Promise<CookingProgress>;
  completeCookingProgress(id: number, endTime?: Date): Promise<CookingProgress>;
  
  // Badge methods
  getBadges(category?: string, season?: string): Promise<Badge[]>;
  getBadge(id: number): Promise<Badge | undefined>;
  getBadgeByName(name: string): Promise<Badge | undefined>;
  saveBadge(badge: InsertBadge): Promise<Badge>;
  getUserBadges(userId: number): Promise<(Badge & { earnedAt: Date, progress: number })[]>;
  awardBadgeToUser(userId: number, badgeId: number, progress?: number): Promise<UserBadge>;
  updateUserBadgeProgress(userId: number, badgeId: number, progress: number): Promise<UserBadge>;
  
  // Challenge methods
  getActiveChallenges(season?: string): Promise<CookingChallenge[]>;
  getChallenge(id: number): Promise<CookingChallenge | undefined>;
  saveChallenge(challenge: InsertCookingChallenge): Promise<CookingChallenge>;
  getUserChallenges(userId: number): Promise<(CookingChallenge & { progress: number, isCompleted: boolean })[]>;
  startChallenge(userId: number, challengeId: number): Promise<UserChallengeProgress>;
  updateChallengeProgress(userId: number, challengeId: number, recipeId?: number): Promise<UserChallengeProgress>;
  completeChallenge(userId: number, challengeId: number): Promise<UserChallengeProgress>;
  
  // Session store
  sessionStore: session.Store;
  
  // Initialize database
  initDb(): Promise<void>;
}

// Using a standard pg Pool for session store and database setup
const pool = new Pool({
  connectionString: databaseUrl,
  // Set shorter timeout to fail fast rather than hang
  connectionTimeoutMillis: 10000,
  // Add connection pool settings to improve reliability
  max: 10, // Maximum number of clients the pool should contain
  idleTimeoutMillis: 30000, // How long a client is allowed to remain idle before being closed
});

// Add error handler to the pool
pool.on('error', (err) => {
  console.error('Unexpected error on idle client', err);
});

// Create PostgreSQL session store
const PostgresSessionStore = connectPgSimple(session);

export class DatabaseStorage implements IStorage {
  private db: any; // Will initialize in constructor
  private client: any; // Will initialize in constructor
  sessionStore: session.Store;
  
  constructor() {
    // Set up session store
    this.sessionStore = new PostgresSessionStore({
      pool,
      tableName: 'session', // Default table name
      createTableIfMissing: true,
    });
    
    // Will initialize client and db in initDb()
  }
  
  async initDb(): Promise<void> {
    let retries = 5;
    let lastError;
    
    while (retries > 0) {
      try {
        // Create the client with better timeout settings
        this.client = new Client({
          connectionString: databaseUrl,
          connectionTimeoutMillis: 10000, // 10 seconds
        });
        
        // Connect with timeout
        await this.client.connect();
        
        // Set up Drizzle ORM with the client
        // this.db = drizzle(this.client);
        
        // Initialize schema
        await this.createTables();
        
        // Update existing tables with any missing columns
        await this.updateExistingTables();
        
        // Add demo user if none exists
        const hasUsers = await this.hasAnyUsers();
        if (!hasUsers) {
          await this.createDemoUser();
        }
        
        console.log("Database initialized successfully");
        return; // Success! Exit the function
      } catch (error) {
        lastError = error;
        console.error(`Database initialization attempt failed (${retries} retries left):`, error);
        
        // Close the client if it was created
        if (this.client) {
          try {
            await this.client.end();
          } catch (closeError) {
            console.error("Error closing client:", closeError);
          }
        }
        
        retries--;
        
        if (retries > 0) {
          // Exponential backoff: wait longer between each retry
          const waitTime = Math.pow(2, 5 - retries) * 1000; // 1s, 2s, 4s, 8s, 16s
          console.log(`Waiting ${waitTime}ms before retrying...`);
          await new Promise(resolve => setTimeout(resolve, waitTime));
        }
      }
    }
    
    // If we've exhausted all retries, log the error and fall back to memory storage
    console.error("Failed to initialize database after multiple retries:", lastError);
    console.log("Falling back to in-memory storage to allow application to function");
    throw lastError;
  }
  
  private async createTables(): Promise<void> {
    // SQL to create tables if they don't exist
    const createUsersTable = `
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT,
        name TEXT,
        email TEXT UNIQUE,
        image TEXT,
        provider TEXT DEFAULT 'credentials',
        providerId TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        date_of_birth TIMESTAMP WITH TIME ZONE,
        is_pregnant BOOLEAN,
        allergies TEXT[],
        medical_conditions TEXT[],
        dietary_restrictions TEXT[],
        height_cm INTEGER,
        weight_kg INTEGER,
        last_weight_update TIMESTAMP WITH TIME ZONE,
        target_weight_kg INTEGER,
        notifications_enabled BOOLEAN DEFAULT TRUE
      );
    `;
    
    const createRecipesTable = `
      CREATE TABLE IF NOT EXISTS recipes (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        image TEXT NOT NULL,
        time TEXT NOT NULL,
        servings INTEGER NOT NULL,
        calories INTEGER NOT NULL,
        difficulty TEXT NOT NULL,
        health_score INTEGER,
        tags TEXT[] NOT NULL,
        ingredients TEXT[] NOT NULL,
        instructions TEXT[] NOT NULL,
        nutrition JSONB NOT NULL,
        tips TEXT NOT NULL,
        user_id INTEGER REFERENCES users(id) NOT NULL
      );
    `;
    
    const createNutritionLogsTable = `
      CREATE TABLE IF NOT EXISTS nutrition_logs (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) NOT NULL,
        date TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
        meal_type TEXT NOT NULL,
        food_items TEXT[] NOT NULL,
        calories INTEGER,
        protein INTEGER,
        carbs INTEGER,
        fat INTEGER,
        fiber INTEGER,
        water INTEGER,
        health_score INTEGER,
        image_url TEXT,
        recipe_id INTEGER REFERENCES recipes(id),
        notes TEXT
      );
    `;
    
    const createNutritionGoalsTable = `
      CREATE TABLE IF NOT EXISTS nutrition_goals (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) NOT NULL,
        calories_target INTEGER,
        protein_target INTEGER,
        carbs_target INTEGER,
        fat_target INTEGER,
        fiber_target INTEGER,
        water_target INTEGER,
        health_score_target INTEGER,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;

    const createWeightLogsTable = `
      CREATE TABLE IF NOT EXISTS weight_logs (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) NOT NULL,
        date TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
        weight_kg INTEGER NOT NULL,
        notes TEXT,
        bmi INTEGER,
        prediction JSONB
      );
    `;

    const createNotificationPreferencesTable = `
      CREATE TABLE IF NOT EXISTS notification_preferences (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) NOT NULL,
        meal_suggestions BOOLEAN DEFAULT TRUE,
        weight_reminders BOOLEAN DEFAULT TRUE,
        nutrition_alerts BOOLEAN DEFAULT TRUE,
        preferred_time TEXT DEFAULT '08:00',
        last_notification TIMESTAMP WITH TIME ZONE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;

    // Execute the queries
    await this.client.query(createUsersTable);
    await this.client.query(createRecipesTable);
    await this.client.query(createNutritionLogsTable);
    await this.client.query(createNutritionGoalsTable);
    await this.client.query(createWeightLogsTable);
    await this.client.query(createNotificationPreferencesTable);
  }
  
  private async hasAnyUsers(): Promise<boolean> {
    const result = await this.client.query('SELECT COUNT(*) as count FROM users');
    return result.rows[0].count > 0;
  }
  
  // Method to update existing tables with missing columns
  private async updateExistingTables(): Promise<void> {
    try {
      // Update nutrition_logs table to add missing columns
      await this.addColumnsIfNotExist('nutrition_logs', [
        { name: 'fiber', type: 'INTEGER' },
        { name: 'water', type: 'INTEGER' },
        { name: 'recipe_id', type: 'INTEGER REFERENCES recipes(id)' },
        { name: 'notes', type: 'TEXT' }
      ]);
      
      console.log("Database tables updated successfully");
    } catch (error) {
      console.error("Error updating tables:", error);
      // Continue execution even if there's an error here
    }
  }
  
  // Helper method to add columns if they don't exist
  private async addColumnsIfNotExist(tableName: string, columns: Array<{name: string, type: string}>): Promise<void> {
    for (const column of columns) {
      // Check if the column exists
      const checkQuery = `
        SELECT column_name 
        FROM information_schema.columns 
        WHERE table_name = $1 
        AND column_name = $2;
      `;
      
      const result = await this.client.query(checkQuery, [tableName, column.name]);
      
      if (result.rows.length === 0) {
        // Column doesn't exist, add it
        const alterQuery = `
          ALTER TABLE ${tableName} 
          ADD COLUMN IF NOT EXISTS ${column.name} ${column.type};
        `;
        
        await this.client.query(alterQuery);
        console.log(`Added column ${column.name} to ${tableName}`);
      }
    }
  }
  
  // Badge methods - stubs for type compatibility
  async getBadges(category?: string, season?: string): Promise<Badge[]> {
    return [];
  }
  
  async getBadge(id: number): Promise<Badge | undefined> {
    return undefined;
  }
  
  async getBadgeByName(name: string): Promise<Badge | undefined> {
    return undefined;
  }
  
  async saveBadge(badge: InsertBadge): Promise<Badge> {
    throw new Error("Not implemented yet");
  }
  
  async getUserBadges(userId: number): Promise<(Badge & { earnedAt: Date, progress: number })[]> {
    return [];
  }
  
  async awardBadgeToUser(userId: number, badgeId: number, progress?: number): Promise<UserBadge> {
    throw new Error("Not implemented yet");
  }
  
  async updateUserBadgeProgress(userId: number, badgeId: number, progress: number): Promise<UserBadge> {
    throw new Error("Not implemented yet");
  }
  
  // Challenge methods - stubs for type compatibility
  async getActiveChallenges(season?: string): Promise<CookingChallenge[]> {
    return [];
  }
  
  async getChallenge(id: number): Promise<CookingChallenge | undefined> {
    return undefined;
  }
  
  async saveChallenge(challenge: InsertCookingChallenge): Promise<CookingChallenge> {
    throw new Error("Not implemented yet");
  }
  
  async getUserChallenges(userId: number): Promise<(CookingChallenge & { progress: number, isCompleted: boolean })[]> {
    return [];
  }
  
  async startChallenge(userId: number, challengeId: number): Promise<UserChallengeProgress> {
    throw new Error("Not implemented yet");
  }
  
  async updateChallengeProgress(userId: number, challengeId: number, recipeId?: number): Promise<UserChallengeProgress> {
    throw new Error("Not implemented yet");
  }
  
  async completeChallenge(userId: number, challengeId: number): Promise<UserChallengeProgress> {
    throw new Error("Not implemented yet");
  }
  
  private async createDemoUser(): Promise<void> {
    const demoUser = {
      username: 'demouser',
      password: '$2b$10$kItG5EeOZkKRxGS9bGQKP.LbLlWRJhU34sGAYUeaDDWDGJnfu27.6', // 'password123'
      name: 'Demo User',
      email: 'demo@example.com',
      image: 'https://ui-avatars.com/api/?name=Demo+User&background=ff8c00&color=fff',
      provider: 'credentials',
      providerId: null,
      date_of_birth: new Date('1990-01-15'), // Convert string to Date object
      is_pregnant: false,
      allergies: ['peanuts'],
      medical_conditions: [],
      dietary_restrictions: ['vegetarian']
    };
    
    const query = `
      INSERT INTO users (
        username, password, name, email, image, provider, providerId, 
        date_of_birth, is_pregnant, allergies, medical_conditions, dietary_restrictions
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12
      ) RETURNING *;
    `;
    
    try {
      await this.client.query(query, [
        demoUser.username,
        demoUser.password,
        demoUser.name,
        demoUser.email,
        demoUser.image,
        demoUser.provider,
        demoUser.providerId,
        demoUser.date_of_birth,
        demoUser.is_pregnant,
        demoUser.allergies,
        demoUser.medical_conditions,
        demoUser.dietary_restrictions
      ]);
      
      console.log("Demo user created successfully");
    } catch (error) {
      console.error("Error creating demo user:", error);
      // Don't throw the error as this is not critical functionality
      // Just log it and continue
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    const query = 'SELECT * FROM users WHERE id = $1';
    const result = await this.client.query(query, [id]);
    
    if (result.rows.length === 0) {
      return undefined;
    }
    
    // Convert database snake_case to camelCase
    return this.transformUserFromDb(result.rows[0]);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const query = 'SELECT * FROM users WHERE username = $1';
    const result = await this.client.query(query, [username]);
    
    if (result.rows.length === 0) {
      return undefined;
    }
    
    return this.transformUserFromDb(result.rows[0]);
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const query = 'SELECT * FROM users WHERE email = $1';
    const result = await this.client.query(query, [email]);
    
    if (result.rows.length === 0) {
      return undefined;
    }
    
    return this.transformUserFromDb(result.rows[0]);
  }
  
  async getUserByProviderId(provider: string, providerId: string): Promise<User | undefined> {
    const query = 'SELECT * FROM users WHERE provider = $1 AND providerId = $2';
    const result = await this.client.query(query, [provider, providerId]);
    
    if (result.rows.length === 0) {
      return undefined;
    }
    
    return this.transformUserFromDb(result.rows[0]);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const query = `
      INSERT INTO users (
        username, password, name, email, image, provider, providerId, 
        date_of_birth, is_pregnant, allergies, medical_conditions, dietary_restrictions
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12
      ) RETURNING *;
    `;
    
    try {
      const result = await this.client.query(query, [
        insertUser.username,
        insertUser.password || null,
        insertUser.name || null,
        insertUser.email || null,
        insertUser.image || null,
        insertUser.provider || 'credentials',
        insertUser.providerId || null,
        insertUser.dateOfBirth || null, // This should now be a properly typed Date object
        insertUser.isPregnant || false,
        insertUser.allergies || [],
        insertUser.medicalConditions || [],
        insertUser.dietaryRestrictions || []
      ]);
      
      return this.transformUserFromDb(result.rows[0]);
    } catch (error: any) { // Explicitly type error as any
      console.error('Error creating user:', error);
      if (typeof error.message === 'string') {
        if (error.message.includes('duplicate key') && error.message.includes('username')) {
          throw new Error('Username already exists');
        } else if (error.message.includes('duplicate key') && error.message.includes('email')) {
          throw new Error('Email already exists');
        }
      }
      throw error;
    }
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    // First get the current user to ensure they exist
    const currentUser = await this.getUser(id);
    
    if (!currentUser) {
      throw new Error(`User with ID ${id} not found`);
    }
    
    // Build the update query dynamically based on which fields are provided
    let updateFields = [];
    let values = [];
    let valueIndex = 1;
    
    if (userData.username !== undefined) {
      updateFields.push(`username = $${valueIndex++}`);
      values.push(userData.username);
    }
    
    if (userData.password !== undefined) {
      updateFields.push(`password = $${valueIndex++}`);
      values.push(userData.password);
    }
    
    if (userData.name !== undefined) {
      updateFields.push(`name = $${valueIndex++}`);
      values.push(userData.name);
    }
    
    if (userData.email !== undefined) {
      updateFields.push(`email = $${valueIndex++}`);
      values.push(userData.email);
    }
    
    if (userData.image !== undefined) {
      updateFields.push(`image = $${valueIndex++}`);
      values.push(userData.image);
    }
    
    if (userData.provider !== undefined) {
      updateFields.push(`provider = $${valueIndex++}`);
      values.push(userData.provider);
    }
    
    if (userData.providerId !== undefined) {
      updateFields.push(`providerId = $${valueIndex++}`);
      values.push(userData.providerId);
    }
    
    if (userData.dateOfBirth !== undefined) {
      updateFields.push(`date_of_birth = $${valueIndex++}`);
      values.push(userData.dateOfBirth);
    }
    
    if (userData.isPregnant !== undefined) {
      updateFields.push(`is_pregnant = $${valueIndex++}`);
      values.push(userData.isPregnant);
    }
    
    if (userData.allergies !== undefined) {
      updateFields.push(`allergies = $${valueIndex++}`);
      values.push(userData.allergies);
    }
    
    if (userData.medicalConditions !== undefined) {
      updateFields.push(`medical_conditions = $${valueIndex++}`);
      values.push(userData.medicalConditions);
    }
    
    if (userData.dietaryRestrictions !== undefined) {
      updateFields.push(`dietary_restrictions = $${valueIndex++}`);
      values.push(userData.dietaryRestrictions);
    }
    
    // Add the user ID at the end
    values.push(id);
    
    // If there are no fields to update, just return the current user
    if (updateFields.length === 0) {
      return currentUser;
    }
    
    // Create the query
    const query = `
      UPDATE users
      SET ${updateFields.join(', ')}
      WHERE id = $${valueIndex}
      RETURNING *;
    `;
    
    const result = await this.client.query(query, values);
    return this.transformUserFromDb(result.rows[0]);
  }
  
  async getUserSavedRecipes(userId: number): Promise<Recipe[]> {
    const query = 'SELECT * FROM recipes WHERE user_id = $1';
    const result = await this.client.query(query, [userId]);
    
    return result.rows.map(this.transformRecipeFromDb);
  }

  async getRecipes(): Promise<Recipe[]> {
    const query = 'SELECT * FROM recipes';
    const result = await this.client.query(query);
    
    return result.rows.map(this.transformRecipeFromDb);
  }

  async getRecipe(id: number): Promise<Recipe | undefined> {
    const query = 'SELECT * FROM recipes WHERE id = $1';
    const result = await this.client.query(query, [id]);
    
    if (result.rows.length === 0) {
      return undefined;
    }
    
    return this.transformRecipeFromDb(result.rows[0]);
  }

  async saveRecipe(insertRecipe: InsertRecipe): Promise<Recipe> {
    const query = `
      INSERT INTO recipes (
        title, description, image, time, servings, calories, difficulty,
        health_score, tags, ingredients, instructions, nutrition, tips, user_id
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14
      ) RETURNING *;
    `;
    
    const result = await this.client.query(query, [
      insertRecipe.title,
      insertRecipe.description,
      insertRecipe.image,
      insertRecipe.time,
      insertRecipe.servings,
      insertRecipe.calories,
      insertRecipe.difficulty,
      insertRecipe.healthScore || null,
      insertRecipe.tags,
      insertRecipe.ingredients,
      insertRecipe.instructions,
      JSON.stringify(insertRecipe.nutrition),
      insertRecipe.tips,
      insertRecipe.userId
    ]);
    
    return this.transformRecipeFromDb(result.rows[0]);
  }

  async getNutritionLogs(userId: number): Promise<NutritionLog[]> {
    const query = 'SELECT * FROM nutrition_logs WHERE user_id = $1 ORDER BY date DESC';
    const result = await this.client.query(query, [userId]);
    
    return result.rows.map(this.transformNutritionLogFromDb);
  }

  async getNutritionLog(id: number): Promise<NutritionLog | undefined> {
    const query = 'SELECT * FROM nutrition_logs WHERE id = $1';
    const result = await this.client.query(query, [id]);
    
    if (result.rows.length === 0) {
      return undefined;
    }
    
    return this.transformNutritionLogFromDb(result.rows[0]);
  }

  async saveNutritionLog(insertLog: InsertNutritionLog): Promise<NutritionLog> {
    const query = `
      INSERT INTO nutrition_logs (
        user_id, date, meal_type, food_items, calories, protein, carbs, fat,
        fiber, water, health_score, image_url, recipe_id, notes
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14
      ) RETURNING *;
    `;
    
    const result = await this.client.query(query, [
      insertLog.userId,
      insertLog.date || new Date(),
      insertLog.mealType,
      insertLog.foodItems,
      insertLog.calories || null,
      insertLog.protein || null,
      insertLog.carbs || null,
      insertLog.fat || null,
      insertLog.fiber || null,
      insertLog.water || null,
      insertLog.healthScore || null,
      insertLog.imageUrl || null,
      insertLog.recipeId || null,
      insertLog.notes || null
    ]);
    
    return this.transformNutritionLogFromDb(result.rows[0]);
  }
  
  async getNutritionLogsByRecipe(recipeId: number): Promise<NutritionLog[]> {
    const query = 'SELECT * FROM nutrition_logs WHERE recipe_id = $1 ORDER BY date DESC';
    const result = await this.client.query(query, [recipeId]);
    return result.rows.map((row: Record<string, any>) => this.transformNutritionLogFromDb(row));
  }
  
  async getNutritionGoals(userId: number): Promise<NutritionGoal | undefined> {
    const query = 'SELECT * FROM nutrition_goals WHERE user_id = $1';
    const result = await this.client.query(query, [userId]);
    
    if (result.rows.length === 0) {
      return undefined;
    }
    
    return {
      id: result.rows[0].id,
      userId: result.rows[0].user_id,
      caloriesTarget: result.rows[0].calories_target,
      proteinTarget: result.rows[0].protein_target,
      carbsTarget: result.rows[0].carbs_target,
      fatTarget: result.rows[0].fat_target,
      fiberTarget: result.rows[0].fiber_target,
      waterTarget: result.rows[0].water_target,
      healthScoreTarget: result.rows[0].health_score_target,
      createdAt: result.rows[0].created_at,
      updatedAt: result.rows[0].updated_at,
    };
  }
  
  async saveNutritionGoals(goals: InsertNutritionGoal): Promise<NutritionGoal> {
    const query = `
      INSERT INTO nutrition_goals (
        user_id, calories_target, protein_target, carbs_target, fat_target, 
        fiber_target, water_target, health_score_target, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING *
    `;
    
    const now = new Date();
    const result = await this.client.query(query, [
      goals.userId,
      goals.caloriesTarget || null,
      goals.proteinTarget || null,
      goals.carbsTarget || null,
      goals.fatTarget || null,
      goals.fiberTarget || null,
      goals.waterTarget || null,
      goals.healthScoreTarget || null,
      now,
      now,
    ]);
    
    return {
      id: result.rows[0].id,
      userId: result.rows[0].user_id,
      caloriesTarget: result.rows[0].calories_target,
      proteinTarget: result.rows[0].protein_target,
      carbsTarget: result.rows[0].carbs_target,
      fatTarget: result.rows[0].fat_target,
      fiberTarget: result.rows[0].fiber_target,
      waterTarget: result.rows[0].water_target,
      healthScoreTarget: result.rows[0].health_score_target,
      createdAt: result.rows[0].created_at,
      updatedAt: result.rows[0].updated_at,
    };
  }
  
  // Weight tracking methods
  async getWeightLogs(userId: number, startDate?: Date, endDate?: Date): Promise<WeightLog[]> {
    let query = 'SELECT * FROM weight_logs WHERE user_id = $1';
    const params: any[] = [userId];
    
    if (startDate) {
      query += ' AND date >= $2';
      params.push(startDate);
    }
    
    if (endDate) {
      query += ' AND date <= $' + (params.length + 1);
      params.push(endDate);
    }
    
    query += ' ORDER BY date DESC';
    
    const result = await this.client.query(query, params);
    
    return result.rows.map((row: Record<string, any>) => ({
      id: row.id,
      userId: row.user_id,
      date: new Date(row.date),
      weightKg: row.weight_kg,
      notes: row.notes,
      bmi: row.bmi,
      prediction: row.prediction ? 
        (typeof row.prediction === 'string' ? JSON.parse(row.prediction) : row.prediction) : null
    }));
  }
  
  async getLatestWeightLog(userId: number): Promise<WeightLog | undefined> {
    const query = 'SELECT * FROM weight_logs WHERE user_id = $1 ORDER BY date DESC LIMIT 1';
    const result = await this.client.query(query, [userId]);
    
    if (result.rows.length === 0) {
      return undefined;
    }
    
    return {
      id: result.rows[0].id,
      userId: result.rows[0].user_id,
      date: new Date(result.rows[0].date),
      weightKg: result.rows[0].weight_kg,
      notes: result.rows[0].notes,
      bmi: result.rows[0].bmi,
      prediction: result.rows[0].prediction ?
        (typeof result.rows[0].prediction === 'string' ? JSON.parse(result.rows[0].prediction) : result.rows[0].prediction) : null
    };
  }
  
  async saveWeightLog(log: InsertWeightLog): Promise<WeightLog> {
    const query = `
      INSERT INTO weight_logs (
        user_id, date, weight_kg, notes, bmi, prediction
      ) VALUES (
        $1, $2, $3, $4, $5, $6
      ) RETURNING *;
    `;
    
    const result = await this.client.query(query, [
      log.userId,
      log.date || new Date(),
      log.weightKg,
      log.notes || null,
      log.bmi || null,
      log.prediction ? JSON.stringify(log.prediction) : null
    ]);
    
    return {
      id: result.rows[0].id,
      userId: result.rows[0].user_id,
      date: new Date(result.rows[0].date),
      weightKg: result.rows[0].weight_kg,
      notes: result.rows[0].notes,
      bmi: result.rows[0].bmi,
      prediction: result.rows[0].prediction ?
        (typeof result.rows[0].prediction === 'string' ? JSON.parse(result.rows[0].prediction) : result.rows[0].prediction) : null
    };
  }
  
  // Notification preferences methods
  async getNotificationPreferences(userId: number): Promise<NotificationPreferences | undefined> {
    const query = 'SELECT * FROM notification_preferences WHERE user_id = $1';
    const result = await this.client.query(query, [userId]);
    
    if (result.rows.length === 0) {
      return undefined;
    }
    
    return {
      id: result.rows[0].id,
      userId: result.rows[0].user_id,
      mealSuggestions: result.rows[0].meal_suggestions,
      weightReminders: result.rows[0].weight_reminders,
      nutritionAlerts: result.rows[0].nutrition_alerts,
      preferredTime: result.rows[0].preferred_time,
      lastNotification: result.rows[0].last_notification ? new Date(result.rows[0].last_notification) : null,
      createdAt: new Date(result.rows[0].created_at),
      updatedAt: new Date(result.rows[0].updated_at)
    };
  }
  
  async saveNotificationPreferences(prefs: InsertNotificationPreferences): Promise<NotificationPreferences> {
    const query = `
      INSERT INTO notification_preferences (
        user_id, meal_suggestions, weight_reminders, nutrition_alerts, 
        preferred_time, last_notification, created_at, updated_at
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8
      ) RETURNING *;
    `;
    
    const now = new Date();
    const result = await this.client.query(query, [
      prefs.userId,
      prefs.mealSuggestions !== undefined ? prefs.mealSuggestions : true,
      prefs.weightReminders !== undefined ? prefs.weightReminders : true,
      prefs.nutritionAlerts !== undefined ? prefs.nutritionAlerts : true,
      prefs.preferredTime || '08:00',
      prefs.lastNotification || null,
      now,
      now
    ]);
    
    return {
      id: result.rows[0].id,
      userId: result.rows[0].user_id,
      mealSuggestions: result.rows[0].meal_suggestions,
      weightReminders: result.rows[0].weight_reminders,
      nutritionAlerts: result.rows[0].nutrition_alerts,
      preferredTime: result.rows[0].preferred_time,
      lastNotification: result.rows[0].last_notification ? new Date(result.rows[0].last_notification) : null,
      createdAt: new Date(result.rows[0].created_at),
      updatedAt: new Date(result.rows[0].updated_at)
    };
  }
  
  async updateNotificationPreferences(userId: number, prefs: Partial<NotificationPreferences>): Promise<NotificationPreferences> {
    // First check if preferences exist for this user
    const existingPrefs = await this.getNotificationPreferences(userId);
    
    if (!existingPrefs) {
      // No preferences exist, create new ones
      return this.saveNotificationPreferences({
        ...prefs,
        userId,
      } as InsertNotificationPreferences);
    }
    
    // Build the SET clause for the update query
    const setClauses = [];
    const values: any[] = [userId]; // First parameter is always userId
    let paramIndex = 2; // Start parameter numbering from 2
    
    if (prefs.mealSuggestions !== undefined) {
      setClauses.push(`meal_suggestions = $${paramIndex++}`);
      values.push(prefs.mealSuggestions);
    }
    
    if (prefs.weightReminders !== undefined) {
      setClauses.push(`weight_reminders = $${paramIndex++}`);
      values.push(prefs.weightReminders);
    }
    
    if (prefs.nutritionAlerts !== undefined) {
      setClauses.push(`nutrition_alerts = $${paramIndex++}`);
      values.push(prefs.nutritionAlerts);
    }
    
    if (prefs.preferredTime !== undefined) {
      setClauses.push(`preferred_time = $${paramIndex++}`);
      values.push(prefs.preferredTime);
    }
    
    if (prefs.lastNotification !== undefined) {
      setClauses.push(`last_notification = $${paramIndex++}`);
      values.push(prefs.lastNotification);
    }
    
    // Always update the updated_at timestamp
    setClauses.push(`updated_at = $${paramIndex++}`);
    values.push(new Date());
    
    // If there are no fields to update, just return the existing preferences
    if (setClauses.length === 1) { // Only updated_at is being updated
      return existingPrefs;
    }
    
    // Create the query
    const query = `
      UPDATE notification_preferences
      SET ${setClauses.join(', ')}
      WHERE user_id = $1
      RETURNING *;
    `;
    
    const result = await this.client.query(query, values);
    
    return {
      id: result.rows[0].id,
      userId: result.rows[0].user_id,
      mealSuggestions: result.rows[0].meal_suggestions,
      weightReminders: result.rows[0].weight_reminders,
      nutritionAlerts: result.rows[0].nutrition_alerts,
      preferredTime: result.rows[0].preferred_time,
      lastNotification: result.rows[0].last_notification ? new Date(result.rows[0].last_notification) : null,
      createdAt: new Date(result.rows[0].created_at),
      updatedAt: new Date(result.rows[0].updated_at)
    };
  }
  
  async getUsersForDailyNotifications(): Promise<User[]> {
    const query = `
      SELECT u.* FROM users u
      JOIN notification_preferences np ON u.id = np.user_id
      WHERE u.notifications_enabled = TRUE
      AND (
        np.meal_suggestions = TRUE OR 
        np.weight_reminders = TRUE OR 
        np.nutrition_alerts = TRUE
      )
      AND (np.last_notification IS NULL OR np.last_notification < NOW() - INTERVAL '20 hours')
    `;
    
    const result = await this.client.query(query);
    return result.rows.map((row: any) => this.transformUserFromDb(row));
  }
  
  // Health assessment method
  async getHealthAssessment(userId: number): Promise<{
    bmi: number;
    status: string;
    weightTrend: 'gaining' | 'losing' | 'stable';
    recommendation: string;
    prediction: {
      estimatedWeightIn30Days: number;
      confidence: number;
    };
  }> {
    // Get the user's height, weight, and recent weight logs
    const user = await this.getUser(userId);
    if (!user || !user.heightCm || !user.weightKg) {
      throw new Error('User height and weight data is required for health assessment');
    }
    
    // Get weight logs for trend analysis
    const weightLogs = await this.getWeightLogs(userId);
    
    // Calculate BMI
    const heightInMeters = user.heightCm / 100;
    const bmi = Math.round((user.weightKg / (heightInMeters * heightInMeters)) * 10) / 10;
    
    // Determine BMI status
    let status = '';
    if (bmi < 18.5) {
      status = 'Underweight';
    } else if (bmi >= 18.5 && bmi < 25) {
      status = 'Normal weight';
    } else if (bmi >= 25 && bmi < 30) {
      status = 'Overweight';
    } else {
      status = 'Obese';
    }
    
    // Determine weight trend
    let weightTrend: 'gaining' | 'losing' | 'stable' = 'stable';
    let recommendation = '';
    let prediction = {
      estimatedWeightIn30Days: user.weightKg,
      confidence: 0.7
    };
    
    if (weightLogs.length >= 2) {
      // Sort logs by date (newest first)
      weightLogs.sort((a, b) => b.date.getTime() - a.date.getTime());
      
      // Compare current weight with previous weight
      const currentWeight = weightLogs[0].weightKg;
      const previousWeight = weightLogs[1].weightKg;
      
      if (currentWeight > previousWeight + 1) {
        weightTrend = 'gaining';
        recommendation = 'Consider watching your calorie intake and increasing physical activity.';
        prediction.estimatedWeightIn30Days = user.weightKg + Math.round((currentWeight - previousWeight) * 2);
      } else if (currentWeight < previousWeight - 1) {
        weightTrend = 'losing';
        recommendation = 'Keep up the good work if weight loss is your goal.';
        prediction.estimatedWeightIn30Days = user.weightKg - Math.round((previousWeight - currentWeight) * 2);
      } else {
        weightTrend = 'stable';
        recommendation = 'Your weight has been stable. Great job maintaining!';
      }
      
      prediction.confidence = 0.8; // Higher confidence with more data
    } else {
      // Not enough data for trend analysis
      recommendation = 'Keep logging your weight regularly for personalized recommendations.';
      prediction.confidence = 0.6; // Lower confidence with less data
    }
    
    // Make recommendation based on BMI
    if (status === 'Underweight') {
      recommendation += ' Consider consulting with a nutritionist about a healthy weight gain plan.';
    } else if (status === 'Overweight' || status === 'Obese') {
      recommendation += ' Consider a balanced diet and regular exercise for healthier weight.';
    }
    
    return {
      bmi,
      status,
      weightTrend,
      recommendation,
      prediction
    };
  }
  
  async updateNutritionGoals(userId: number, goals: Partial<NutritionGoal>): Promise<NutritionGoal> {
    // First check if goals exist for this user
    const existingGoals = await this.getNutritionGoals(userId);
    
    if (!existingGoals) {
      // No goals exist, create new ones
      return this.saveNutritionGoals({
        ...goals,
        userId,
      } as InsertNutritionGoal);
    }
    
    // Build the SET clause for the update query
    const setClauses = [];
    const values: (number | string | null)[] = [userId]; // First parameter is always userId
    let paramIndex = 2; // Start parameter numbering from 2
    
    if (goals.caloriesTarget !== undefined) {
      setClauses.push(`calories_target = $${paramIndex++}`);
      values.push(goals.caloriesTarget);
    }
    
    if (goals.proteinTarget !== undefined) {
      setClauses.push(`protein_target = $${paramIndex++}`);
      values.push(goals.proteinTarget);
    }
    
    if (goals.carbsTarget !== undefined) {
      setClauses.push(`carbs_target = $${paramIndex++}`);
      values.push(goals.carbsTarget);
    }
    
    if (goals.fatTarget !== undefined) {
      setClauses.push(`fat_target = $${paramIndex++}`);
      values.push(goals.fatTarget);
    }
    
    if (goals.fiberTarget !== undefined) {
      setClauses.push(`fiber_target = $${paramIndex++}`);
      values.push(goals.fiberTarget);
    }
    
    if (goals.waterTarget !== undefined) {
      setClauses.push(`water_target = $${paramIndex++}`);
      values.push(goals.waterTarget);
    }
    
    if (goals.healthScoreTarget !== undefined) {
      setClauses.push(`health_score_target = $${paramIndex++}`);
      values.push(goals.healthScoreTarget);
    }
    
    // Always update the updated_at timestamp
    setClauses.push(`updated_at = $${paramIndex++}`);
    values.push(new Date().toISOString());
    
    const query = `
      UPDATE nutrition_goals
      SET ${setClauses.join(', ')}
      WHERE user_id = $1
      RETURNING *
    `;
    
    const result = await this.client.query(query, values);
    
    return {
      id: result.rows[0].id,
      userId: result.rows[0].user_id,
      caloriesTarget: result.rows[0].calories_target,
      proteinTarget: result.rows[0].protein_target,
      carbsTarget: result.rows[0].carbs_target,
      fatTarget: result.rows[0].fat_target,
      fiberTarget: result.rows[0].fiber_target,
      waterTarget: result.rows[0].water_target,
      healthScoreTarget: result.rows[0].health_score_target,
      createdAt: result.rows[0].created_at,
      updatedAt: result.rows[0].updated_at,
    };
  }

  async getUserNutritionStats(userId: number, period?: 'day' | 'week' | 'month'): Promise<{
    totalLogs: number;
    averageHealthScore: number;
    averageCalories: number;
    topFoodItems: {item: string, count: number}[];
    periodStart?: Date;
    periodEnd?: Date;
  }> {
    let periodStart: Date | undefined;
    let periodEnd: Date | undefined = new Date(); // Current time as period end
    let queryParams: (number | string)[] = [userId];
    let dateFilter = '';
    
    // Add period filter if specified
    if (period) {
      periodStart = new Date();
      
      switch (period) {
        case 'day':
          // Set to start of current day
          periodStart.setHours(0, 0, 0, 0);
          break;
        case 'week':
          // Set to 7 days ago
          periodStart.setDate(periodStart.getDate() - 7);
          break;
        case 'month':
          // Set to 30 days ago
          periodStart.setDate(periodStart.getDate() - 30);
          break;
      }
      
      dateFilter = ' AND date >= $2 AND date <= $3';
      queryParams.push(periodStart.toISOString());
      queryParams.push(periodEnd.toISOString());
    }
    
    // Get total logs
    const countQuery = `SELECT COUNT(*) as count FROM nutrition_logs WHERE user_id = $1${dateFilter}`;
    const countResult = await this.client.query(countQuery, queryParams);
    const totalLogs = parseInt(countResult.rows[0].count);
    
    if (totalLogs === 0) {
      return {
        totalLogs: 0,
        averageHealthScore: 0,
        averageCalories: 0,
        topFoodItems: [],
        periodStart,
        periodEnd
      };
    }
    
    // Get average health score
    const healthScoreQuery = `SELECT AVG(health_score) as avg_score FROM nutrition_logs 
      WHERE user_id = $1${dateFilter} AND health_score IS NOT NULL`;
    const healthScoreResult = await this.client.query(healthScoreQuery, queryParams);
    const averageHealthScore = parseFloat(healthScoreResult.rows[0].avg_score || 0);
    
    // Get average calories
    const caloriesQuery = `SELECT AVG(calories) as avg_calories FROM nutrition_logs 
      WHERE user_id = $1${dateFilter} AND calories IS NOT NULL`;
    const caloriesResult = await this.client.query(caloriesQuery, queryParams);
    const averageCalories = parseFloat(caloriesResult.rows[0].avg_calories || 0);
    
    // Get top food items (this is trickier with PostgreSQL arrays)
    // We'll get all the food items, then process them in JavaScript
    const foodItemsQuery = `SELECT food_items FROM nutrition_logs WHERE user_id = $1${dateFilter}`;
    const foodItemsResult = await this.client.query(foodItemsQuery, queryParams);
    
    // Count occurrences of each food item
    const foodItemsMap = new Map<string, number>();
    
    foodItemsResult.rows.forEach((row: { food_items: string[] }) => {
      row.food_items.forEach((item: string) => {
        const currentCount = foodItemsMap.get(item) || 0;
        foodItemsMap.set(item, currentCount + 1);
      });
    });
    
    const topFoodItems = Array.from(foodItemsMap.entries())
      .map(([item, count]) => ({ item, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5); // Get top 5 items
    
    return {
      totalLogs,
      averageHealthScore: Number(averageHealthScore.toFixed(1)),
      averageCalories: Math.round(averageCalories),
      topFoodItems,
      periodStart,
      periodEnd
    };
  }
  
  // Helper methods to transform database records to camelCase TypeScript types
  private transformUserFromDb(dbUser: Record<string, any>): User {
    return {
      id: dbUser.id,
      username: dbUser.username,
      password: dbUser.password,
      name: dbUser.name,
      email: dbUser.email,
      image: dbUser.image,
      provider: dbUser.provider,
      providerId: dbUser.providerid,
      createdAt: new Date(dbUser.created_at),
      dateOfBirth: dbUser.date_of_birth,
      isPregnant: dbUser.is_pregnant,
      allergies: dbUser.allergies || [],
      medicalConditions: dbUser.medical_conditions || [],
      dietaryRestrictions: dbUser.dietary_restrictions || [],
      heightCm: dbUser.height_cm,
      weightKg: dbUser.weight_kg,
      lastWeightUpdate: dbUser.last_weight_update ? new Date(dbUser.last_weight_update) : null,
      targetWeightKg: dbUser.target_weight_kg,
      notificationsEnabled: dbUser.notifications_enabled !== false, // default to true if not set
      coachNickname: dbUser.coach_nickname || "PC" // Default to "PC" if not set
    };
  }
  
  private transformRecipeFromDb(dbRecipe: Record<string, any>): Recipe {
    return {
      id: dbRecipe.id,
      title: dbRecipe.title,
      description: dbRecipe.description,
      image: dbRecipe.image,
      time: dbRecipe.time,
      servings: dbRecipe.servings,
      calories: dbRecipe.calories,
      difficulty: dbRecipe.difficulty,
      healthScore: dbRecipe.health_score,
      tags: dbRecipe.tags,
      ingredients: dbRecipe.ingredients,
      instructions: dbRecipe.instructions,
      nutrition: typeof dbRecipe.nutrition === 'string' 
        ? JSON.parse(dbRecipe.nutrition) 
        : dbRecipe.nutrition,
      tips: dbRecipe.tips,
      userId: dbRecipe.user_id
    };
  }
  
  private transformNutritionLogFromDb(dbLog: Record<string, any>): NutritionLog {
    return {
      id: dbLog.id,
      userId: dbLog.user_id,
      date: new Date(dbLog.date),
      mealType: dbLog.meal_type,
      foodItems: dbLog.food_items,
      calories: dbLog.calories,
      protein: dbLog.protein,
      carbs: dbLog.carbs,
      fat: dbLog.fat,
      fiber: dbLog.fiber,
      water: dbLog.water,
      healthScore: dbLog.health_score,
      imageUrl: dbLog.image_url,
      recipeId: dbLog.recipe_id,
      notes: dbLog.notes
    };
  }
  
  // Kitchen Timer methods
  async getTimerSettings(userId: number): Promise<TimerSettings[]> {
    const { rows } = await this.db.query(
      `SELECT * FROM timer_settings WHERE user_id = $1 ORDER BY name ASC`,
      [userId]
    );
    return rows.map((row: any) => ({
      id: row.id,
      userId: row.user_id,
      name: row.name,
      durationSeconds: row.duration_seconds,
      isMuted: row.is_muted,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    }));
  }
  
  async getTimerSetting(id: number): Promise<TimerSettings | undefined> {
    const { rows } = await this.db.query(
      `SELECT * FROM timer_settings WHERE id = $1`,
      [id]
    );
    
    if (rows.length === 0) {
      return undefined;
    }
    
    const row = rows[0];
    return {
      id: row.id,
      userId: row.user_id,
      name: row.name,
      durationSeconds: row.duration_seconds,
      isMuted: row.is_muted,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  }
  
  async saveTimerSetting(setting: InsertTimerSettings): Promise<TimerSettings> {
    const { rows } = await this.db.query(
      `INSERT INTO timer_settings 
      (user_id, name, duration_seconds, is_muted, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *`,
      [
        setting.userId,
        setting.name,
        setting.durationSeconds,
        setting.isMuted || false,
        new Date(),
        new Date()
      ]
    );
    
    const row = rows[0];
    return {
      id: row.id,
      userId: row.user_id,
      name: row.name,
      durationSeconds: row.duration_seconds,
      isMuted: row.is_muted,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  }
  
  async updateTimerSetting(id: number, setting: Partial<TimerSettings>): Promise<TimerSettings> {
    // Get current setting to merge with updates
    const currentSetting = await this.getTimerSetting(id);
    
    if (!currentSetting) {
      throw new Error(`Timer setting with ID ${id} not found`);
    }
    
    // Build the query dynamically based on which fields are being updated
    const updateFields = [];
    const queryParams = [];
    let paramCounter = 1;
    
    if (setting.name !== undefined) {
      updateFields.push(`name = $${paramCounter++}`);
      queryParams.push(setting.name);
    }
    
    if (setting.durationSeconds !== undefined) {
      updateFields.push(`duration_seconds = $${paramCounter++}`);
      queryParams.push(setting.durationSeconds);
    }
    
    if (setting.isMuted !== undefined) {
      updateFields.push(`is_muted = $${paramCounter++}`);
      queryParams.push(setting.isMuted);
    }
    
    // Always update the updated_at timestamp
    updateFields.push(`updated_at = $${paramCounter++}`);
    queryParams.push(new Date());
    
    // Add the ID as the last parameter
    queryParams.push(id);
    
    const { rows } = await this.db.query(
      `UPDATE timer_settings
      SET ${updateFields.join(', ')}
      WHERE id = $${paramCounter}
      RETURNING *`,
      queryParams
    );
    
    const row = rows[0];
    return {
      id: row.id,
      userId: row.user_id,
      name: row.name,
      durationSeconds: row.duration_seconds,
      isMuted: row.is_muted,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  }
  
  async deleteTimerSetting(id: number): Promise<boolean> {
    const { rowCount } = await this.db.query(
      `DELETE FROM timer_settings WHERE id = $1`,
      [id]
    );
    
    return rowCount > 0;
  }
  
  // Cooking Progress methods
  async getCookingProgresses(userId: number): Promise<CookingProgress[]> {
    const { rows } = await this.db.query(
      `SELECT * FROM cooking_progress 
      WHERE user_id = $1 
      ORDER BY start_time DESC`,
      [userId]
    );
    
    return rows.map((row: any) => ({
      id: row.id,
      userId: row.user_id,
      recipeId: row.recipe_id,
      status: row.status,
      startTime: row.start_time,
      endTime: row.end_time,
      completedSteps: row.completed_steps || [],
      notes: row.notes,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    }));
  }
  
  async getCookingProgress(id: number): Promise<CookingProgress | undefined> {
    const { rows } = await this.db.query(
      `SELECT * FROM cooking_progress WHERE id = $1`,
      [id]
    );
    
    if (rows.length === 0) {
      return undefined;
    }
    
    const row = rows[0];
    return {
      id: row.id,
      userId: row.user_id,
      recipeId: row.recipe_id,
      status: row.status,
      startTime: row.start_time,
      endTime: row.end_time,
      completedSteps: row.completed_steps || [],
      notes: row.notes,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  }
  
  async getCookingProgressByRecipe(userId: number, recipeId: number): Promise<CookingProgress | undefined> {
    const { rows } = await this.db.query(
      `SELECT * FROM cooking_progress 
      WHERE user_id = $1 AND recipe_id = $2 AND end_time IS NULL
      ORDER BY start_time DESC
      LIMIT 1`,
      [userId, recipeId]
    );
    
    if (rows.length === 0) {
      return undefined;
    }
    
    const row = rows[0];
    return {
      id: row.id,
      userId: row.user_id,
      recipeId: row.recipe_id,
      status: row.status,
      startTime: row.start_time,
      endTime: row.end_time,
      completedSteps: row.completed_steps || [],
      notes: row.notes,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  }
  
  async saveCookingProgress(progress: InsertCookingProgress): Promise<CookingProgress> {
    const { rows } = await this.db.query(
      `INSERT INTO cooking_progress 
      (user_id, recipe_id, status, start_time, end_time, completed_steps, notes, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *`,
      [
        progress.userId,
        progress.recipeId,
        progress.status || "in_progress",
        progress.startTime || new Date(),
        progress.endTime || null,
        progress.completedSteps || [],
        progress.notes || null,
        new Date(),
        new Date()
      ]
    );
    
    const row = rows[0];
    return {
      id: row.id,
      userId: row.user_id,
      recipeId: row.recipe_id,
      status: row.status,
      startTime: row.start_time,
      endTime: row.end_time,
      completedSteps: row.completed_steps || [],
      notes: row.notes,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  }
  
  async updateCookingProgress(id: number, progress: Partial<CookingProgress>): Promise<CookingProgress> {
    // Get current progress to merge with updates
    const currentProgress = await this.getCookingProgress(id);
    
    if (!currentProgress) {
      throw new Error(`Cooking progress with ID ${id} not found`);
    }
    
    // Build the query dynamically based on which fields are being updated
    const updateFields = [];
    const queryParams = [];
    let paramCounter = 1;
    
    if (progress.status !== undefined) {
      updateFields.push(`status = $${paramCounter++}`);
      queryParams.push(progress.status);
    }
    
    if (progress.endTime !== undefined) {
      updateFields.push(`end_time = $${paramCounter++}`);
      queryParams.push(progress.endTime);
    }
    
    if (progress.completedSteps !== undefined) {
      updateFields.push(`completed_steps = $${paramCounter++}`);
      queryParams.push(progress.completedSteps);
    }
    
    if (progress.notes !== undefined) {
      updateFields.push(`notes = $${paramCounter++}`);
      queryParams.push(progress.notes);
    }
    
    // Always update the updated_at timestamp
    updateFields.push(`updated_at = $${paramCounter++}`);
    queryParams.push(new Date());
    
    // No updates needed, return the current progress
    if (updateFields.length === 0) {
      return currentProgress;
    }
    
    // Add the ID as the last parameter
    queryParams.push(id);
    
    const { rows } = await this.db.query(
      `UPDATE cooking_progress
      SET ${updateFields.join(', ')}
      WHERE id = $${paramCounter}
      RETURNING *`,
      queryParams
    );
    
    const row = rows[0];
    return {
      id: row.id,
      userId: row.user_id,
      recipeId: row.recipe_id,
      status: row.status,
      startTime: row.start_time,
      endTime: row.end_time,
      completedSteps: row.completed_steps || [],
      notes: row.notes,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  }
  
  async completeCookingProgress(id: number, endTime?: Date): Promise<CookingProgress> {
    const currentProgress = await this.getCookingProgress(id);
    
    if (!currentProgress) {
      throw new Error(`Cooking progress with ID ${id} not found`);
    }
    
    const { rows } = await this.db.query(
      `UPDATE cooking_progress
      SET status = 'completed', end_time = $1, updated_at = $2
      WHERE id = $3
      RETURNING *`,
      [endTime || new Date(), new Date(), id]
    );
    
    const row = rows[0];
    return {
      id: row.id,
      userId: row.user_id,
      recipeId: row.recipe_id,
      status: row.status,
      startTime: row.start_time,
      endTime: row.end_time,
      completedSteps: row.completed_steps || [],
      notes: row.notes,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  }
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private recipeStore: Map<number, Recipe>;
  private nutritionLogStore: Map<number, NutritionLog>;
  private nutritionGoalStore: Map<number, NutritionGoal>;
  private weightLogStore: Map<number, WeightLog>;
  private notificationPrefsStore: Map<number, NotificationPreferences>;
  private timerSettingsStore: Map<number, TimerSettings>;
  private cookingProgressStore: Map<number, CookingProgress>;
  private badgeStore: Map<number, Badge>;
  private userBadgeStore: Map<number, UserBadge>;
  private challengeStore: Map<number, CookingChallenge>;
  private userChallengeStore: Map<number, UserChallengeProgress>;
  private userCurrentId: number;
  private recipeCurrentId: number;
  private nutritionLogCurrentId: number;
  private nutritionGoalCurrentId: number;
  private weightLogCurrentId: number;
  private notificationPrefsCurrentId: number;
  private timerSettingsCurrentId: number;
  private cookingProgressCurrentId: number;
  private badgeCurrentId: number;
  private userBadgeCurrentId: number;
  private challengeCurrentId: number;
  private userChallengeCurrentId: number;
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.recipeStore = new Map();
    this.nutritionLogStore = new Map();
    this.nutritionGoalStore = new Map();
    this.weightLogStore = new Map();
    this.notificationPrefsStore = new Map();
    this.timerSettingsStore = new Map();
    this.cookingProgressStore = new Map();
    this.badgeStore = new Map();
    this.userBadgeStore = new Map();
    this.challengeStore = new Map();
    this.userChallengeStore = new Map();
    this.userCurrentId = 1;
    this.recipeCurrentId = 1;
    this.nutritionLogCurrentId = 1;
    this.nutritionGoalCurrentId = 1;
    this.weightLogCurrentId = 1;
    this.notificationPrefsCurrentId = 1;
    this.timerSettingsCurrentId = 1;
    this.cookingProgressCurrentId = 1;
    this.badgeCurrentId = 1;
    this.userBadgeCurrentId = 1;
    this.challengeCurrentId = 1;
    this.userChallengeCurrentId = 1;
    
    // Create a Spring seasonal badge for testing
    const springBadge: Badge = {
      id: this.badgeCurrentId++,
      name: "Spring Chef 2025",
      description: "Completed a Spring seasonal cooking challenge using fresh spring ingredients",
      icon: "🌱",
      category: "seasonal",
      requirements: { recipeCount: 3, season: "spring" },
      tier: 1, // Bronze
      season: "spring",
      points: 50,
      isLimited: true,
      validFrom: new Date("2025-03-21"),
      validUntil: new Date("2025-06-21"),
      createdAt: new Date(),
    };
    this.badgeStore.set(springBadge.id, springBadge);
    
    // Add a spring cooking challenge
    const springChallenge: CookingChallenge = {
      id: this.challengeCurrentId++,
      title: "Spring Greens 2025",
      description: "Cook three recipes featuring fresh spring vegetables like asparagus, peas, and artichokes",
      image: "https://images.unsplash.com/photo-1559181567-c3384527ae38",
      season: "spring",
      year: 2025,
      startDate: new Date("2025-03-21"),
      endDate: new Date("2025-06-21"),
      requiredRecipeCount: 3,
      points: 100,
      badgeId: springBadge.id,
      isActive: true,
      difficulty: "medium",
      recipeIds: [],
      createdAt: new Date(),
    };
    this.challengeStore.set(springChallenge.id, springChallenge);
    
    // Create memory store for sessions
    const MemoryStore = memorystore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
      stale: false // Immediately destroy expired sessions
    });
    
    console.log('In-memory storage initialized successfully');
    
    // Create a default demo user for testing
    const user: User = { 
      id: this.userCurrentId++,
      username: 'demouser',
      password: '$2b$10$kItG5EeOZkKRxGS9bGQKP.LbLlWRJhU34sGAYUeaDDWDGJnfu27.6', // 'password123'
      name: 'Demo User',
      email: 'demo@example.com',
      image: 'https://ui-avatars.com/api/?name=Demo+User&background=ff8c00&color=fff',
      provider: "credentials",
      providerId: null,
      createdAt: new Date(),
      // Default health profile
      dateOfBirth: null,
      isPregnant: false,
      allergies: ['peanuts'],
      medicalConditions: [],
      dietaryRestrictions: ['vegetarian'],
      // New fields for health tracking
      heightCm: 175,
      weightKg: 70,
      lastWeightUpdate: new Date(),
      targetWeightKg: 68,
      notificationsEnabled: true,
      coachNickname: "PC" // Personal Coach nickname
    };
    this.users.set(user.id, user);
  }
  
  async initDb(): Promise<void> {
    // No-op for memory storage
    console.log("Memory storage initialized");
    return Promise.resolve();
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }
  
  async getUserByProviderId(provider: string, providerId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.provider === provider && user.providerId === providerId,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { 
      id,
      username: insertUser.username,
      password: insertUser.password || null,
      name: insertUser.name || null,
      email: insertUser.email || null,
      image: insertUser.image || null,
      provider: insertUser.provider || "credentials",
      providerId: insertUser.providerId || null,
      createdAt: new Date(),
      // Health profile with defaults
      dateOfBirth: insertUser.dateOfBirth || null,
      isPregnant: insertUser.isPregnant || false,
      allergies: insertUser.allergies || [],
      medicalConditions: insertUser.medicalConditions || [],
      dietaryRestrictions: insertUser.dietaryRestrictions || [],
      // New fields for health tracking
      heightCm: insertUser.heightCm || null,
      weightKg: insertUser.weightKg || null,
      lastWeightUpdate: null,
      targetWeightKg: insertUser.targetWeightKg || null,
      notificationsEnabled: insertUser.notificationsEnabled !== false,
      coachNickname: insertUser.coachNickname || "PC" // Default coach nickname
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    const currentUser = await this.getUser(id);
    
    if (!currentUser) {
      throw new Error(`User with ID ${id} not found`);
    }
    
    // Update the user with new data
    const updatedUser: User = {
      ...currentUser,
      ...userData,
      // Make sure these fields are not overwritten with undefined
      id: currentUser.id, // Never change the ID
      createdAt: currentUser.createdAt, // Never change the created date
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async getUserSavedRecipes(userId: number): Promise<Recipe[]> {
    return Array.from(this.recipeStore.values()).filter(
      (recipe) => recipe.userId === userId,
    );
  }

  async getRecipes(): Promise<Recipe[]> {
    return Array.from(this.recipeStore.values());
  }

  async getRecipe(id: number): Promise<Recipe | undefined> {
    return this.recipeStore.get(id);
  }

  async saveRecipe(insertRecipe: InsertRecipe): Promise<Recipe> {
    const id = this.recipeCurrentId++;
    // Default to user ID 1 if no user is specified
    const recipe: Recipe = { 
      ...insertRecipe, 
      id,
      userId: insertRecipe.userId || 1,
      healthScore: insertRecipe.healthScore || null
    };
    this.recipeStore.set(id, recipe);
    return recipe;
  }

  // Nutrition log methods
  async getNutritionLogs(userId: number): Promise<NutritionLog[]> {
    return Array.from(this.nutritionLogStore.values()).filter(
      (log) => log.userId === userId
    );
  }

  async getNutritionLog(id: number): Promise<NutritionLog | undefined> {
    return this.nutritionLogStore.get(id);
  }

  async saveNutritionLog(insertLog: InsertNutritionLog): Promise<NutritionLog> {
    const id = this.nutritionLogCurrentId++;
    
    // Create a proper NutritionLog from the insert data
    const log = {
      ...insertLog,
      id,
      date: insertLog.date || new Date(),
      // Ensure all optional fields are properly handled with null defaults
      calories: insertLog.calories === undefined ? null : insertLog.calories,
      protein: insertLog.protein === undefined ? null : insertLog.protein,
      carbs: insertLog.carbs === undefined ? null : insertLog.carbs,
      fat: insertLog.fat === undefined ? null : insertLog.fat,
      fiber: insertLog.fiber === undefined ? null : insertLog.fiber,
      water: insertLog.water === undefined ? null : insertLog.water,
      healthScore: insertLog.healthScore === undefined ? null : insertLog.healthScore,
      imageUrl: insertLog.imageUrl === undefined ? null : insertLog.imageUrl,
      recipeId: insertLog.recipeId === undefined ? null : insertLog.recipeId,
      notes: insertLog.notes === undefined ? null : insertLog.notes,
    } as NutritionLog;
    
    this.nutritionLogStore.set(id, log);
    return log;
  }
  
  async getNutritionLogsByRecipe(recipeId: number): Promise<NutritionLog[]> {
    return Array.from(this.nutritionLogStore.values()).filter(
      (log) => log.recipeId === recipeId
    );
  }
  
  // Nutrition goals methods
  async getNutritionGoals(userId: number): Promise<NutritionGoal | undefined> {
    // Find the goal for this user
    return Array.from(this.nutritionGoalStore.values()).find(
      (goal) => goal.userId === userId
    );
  }
  
  async saveNutritionGoals(goals: InsertNutritionGoal): Promise<NutritionGoal> {
    const id = this.nutritionGoalCurrentId++;
    
    // Create a proper NutritionGoal from the insert data
    const goal: NutritionGoal = {
      id,
      userId: goals.userId,
      caloriesTarget: goals.caloriesTarget ?? null,
      proteinTarget: goals.proteinTarget ?? null,
      carbsTarget: goals.carbsTarget ?? null,
      fatTarget: goals.fatTarget ?? null,
      fiberTarget: goals.fiberTarget ?? null,
      waterTarget: goals.waterTarget ?? null,
      healthScoreTarget: goals.healthScoreTarget ?? null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    this.nutritionGoalStore.set(id, goal);
    return goal;
  }
  
  async updateNutritionGoals(userId: number, goals: Partial<NutritionGoal>): Promise<NutritionGoal> {
    // Find the current goals for the user
    const currentGoals = await this.getNutritionGoals(userId);
    
    if (!currentGoals) {
      // No goals exist, create new ones
      return this.saveNutritionGoals({
        ...goals,
        userId,
      } as InsertNutritionGoal);
    }
    
    // Update the goals with new data
    const updatedGoals: NutritionGoal = {
      ...currentGoals,
      ...goals,
      // Make sure these fields are not overwritten
      id: currentGoals.id,
      userId: currentGoals.userId,
      createdAt: currentGoals.createdAt,
      updatedAt: new Date(), // Update the updatedAt timestamp
    };
    
    this.nutritionGoalStore.set(currentGoals.id, updatedGoals);
    return updatedGoals;
  }

  async getUserNutritionStats(userId: number, period?: 'day' | 'week' | 'month'): Promise<{
    totalLogs: number;
    averageHealthScore: number;
    averageCalories: number;
    topFoodItems: {item: string, count: number}[];
    periodStart?: Date;
    periodEnd?: Date;
  }> {
    let userLogs = await this.getNutritionLogs(userId);
    let periodStart: Date | undefined;
    let periodEnd: Date | undefined = new Date(); // Current time as period end
    
    // Filter logs by period if specified
    if (period) {
      periodStart = new Date();
      
      switch (period) {
        case 'day':
          // Set to start of current day
          periodStart.setHours(0, 0, 0, 0);
          break;
        case 'week':
          // Set to 7 days ago
          periodStart.setDate(periodStart.getDate() - 7);
          break;
        case 'month':
          // Set to 30 days ago
          periodStart.setDate(periodStart.getDate() - 30);
          break;
      }
      
      // Filter logs that fall within the period
      userLogs = userLogs.filter(log => {
        const logDate = new Date(log.date);
        return logDate >= periodStart! && logDate <= periodEnd;
      });
    }
    
    if (userLogs.length === 0) {
      return {
        totalLogs: 0,
        averageHealthScore: 0,
        averageCalories: 0,
        topFoodItems: [],
        periodStart,
        periodEnd,
      };
    }
    
    // Calculate average health score
    const healthScores = userLogs
      .map(log => log.healthScore || 0)
      .filter(score => score > 0);
      
    const averageHealthScore = healthScores.length > 0
      ? healthScores.reduce((sum, score) => sum + score, 0) / healthScores.length
      : 0;
    
    // Calculate average calories
    const calories = userLogs
      .map(log => log.calories || 0)
      .filter(cal => cal > 0);
      
    const averageCalories = calories.length > 0
      ? calories.reduce((sum, cal) => sum + cal, 0) / calories.length
      : 0;
    
    // Calculate top food items
    const foodItemsMap = new Map<string, number>();
    
    userLogs.forEach(log => {
      log.foodItems.forEach(item => {
        const currentCount = foodItemsMap.get(item) || 0;
        foodItemsMap.set(item, currentCount + 1);
      });
    });
    
    const topFoodItems = Array.from(foodItemsMap.entries())
      .map(([item, count]) => ({ item, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5); // Get top 5 items
    
    return {
      totalLogs: userLogs.length,
      averageHealthScore: Number(averageHealthScore.toFixed(1)),
      averageCalories: Math.round(averageCalories),
      topFoodItems,
      periodStart,
      periodEnd,
    };
  }
  
  // Weight tracking methods
  async getWeightLogs(userId: number, startDate?: Date, endDate?: Date): Promise<WeightLog[]> {
    // Filter logs by user and date range if specified
    return Array.from(this.weightLogStore.values())
      .filter(log => {
        if (log.userId !== userId) return false;
        
        if (startDate && log.date < startDate) return false;
        if (endDate && log.date > endDate) return false;
        
        return true;
      })
      .sort((a, b) => b.date.getTime() - a.date.getTime()); // Newest first
  }
  
  async getLatestWeightLog(userId: number): Promise<WeightLog | undefined> {
    const logs = await this.getWeightLogs(userId);
    return logs.length > 0 ? logs[0] : undefined; // First log is the newest due to sort
  }
  
  async saveWeightLog(insertLog: InsertWeightLog): Promise<WeightLog> {
    const id = this.weightLogCurrentId++;
    
    // Create a proper WeightLog from the insert data
    const log: WeightLog = {
      id,
      userId: insertLog.userId,
      date: insertLog.date || new Date(),
      weightKg: insertLog.weightKg,
      notes: insertLog.notes || null,
      bmi: insertLog.bmi || null,
      prediction: insertLog.prediction || null
    };
    
    this.weightLogStore.set(id, log);
    
    // Update the user's current weight
    const user = await this.getUser(insertLog.userId);
    if (user) {
      await this.updateUser(user.id, { 
        weightKg: insertLog.weightKg,
        lastWeightUpdate: log.date
      });
    }
    
    return log;
  }
  
  // Notification preferences methods
  async getNotificationPreferences(userId: number): Promise<NotificationPreferences | undefined> {
    return Array.from(this.notificationPrefsStore.values()).find(
      (prefs) => prefs.userId === userId
    );
  }
  
  async saveNotificationPreferences(prefs: InsertNotificationPreferences): Promise<NotificationPreferences> {
    const id = this.notificationPrefsCurrentId++;
    
    // Create proper NotificationPreferences with defaults
    const now = new Date();
    const notifications: NotificationPreferences = {
      id,
      userId: prefs.userId,
      mealSuggestions: prefs.mealSuggestions !== undefined ? prefs.mealSuggestions : true,
      weightReminders: prefs.weightReminders !== undefined ? prefs.weightReminders : true,
      nutritionAlerts: prefs.nutritionAlerts !== undefined ? prefs.nutritionAlerts : true,
      preferredTime: prefs.preferredTime || '08:00',
      lastNotification: prefs.lastNotification || null,
      createdAt: now,
      updatedAt: now
    };
    
    this.notificationPrefsStore.set(id, notifications);
    return notifications;
  }
  
  async updateNotificationPreferences(userId: number, prefs: Partial<NotificationPreferences>): Promise<NotificationPreferences> {
    // Check if notification preferences exist for this user
    const existingPrefs = await this.getNotificationPreferences(userId);
    
    if (!existingPrefs) {
      // No preferences exist, create new ones
      return this.saveNotificationPreferences({
        ...prefs,
        userId,
      } as InsertNotificationPreferences);
    }
    
    // Update the preferences
    const updatedPrefs: NotificationPreferences = {
      ...existingPrefs,
      ...prefs,
      // Make sure these fields are not overwritten
      id: existingPrefs.id,
      userId: existingPrefs.userId,
      createdAt: existingPrefs.createdAt,
      updatedAt: new Date() // Update the updatedAt timestamp
    };
    
    this.notificationPrefsStore.set(existingPrefs.id, updatedPrefs);
    return updatedPrefs;
  }
  
  async getUsersForDailyNotifications(): Promise<User[]> {
    const users: User[] = [];
    const now = new Date();
    
    // Get all users with notification enabled
    const eligibleUsers = Array.from(this.users.values()).filter(
      user => user.notificationsEnabled
    );
    
    // For each user, check if they have notification preferences
    for (const user of eligibleUsers) {
      const prefs = await this.getNotificationPreferences(user.id);
      
      // Skip if no preferences or all notification types are disabled
      if (!prefs || (!prefs.mealSuggestions && !prefs.weightReminders && !prefs.nutritionAlerts)) {
        continue;
      }
      
      // Check if it's been at least 20 hours since the last notification
      if (!prefs.lastNotification || 
          (now.getTime() - prefs.lastNotification.getTime()) > 20 * 60 * 60 * 1000) {
        users.push(user);
      }
    }
    
    return users;
  }
  
  // Health assessment method
  async getHealthAssessment(userId: number): Promise<{
    bmi: number;
    status: string;
    weightTrend: 'gaining' | 'losing' | 'stable';
    recommendation: string;
    prediction: {
      estimatedWeightIn30Days: number;
      confidence: number;
    };
  }> {
    // Get the user's height, weight, and recent weight logs
    const user = await this.getUser(userId);
    if (!user || !user.heightCm || !user.weightKg) {
      throw new Error('User height and weight data is required for health assessment');
    }
    
    // Get weight logs for trend analysis
    const weightLogs = await this.getWeightLogs(userId);
    
    // Calculate BMI
    const heightInMeters = user.heightCm / 100;
    const bmi = Math.round((user.weightKg / (heightInMeters * heightInMeters)) * 10) / 10;
    
    // Determine BMI status
    let status = '';
    if (bmi < 18.5) {
      status = 'Underweight';
    } else if (bmi >= 18.5 && bmi < 25) {
      status = 'Normal weight';
    } else if (bmi >= 25 && bmi < 30) {
      status = 'Overweight';
    } else {
      status = 'Obese';
    }
    
    // Determine weight trend
    let weightTrend: 'gaining' | 'losing' | 'stable' = 'stable';
    let recommendation = '';
    let prediction = {
      estimatedWeightIn30Days: user.weightKg,
      confidence: 0.7
    };
    
    if (weightLogs.length >= 2) {
      // Sort logs by date (newest first)
      weightLogs.sort((a, b) => b.date.getTime() - a.date.getTime());
      
      // Compare current weight with previous weight
      const currentWeight = weightLogs[0].weightKg;
      const previousWeight = weightLogs[1].weightKg;
      
      if (currentWeight > previousWeight + 1) {
        weightTrend = 'gaining';
        recommendation = 'Consider watching your calorie intake and increasing physical activity.';
        prediction.estimatedWeightIn30Days = user.weightKg + Math.round((currentWeight - previousWeight) * 2);
      } else if (currentWeight < previousWeight - 1) {
        weightTrend = 'losing';
        recommendation = 'Keep up the good work if weight loss is your goal.';
        prediction.estimatedWeightIn30Days = user.weightKg - Math.round((previousWeight - currentWeight) * 2);
      } else {
        weightTrend = 'stable';
        recommendation = 'Your weight has been stable. Great job maintaining!';
      }
      
      prediction.confidence = 0.8; // Higher confidence with more data
    } else {
      // Not enough data for trend analysis
      recommendation = 'Keep logging your weight regularly for personalized recommendations.';
      prediction.confidence = 0.6; // Lower confidence with less data
    }
    
    // Make recommendation based on BMI
    if (status === 'Underweight') {
      recommendation += ' Consider consulting with a nutritionist about a healthy weight gain plan.';
    } else if (status === 'Overweight' || status === 'Obese') {
      recommendation += ' Consider a balanced diet and regular exercise for healthier weight.';
    }
    
    return {
      bmi,
      status,
      weightTrend,
      recommendation,
      prediction
    };
  }
  
  // Kitchen Timer methods
  async getTimerSettings(userId: number): Promise<TimerSettings[]> {
    return Array.from(this.timerSettingsStore.values()).filter(
      (setting) => setting.userId === userId
    ).sort((a, b) => a.name.localeCompare(b.name));
  }
  
  async getTimerSetting(id: number): Promise<TimerSettings | undefined> {
    return this.timerSettingsStore.get(id);
  }
  
  async saveTimerSetting(setting: InsertTimerSettings): Promise<TimerSettings> {
    const id = this.timerSettingsCurrentId++;
    
    // Create a proper TimerSettings object
    const timerSetting: TimerSettings = {
      id,
      userId: setting.userId,
      name: setting.name,
      durationSeconds: setting.durationSeconds,
      isMuted: setting.isMuted || false,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.timerSettingsStore.set(id, timerSetting);
    return timerSetting;
  }
  
  async updateTimerSetting(id: number, setting: Partial<TimerSettings>): Promise<TimerSettings> {
    const currentSetting = await this.getTimerSetting(id);
    
    if (!currentSetting) {
      throw new Error(`Timer setting with ID ${id} not found`);
    }
    
    // Update the setting with new data
    const updatedSetting: TimerSettings = {
      ...currentSetting,
      ...setting,
      // Make sure these fields are not overwritten
      id: currentSetting.id,
      userId: currentSetting.userId,
      createdAt: currentSetting.createdAt,
      updatedAt: new Date() // Update the updatedAt timestamp
    };
    
    this.timerSettingsStore.set(id, updatedSetting);
    return updatedSetting;
  }
  
  async deleteTimerSetting(id: number): Promise<boolean> {
    const exists = this.timerSettingsStore.has(id);
    if (exists) {
      this.timerSettingsStore.delete(id);
      return true;
    }
    return false;
  }
  
  // Cooking Progress methods
  async getCookingProgresses(userId: number): Promise<CookingProgress[]> {
    return Array.from(this.cookingProgressStore.values())
      .filter((progress) => progress.userId === userId)
      .sort((a, b) => b.startTime.getTime() - a.startTime.getTime()); // Newest first
  }
  
  async getCookingProgress(id: number): Promise<CookingProgress | undefined> {
    return this.cookingProgressStore.get(id);
  }
  
  async getCookingProgressByRecipe(userId: number, recipeId: number): Promise<CookingProgress | undefined> {
    return Array.from(this.cookingProgressStore.values()).find(
      (progress) => progress.userId === userId && progress.recipeId === recipeId && !progress.endTime
    );
  }
  
  async saveCookingProgress(progress: InsertCookingProgress): Promise<CookingProgress> {
    const id = this.cookingProgressCurrentId++;
    
    // Create a proper CookingProgress object
    const cookingProgress: CookingProgress = {
      id,
      userId: progress.userId,
      recipeId: progress.recipeId,
      status: progress.status || "in_progress",
      startTime: progress.startTime || new Date(),
      endTime: progress.endTime || null,
      completedSteps: progress.completedSteps || [],
      notes: progress.notes || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    this.cookingProgressStore.set(id, cookingProgress);
    return cookingProgress;
  }
  
  async updateCookingProgress(id: number, progress: Partial<CookingProgress>): Promise<CookingProgress> {
    const currentProgress = await this.getCookingProgress(id);
    
    if (!currentProgress) {
      throw new Error(`Cooking progress with ID ${id} not found`);
    }
    
    // Update the progress with new data
    const updatedProgress: CookingProgress = {
      ...currentProgress,
      ...progress,
      // Make sure these fields are not overwritten
      id: currentProgress.id,
      userId: currentProgress.userId,
      recipeId: currentProgress.recipeId,
      startTime: currentProgress.startTime
    };
    
    this.cookingProgressStore.set(id, updatedProgress);
    return updatedProgress;
  }
  
  async completeCookingProgress(id: number, endTime?: Date): Promise<CookingProgress> {
    const currentProgress = await this.getCookingProgress(id);
    
    if (!currentProgress) {
      throw new Error(`Cooking progress with ID ${id} not found`);
    }
    
    const completedProgress: CookingProgress = {
      ...currentProgress,
      status: "completed",
      endTime: endTime || new Date(),
      updatedAt: new Date()
    };
    
    this.cookingProgressStore.set(id, completedProgress);
    return completedProgress;
  }
  
  // Badge methods
  async getBadges(category?: string, season?: string): Promise<Badge[]> {
    let badges = Array.from(this.badgeStore.values());
    
    // Filter by category if provided
    if (category) {
      badges = badges.filter(badge => badge.category === category);
    }
    
    // Filter by season if provided
    if (season) {
      badges = badges.filter(badge => badge.season === season);
    }
    
    return badges;
  }
  
  async getBadge(id: number): Promise<Badge | undefined> {
    return this.badgeStore.get(id);
  }
  
  async getBadgeByName(name: string): Promise<Badge | undefined> {
    return Array.from(this.badgeStore.values()).find(badge => badge.name === name);
  }
  
  async saveBadge(badge: InsertBadge): Promise<Badge> {
    const id = this.badgeCurrentId++;
    
    const newBadge: Badge = {
      ...badge,
      id,
      createdAt: new Date(),
    };
    
    this.badgeStore.set(id, newBadge);
    return newBadge;
  }
  
  async getUserBadges(userId: number): Promise<(Badge & { earnedAt: Date, progress: number })[]> {
    // Get all user badge relationships for this user
    const userBadges = Array.from(this.userBadgeStore.values())
      .filter(ub => ub.userId === userId);
    
    // Map them to badges with earned info
    return Promise.all(
      userBadges.map(async (ub) => {
        const badge = await this.getBadge(ub.badgeId);
        if (!badge) {
          throw new Error(`Badge with ID ${ub.badgeId} not found`);
        }
        
        return {
          ...badge,
          earnedAt: ub.earnedAt,
          progress: ub.progress,
        };
      })
    );
  }
  
  async awardBadgeToUser(userId: number, badgeId: number, progress = 100): Promise<UserBadge> {
    // Check if the user already has this badge
    const existingBadge = Array.from(this.userBadgeStore.values())
      .find(ub => ub.userId === userId && ub.badgeId === badgeId);
    
    if (existingBadge) {
      // Update progress if it's higher
      if (progress > existingBadge.progress) {
        return this.updateUserBadgeProgress(userId, badgeId, progress);
      }
      return existingBadge;
    }
    
    // Award new badge
    const id = this.userBadgeCurrentId++;
    const userBadge: UserBadge = {
      id,
      userId,
      badgeId,
      earnedAt: new Date(),
      progress,
      showOnProfile: true,
    };
    
    this.userBadgeStore.set(id, userBadge);
    return userBadge;
  }
  
  async updateUserBadgeProgress(userId: number, badgeId: number, progress: number): Promise<UserBadge> {
    // Find the existing user badge
    const userBadge = Array.from(this.userBadgeStore.values())
      .find(ub => ub.userId === userId && ub.badgeId === badgeId);
    
    if (!userBadge) {
      return this.awardBadgeToUser(userId, badgeId, progress);
    }
    
    // Update the progress
    const updatedUserBadge: UserBadge = {
      ...userBadge,
      progress: Math.max(userBadge.progress, progress), // Only increase progress, never decrease
    };
    
    this.userBadgeStore.set(userBadge.id, updatedUserBadge);
    return updatedUserBadge;
  }
  
  // Challenge methods
  async getActiveChallenges(season?: string): Promise<CookingChallenge[]> {
    const now = new Date();
    
    return Array.from(this.challengeStore.values())
      .filter(challenge => {
        // Only include active challenges that haven't ended
        if (!challenge.isActive || new Date(challenge.endDate) < now) {
          return false;
        }
        
        // Filter by season if provided
        if (season && challenge.season !== season) {
          return false;
        }
        
        return true;
      });
  }
  
  async getChallenge(id: number): Promise<CookingChallenge | undefined> {
    return this.challengeStore.get(id);
  }
  
  async saveChallenge(challenge: InsertCookingChallenge): Promise<CookingChallenge> {
    const id = this.challengeCurrentId++;
    
    const newChallenge: CookingChallenge = {
      ...challenge,
      id,
      createdAt: new Date(),
      recipeIds: challenge.recipeIds || [],
    };
    
    this.challengeStore.set(id, newChallenge);
    return newChallenge;
  }
  
  async getUserChallenges(userId: number): Promise<(CookingChallenge & { progress: number, isCompleted: boolean })[]> {
    // Get all user challenge progress entries for this user
    const userChallenges = Array.from(this.userChallengeStore.values())
      .filter(ucp => ucp.userId === userId);
    
    // Map them to challenges with progress info
    return Promise.all(
      userChallenges.map(async (ucp) => {
        const challenge = await this.getChallenge(ucp.challengeId);
        if (!challenge) {
          throw new Error(`Challenge with ID ${ucp.challengeId} not found`);
        }
        
        return {
          ...challenge,
          progress: ucp.progress,
          isCompleted: ucp.isCompleted,
        };
      })
    );
  }
  
  async startChallenge(userId: number, challengeId: number): Promise<UserChallengeProgress> {
    // Check if user already started this challenge
    const existingProgress = Array.from(this.userChallengeStore.values())
      .find(ucp => ucp.userId === userId && ucp.challengeId === challengeId);
    
    if (existingProgress) {
      return existingProgress;
    }
    
    // Start a new challenge progress
    const id = this.userChallengeCurrentId++;
    const progress: UserChallengeProgress = {
      id,
      userId,
      challengeId,
      completedRecipeIds: [],
      progress: 0,
      isCompleted: false,
      completedAt: null,
      startedAt: new Date(),
      lastUpdated: new Date(),
    };
    
    this.userChallengeStore.set(id, progress);
    return progress;
  }
  
  async updateChallengeProgress(userId: number, challengeId: number, recipeId?: number): Promise<UserChallengeProgress> {
    // Find the user's progress for this challenge
    const userProgress = Array.from(this.userChallengeStore.values())
      .find(ucp => ucp.userId === userId && ucp.challengeId === challengeId);
    
    if (!userProgress) {
      // Start the challenge first
      const newProgress = await this.startChallenge(userId, challengeId);
      
      // If a recipe was completed, update it
      if (recipeId) {
        return this.updateChallengeProgress(userId, challengeId, recipeId);
      }
      
      return newProgress;
    }
    
    // Get the challenge to check requirements
    const challenge = await this.getChallenge(challengeId);
    if (!challenge) {
      throw new Error(`Challenge with ID ${challengeId} not found`);
    }
    
    // If a recipe was completed, add it to the list
    let updatedCompletedRecipes = [...userProgress.completedRecipeIds];
    if (recipeId && !updatedCompletedRecipes.includes(recipeId)) {
      updatedCompletedRecipes.push(recipeId);
    }
    
    // Calculate progress percentage
    const progressPercentage = Math.min(
      100, 
      Math.round((updatedCompletedRecipes.length / challenge.requiredRecipeCount) * 100)
    );
    
    // Check if challenge is now completed
    const isCompleted = progressPercentage >= 100;
    const completedAt = isCompleted && !userProgress.isCompleted ? new Date() : userProgress.completedAt;
    
    // Update the progress
    const updatedProgress: UserChallengeProgress = {
      ...userProgress,
      completedRecipeIds: updatedCompletedRecipes,
      progress: progressPercentage,
      isCompleted,
      completedAt,
      lastUpdated: new Date(),
    };
    
    this.userChallengeStore.set(userProgress.id, updatedProgress);
    
    // If newly completed, award the badge if there is one
    if (isCompleted && !userProgress.isCompleted && challenge.badgeId) {
      await this.awardBadgeToUser(userId, challenge.badgeId);
    }
    
    return updatedProgress;
  }
  
  async completeChallenge(userId: number, challengeId: number): Promise<UserChallengeProgress> {
    // Find the user's progress for this challenge
    const userProgress = Array.from(this.userChallengeStore.values())
      .find(ucp => ucp.userId === userId && ucp.challengeId === challengeId);
    
    if (!userProgress) {
      // Start and complete the challenge
      const newProgress = await this.startChallenge(userId, challengeId);
      return this.completeChallenge(userId, challengeId);
    }
    
    // If already completed, just return
    if (userProgress.isCompleted) {
      return userProgress;
    }
    
    // Get the challenge to check for badge
    const challenge = await this.getChallenge(challengeId);
    if (!challenge) {
      throw new Error(`Challenge with ID ${challengeId} not found`);
    }
    
    // Complete the challenge
    const updatedProgress: UserChallengeProgress = {
      ...userProgress,
      progress: 100,
      isCompleted: true,
      completedAt: new Date(),
      lastUpdated: new Date(),
    };
    
    this.userChallengeStore.set(userProgress.id, updatedProgress);
    
    // Award the badge if there is one
    if (challenge.badgeId) {
      await this.awardBadgeToUser(userId, challenge.badgeId);
    }
    
    return updatedProgress;
  }
}

// Use database storage if DATABASE_URL is available, otherwise use memory storage
// Create the storage instance
let storageInstance: IStorage;

try {
  // Use database storage if URL is provided
  if (databaseUrl) {
    console.log('Attempting to use database storage...');
    // Create a new database storage instance
    storageInstance = new DatabaseStorage();
    
    // Initialize the database connection
    (async () => {
      try {
        // This will connect to the database
        await (storageInstance as DatabaseStorage).initDb();
        console.log('Database connection initialized successfully');
      } catch (initError) {
        console.error('Failed to initialize database connection:', initError);
        // Fall back to in-memory storage on DB init failure
        storageInstance = new MemStorage();
      }
    })();
  } else {
    console.log('No database URL provided, using in-memory storage');
    storageInstance = new MemStorage();
  }
} catch (error) {
  console.error('Error creating storage, falling back to in-memory:', error);
  storageInstance = new MemStorage();
}

export const storage = storageInstance;
