import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  generateRecipes, 
  analyzeFoodImage, 
  chatWithFoodAI,
  analyzeNutrition,
  type ChatMessage,
  type FoodAnalysisResult,
  openai
} from "./openai";
import { 
  searchRecipesByIngredients,
  getRecipeInformation,
  getNutritionalInformation,
  generateRecipesWithSpoonacular
} from "./spoonacular";
import { analyzeFoodImageWithClarifai } from "./clarifai";
import { ingredientSchema, loginSchema, registerSchema } from "@shared/schema";
import { z, ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { loginUser, registerUser, getUserById } from "./auth";
import { setupOAuth } from "./oauth";

// Auth middleware - check if user is authenticated
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.session.userId && req.session.isAuthenticated) {
    next();
  } else {
    res.status(401).json({ message: 'Unauthorized - Please log in to access this resource' });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up OAuth routes
  setupOAuth(app);
  
  // Authentication routes with correct paths
  app.post('/api/login', async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);

      const user = await loginUser(validatedData.email, validatedData.password);

      // Set session and ensure it's saved before responding
      req.session.userId = user.id;
      req.session.isAuthenticated = true;
      
      req.session.save((err) => {
        if (err) {
          console.error('Error saving session during login:', err);
          return res.status(500).json({ 
            message: "Error saving session. Please try again."
          });
        }
        
        // Session saved successfully, send response with user data
        return res.json({ message: 'Login successful', user });
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid login data", 
          errors: fromZodError(error).message 
        });
      }

      console.error('Login error:', error);
      
      // Handle specific error types with appropriate status codes and messages
      if ((error as Error).message.includes('Account not found')) {
        return res.status(404).json({ 
          error: 'account_not_found', 
          message: 'We couldn\'t find an account with this email. Please check your email or register for a new account.'
        });
      } else if ((error as Error).message.includes('Invalid password')) {
        return res.status(401).json({ 
          error: 'invalid_credentials', 
          message: 'The password you entered is incorrect. Please try again or reset your password.'
        });
      } 
      
      // Default error response
      return res.status(401).json({ 
        error: 'login_failed',
        message: (error as Error).message || 'Login failed. Please check your credentials and try again.'
      });
    }
  });

  app.post('/api/register', async (req, res) => {
    try {
      const validatedData = registerSchema.parse(req.body);
      
      // Store original username for comparison
      const originalUsername = validatedData.username;
      
      // Register the user (this may modify the username if needed)
      // The registerSchema already transforms dateOfBirth from string to Date
      const user = await registerUser(validatedData);

      // Set session and ensure it's saved before responding
      req.session.userId = user.id;
      req.session.isAuthenticated = true;
      
      let successMessage = 'Registration successful';
      
      // If username was modified, notify the user
      if (user.username !== originalUsername) {
        successMessage = `Registration successful. Note: Your username was changed to "${user.username}" as "${originalUsername}" was already taken.`;
      }

      req.session.save((err) => {
        if (err) {
          console.error('Error saving session during registration:', err);
          return res.status(500).json({ 
            message: "Error saving session. Please try again."
          });
        }
        
        // Session saved successfully, send response with user data
        return res.status(201).json({ 
          message: successMessage, 
          user, 
          usernameChanged: user.username !== originalUsername
        });
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid registration data", 
          errors: fromZodError(error).message 
        });
      }

      console.error('Registration error:', error);
      
      // Handle specific error types with appropriate status codes
      if ((error as Error).message.includes('Email already in use')) {
        return res.status(409).json({ 
          error: 'email_exists', 
          message: 'This email is already registered. Please use a different email or try logging in.'
        });
      } else if ((error as Error).message.includes('username')) {
        return res.status(409).json({ 
          error: 'username_exists', 
          message: 'This username is already taken. Please choose a different username.'
        });
      } else if ((error as Error).message.includes('password')) {
        return res.status(422).json({ 
          error: 'password_validation', 
          message: 'Password does not meet the requirements. Please use a stronger password.'
        });
      }
      
      // Default error response
      return res.status(400).json({ 
        error: 'registration_failed',
        message: (error as Error).message || 'Registration failed. Please try again.'
      });
    }
  });

  app.get('/api/user', async (req, res) => {
    try {
      console.log('Session debug [GET /api/user]:', {
        sessionID: req.sessionID,
        hasSession: !!req.session,
        isAuthenticated: req.session.isAuthenticated,
        userId: req.session.userId
      });

      // First check if we have a valid authenticated session
      if (req.session.userId && req.session.isAuthenticated) {
        const user = await getUserById(req.session.userId);

        if (user) {
          console.log(`Found authenticated user:`, user);
          
          // Make sure session is saved before responding
          req.session.save((err) => {
            if (err) {
              console.error('Error saving session:', err);
              return res.status(500).json({ message: 'Error saving session' });
            }
            return res.json({ user });
          });
          return; // Early return to prevent further execution
        } else {
          console.error(`User with ID ${req.session.userId} not found in database`);
          // Clear invalid session
          req.session.destroy((err) => {
            if (err) console.error('Session destruction error:', err);
          });
        }
      }

      // No demo mode anymore - we're using real authentication

      // Neither valid session nor demo mode, return 401 
      // but with a JSON response, NOT a redirect
      return res.status(401).json({ message: 'Not authenticated' });
    } catch (error) {
      console.error('Error fetching user:', error);
      return res.status(500).json({ message: 'Failed to fetch user' });
    }
  });

  app.post('/api/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error('Logout error:', err);
        return res.status(500).json({ message: 'Failed to logout' });
      }

      return res.json({ message: 'Logout successful' });
    });
  });

  // Recipe generation endpoint
  app.post("/api/recipes/generate", async (req, res) => {
    try {
      // Check if the OpenAI API key is configured
      if (!process.env.OPENAI_API_KEY) {
        return res.status(500).json({
          success: false,
          message: "OpenAI API key is not configured. Please add your API key to continue."
        });
      }

      const validatedData = ingredientSchema.parse(req.body);
      console.log(`Generating recipes for ingredients: ${validatedData.ingredients.join(', ')}`);

      // Get active dietary filters
      const activeFilters = validatedData.dietaryFilters
        .filter(filter => filter.active)
        .map(filter => filter.name);

      console.log(`With dietary filters: ${activeFilters.join(', ') || 'none'}`);
      console.log(`With cuisine type: ${validatedData.cuisineType || 'not specified'}`);
      console.log(`With servings: ${validatedData.servings || 2}`);

      // Try OpenAI first for recipe generation
      try {
        const recipes = await generateRecipes(
          validatedData.ingredients,
          validatedData.dietaryFilters,
          validatedData.cuisineType,
          validatedData.servings
        );

        console.log(`Successfully generated ${recipes.recipes.length} recipes with OpenAI`);
        return res.json({ success: true, ...recipes });
      } catch (openaiError) {
        // Log OpenAI error but don't return it yet
        console.error("OpenAI Recipe generation failed:", openaiError);

        // Fall back to Spoonacular if OpenAI fails
        console.log("Falling back to Spoonacular for recipe generation...");

        if (!process.env.SPOONACULAR_API_KEY) {
          console.error("Spoonacular API key not configured for fallback");
          throw openaiError; // Re-throw the OpenAI error if no Spoonacular key
        }

        try {
          // Get active dietary filters as strings for Spoonacular
          const dietaryFilterNames = validatedData.dietaryFilters
            .filter(filter => filter.active)
            .map(filter => filter.name);

          const spoonacularRecipes = await generateRecipesWithSpoonacular(
            validatedData.ingredients,
            dietaryFilterNames,
            validatedData.cuisineType,
            validatedData.servings
          );

          console.log(`Successfully generated ${spoonacularRecipes.recipes.length} recipes with Spoonacular (fallback)`);
          return res.json({ success: true, ...spoonacularRecipes });
        } catch (spoonacularError) {
          console.error("Spoonacular fallback also failed:", spoonacularError);
          
          // Handle rate limit error (402 error from Spoonacular)
          const errorMessage = spoonacularError instanceof Error ? spoonacularError.message : String(spoonacularError);
          
          if (errorMessage.includes("402")) {
            console.log("Spoonacular API rate limit reached. Using emergency recipe generation...");
            
            // Since both APIs failed, try a more robust fallback approach - 
            // retry the OpenAI call with a simpler approach
            console.log("Attempting simplified OpenAI recipe generation as last-resort fallback...");
            
            try {
              // Use the imported OpenAI instance
              
              // Create a simpler prompt for OpenAI that doesn't require much tokens
              const minimalPrompt = `
                Please generate a simple recipe using these ingredients: ${validatedData.ingredients.join(', ')}.
                Format should be JSON with: title, description, ingredients array (name, amount), instructions array, 
                simple nutritionalInfo (calories, protein, carbs, fat), prepTime, cookTime, tags.
                Make the recipe very simple, and keep response under 300 tokens.
              `;
              
              // Make a simpler OpenAI call with less token usage and simpler model
              const openaiResponse = await openai.chat.completions.create({
                model: "gpt-3.5-turbo", // Use cheaper model as fallback
                messages: [
                  {
                    role: "system",
                    content: "You are a helpful assistant that generates simple recipes. Return valid JSON only."
                  },
                  {
                    role: "user",
                    content: minimalPrompt
                  }
                ],
                response_format: { type: "json_object" },
                max_tokens: 500 // Limit token usage
              });
              
              const content = openaiResponse.choices[0].message.content;
              if (!content) {
                throw new Error("Empty response from OpenAI");
              }
              
              // Parse the response and format as a single recipe result
              const recipeData = JSON.parse(content);
              const emergencyRecipes = {
                recipes: [
                  {
                    id: Date.now(),
                    ...recipeData,
                    servings: validatedData.servings,
                    image: null // No image in emergency mode
                  }
                ]
              };
              
              return res.json({ 
                success: true, 
                ...emergencyRecipes,
                notice: "Both AI recipe generation and Spoonacular API are temporarily unavailable. Simple recipes have been provided as a fallback."
              });
            } catch (fallbackError) {
              console.error("Emergency fallback also failed:", fallbackError);
              // If the fallback also fails, return a clear error message
              return res.status(503).json({
                success: false,
                message: "Recipe generation services are temporarily unavailable",
                error: "All recipe generation methods failed. Please try again later."
              });
            }
            
          }
          
          // If it's not a rate limit error, throw the original OpenAI error
          // This preserves the original error behavior for other types of failures
          throw openaiError;
        }
      }
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid request data", 
          errors: error.format() 
        });
      }

      console.error("Error generating recipes:", error);

      // Provide better error messages based on the error type
      if ((error as any).status === 401) {
        return res.status(401).json({
          success: false,
          message: "OpenAI API key is invalid or has insufficient permissions.",
          error: "Please check your API key settings."
        });
      }

      return res.status(500).json({ 
        success: false, 
        message: "Failed to generate recipes", 
        error: (error as Error).message 
      });
    }
  });

  // Save a recipe
  app.post("/api/recipes", isAuthenticated, async (req, res) => {
    try {
      // Add the user ID to the recipe
      const recipeData = {
        ...req.body,
        userId: req.session.userId
      };

      const recipe = await storage.saveRecipe(recipeData);
      return res.status(201).json(recipe);
    } catch (error) {
      console.error("Error saving recipe:", error);
      return res.status(500).json({ message: "Failed to save recipe" });
    }
  });

  // Get all saved recipes (public)
  app.get("/api/recipes", async (req, res) => {
    try {
      const recipes = await storage.getRecipes();
      return res.json(recipes);
    } catch (error) {
      console.error("Error fetching recipes:", error);
      return res.status(500).json({ message: "Failed to fetch recipes" });
    }
  });

  // Get current user's saved recipes
  app.get("/api/user/recipes", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const recipes = await storage.getUserSavedRecipes(userId);
      return res.json(recipes);
    } catch (error) {
      console.error("Error fetching user recipes:", error);
      return res.status(500).json({ message: "Failed to fetch user recipes" });
    }
  });

  // Get a specific recipe
  app.get("/api/recipes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid recipe ID" });
      }

      const recipe = await storage.getRecipe(id);
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }

      return res.json(recipe);
    } catch (error) {
      console.error("Error fetching recipe:", error);
      return res.status(500).json({ message: "Failed to fetch recipe" });
    }
  });

  // Scan Ingredients API - Detect ingredients in image using Clarifai
  app.post("/api/ingredients/scan", async (req, res) => {
    try {
      const { image } = req.body;

      // Validate that image is a base64 string
      if (!image || typeof image !== 'string') {
        return res.status(400).json({
          success: false,
          message: "Invalid image data. Please provide a base64 encoded image."
        });
      }

      // Check if the Clarifai API key is configured
      if (!process.env.CLARIFAI_API_KEY) {
        return res.status(500).json({
          success: false,
          message: "Clarifai API key is not configured. Please add your API key to continue."
        });
      }

      // Remove data URL prefix if present
      const base64Image = image.replace(/^data:image\/(png|jpeg|jpg);base64,/, '');

      // Call Clarifai to detect ingredients in the image
      const ingredients = await analyzeFoodImageWithClarifai(base64Image);

      // Ensure we have meaningful results
      if (!ingredients || ingredients.length === 0) {
        return res.status(404).json({
          success: false,
          message: "No ingredients detected in the image. Please try a clearer image or a different angle."
        });
      }

      return res.json({ 
        success: true, 
        ingredients: ingredients 
      });
    } catch (error) {
      console.error("Error scanning ingredients:", error);

      // Provide better error messages based on the error type
      return res.status(500).json({
        success: false,
        message: "Failed to scan ingredients",
        error: (error as Error).message
      });
    }
  });

  // Food Nutrition Analysis API - Analyze food by text description
  app.post("/api/food/analyze/nutrition", async (req, res) => {
    try {
      const { foodItems } = req.body;

      // Validate that foodItems is an array of strings
      if (!foodItems || !Array.isArray(foodItems) || foodItems.length === 0) {
        return res.status(400).json({ 
          success: false,
          message: "Invalid food items. Please provide an array of food items." 
        });
      }

      // Check if the OpenAI API key is configured
      if (!process.env.OPENAI_API_KEY) {
        return res.status(500).json({
          success: false,
          message: "OpenAI API key is not configured. Please add your API key to continue."
        });
      }

      // Call OpenAI to analyze the food
      const analysis = await analyzeNutrition(foodItems);

      return res.json({ 
        success: true, 
        analysis: {
          foodItems: foodItems,
          calories: Math.round(analysis.healthAssessment.score * 150), // Estimate calories
          protein: Math.round(analysis.healthAssessment.score * 5),   // Estimate protein
          carbs: Math.round(analysis.healthAssessment.score * 10),    // Estimate carbs
          fat: Math.round(analysis.healthAssessment.score * 3),       // Estimate fat
          fiber: Math.round(analysis.healthAssessment.score * 2),     // Estimate fiber
          healthScore: analysis.healthAssessment.score,
          category: analysis.healthAssessment.category,
          summary: analysis.healthAssessment.summary,
          nutritionalHighlights: analysis.healthAssessment.nutritionalHighlights,
          healthBenefits: analysis.healthAssessment.healthBenefits,
          concerns: analysis.healthAssessment.concerns,
          alternatives: analysis.healthAssessment.alternatives
        }
      });
    } catch (error) {
      console.error("Error analyzing food:", error);

      // Provide better error messages based on the error type
      if ((error as any).status === 401) {
        return res.status(401).json({
          success: false,
          message: "OpenAI API key is invalid or has insufficient permissions.",
          error: "Please check your API key settings."
        });
      }

      return res.status(500).json({ 
        success: false, 
        message: "Failed to analyze food", 
        error: (error as Error).message 
      });
    }
  });

  // Food Analysis API - Analyze food image
  app.post("/api/food/analyze", async (req, res) => {
    try {
      const { image } = req.body;

      // Validate that image is a base64 string
      if (!image || typeof image !== 'string') {
        return res.status(400).json({ 
          success: false,
          message: "Invalid image data. Please provide a base64 encoded image." 
        });
      }

      // Check if the OpenAI API key is configured
      if (!process.env.OPENAI_API_KEY) {
        return res.status(500).json({
          success: false,
          message: "OpenAI API key is not configured. Please add your API key to continue."
        });
      }

      // Remove data URL prefix if present
      const base64Image = image.replace(/^data:image\/(png|jpeg|jpg);base64,/, '');

      // Call OpenAI to analyze the food image
      const analysis = await analyzeFoodImage(base64Image);

      return res.json({ success: true, analysis });
    } catch (error) {
      console.error("Error analyzing food image:", error);

      // Provide better error messages based on the error type
      if ((error as any).status === 401) {
        return res.status(401).json({
          success: false,
          message: "OpenAI API key is invalid or has insufficient permissions.",
          error: "Please check your API key settings."
        });
      }

      return res.status(500).json({ 
        success: false, 
        message: "Failed to analyze food image", 
        error: (error as Error).message 
      });
    }
  });

  // API key verification endpoint
  app.get("/api/openai/verify", async (req, res) => {
    try {
      // Check if the OpenAI API key is configured
      if (!process.env.OPENAI_API_KEY) {
        return res.status(401).json({
          success: false,
          message: "OpenAI API key is not configured. Please add your API key to continue."
        });
      }

      // Return success if key exists
      return res.json({
        success: true,
        message: "OpenAI API key is configured."
      });
    } catch (error) {
      console.error("Error verifying API key:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to verify OpenAI API key configuration.",
        error: (error as Error).message
      });
    }
  });

  // Food Chat API - Chat with AI about food
  app.post("/api/food/chat", async (req, res) => {
    try {
      const { messages } = req.body;

      // Validate messages array
      if (!Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid messages. Please provide an array of chat messages." 
        });
      }

      // Check if the OpenAI API key is configured
      if (!process.env.OPENAI_API_KEY) {
        return res.status(500).json({
          success: false,
          message: "OpenAI API key is not configured. Please add your API key to continue."
        });
      }

      // Validate message format
      const chatMessageSchema = z.object({
        role: z.enum(['user', 'assistant', 'system']),
        content: z.string().min(1)
      });

      const messagesValid = messages.every(msg => {
        try {
          chatMessageSchema.parse(msg);
          return true;
        } catch (error) {
          return false;
        }
      });

      if (!messagesValid) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid message format. Each message must have 'role' and 'content' properties." 
        });
      }

      // Call OpenAI for chat response
      const response = await chatWithFoodAI(messages as ChatMessage[]);

      return res.json({ 
        success: true, 
        response,
        message: {
          role: 'assistant',
          content: response
        }
      });
    } catch (error) {
      console.error("Error in food chat:", error);

      // Provide better error messages based on the error type
      if ((error as any).status === 401) {
        return res.status(401).json({
          success: false,
          message: "OpenAI API key is invalid or has insufficient permissions.",
          error: "Please check your API key settings."
        });
      }

      return res.status(500).json({ 
        success: false, 
        message: "Failed to generate chat response", 
        error: (error as Error).message 
      });
    }
  });

  // Spoonacular API integration endpoints

  // Generate recipes with Spoonacular API
  app.post("/api/spoonacular/recipes", async (req, res) => {
    try {
      // Check if the Spoonacular API key is configured
      if (!process.env.SPOONACULAR_API_KEY) {
        return res.status(500).json({
          success: false,
          message: "Spoonacular API key is not configured. Please add your API key to continue."
        });
      }

      const validatedData = ingredientSchema.parse(req.body);

      console.log(`[Spoonacular] Generating recipes for ingredients: ${validatedData.ingredients.join(', ')}`);

      // Get active dietary filters as strings
      const dietaryFilterNames = validatedData.dietaryFilters
        .filter(filter => filter.active)
        .map(filter => filter.name);

      console.log(`[Spoonacular] With dietary filters: ${dietaryFilterNames.join(', ') || 'none'}`);
      console.log(`[Spoonacular] With cuisine type: ${validatedData.cuisineType || 'not specified'}`);
      console.log(`[Spoonacular] With servings: ${validatedData.servings || 2}`);

      const recipes = await generateRecipesWithSpoonacular(
        validatedData.ingredients,
        dietaryFilterNames,
        validatedData.cuisineType,
        validatedData.servings
      );

      console.log(`[Spoonacular] Successfully generated ${recipes.recipes.length} recipes`);

      return res.json({ success: true, ...recipes });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid request data", 
          errors: error.format() 
        });
      }

      console.error("Error generating recipes with Spoonacular:", error);

      return res.status(500).json({ 
        success: false, 
        message: "Failed to generate recipes", 
        error: (error as Error).message 
      });
    }
  });

  // Search for recipes by ingredients
  app.post("/api/spoonacular/search", async (req, res) => {
    try {
      // Check if the Spoonacular API key is configured
      if (!process.env.SPOONACULAR_API_KEY) {
        return res.status(500).json({
          success: false,
          message: "Spoonacular API key is not configured. Please add your API key to continue."
        });
      }

      const { ingredients, dietaryPreferences, number } = req.body;

      if (!ingredients || !Array.isArray(ingredients) || ingredients.length === 0) {
        return res.status(400).json({
          success: false,
          message: "Please provide at least one ingredient"
        });
      }

      const results = await searchRecipesByIngredients(
        ingredients,
        dietaryPreferences || [],
        number || 20
      );

      return res.json({ success: true, results });
    } catch (error) {
      console.error("Error searching recipes:", error);

      return res.status(500).json({ 
        success: false, 
        message: "Failed to search recipes", 
        error: (error as Error).message 
      });
    }
  });

  // Get detailed recipe information
  app.get("/api/spoonacular/recipes/:id", async (req, res) => {
    try {
      // Check if the Spoonacular API key is configured
      if (!process.env.SPOONACULAR_API_KEY) {
        return res.status(500).json({
          success: false,
          message: "Spoonacular API key is not configured. Please add your API key to continue."
        });
      }

      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({
          success: false,
          message: "Invalid recipe ID. Please provide a valid number."
        });
      }

      const includeNutrition = req.query.includeNutrition !== 'false';

      const recipe = await getRecipeInformation(id, includeNutrition);

      return res.json({ success: true, recipe });
    } catch (error) {
      console.error("Error fetching recipe information:", error);

      return res.status(500).json({ 
        success: false, 
        message: "Failed to fetch recipe information", 
        error: (error as Error).message 
      });
    }
  });

  // Get nutritional information for ingredients
  app.post("/api/spoonacular/nutrition", async (req, res) => {
    try {
      // Check if the Spoonacular API key is configured
      if (!process.env.SPOONACULAR_API_KEY) {
        return res.status(500).json({
          success: false,
          message: "Spoonacular API key is not configured. Please add your API key to continue."
        });
      }

      const { ingredients } = req.body;

      if (!ingredients || !Array.isArray(ingredients) || ingredients.length === 0) {
        return res.status(400).json({
          success: false,
          message: "Please provide at least one ingredient"
        });
      }

      const nutritionInfo = await getNutritionalInformation(ingredients);

      return res.json({ success: true, nutritionInfo });
    } catch (error) {
      console.error("Error fetching nutritional information:", error);

      return res.status(500).json({ 
        success: false, 
        message: "Failed to fetch nutritional information", 
        error: (error as Error).message 
      });
    }
  });

  // Verify Spoonacular API key
  app.get("/api/spoonacular/verify", async (req, res) => {
    try {
      // Check if the Spoonacular API key is configured
      if (!process.env.SPOONACULAR_API_KEY) {
        return res.status(401).json({
          success: false,
          message: "Spoonacular API key is not configured. Please add your API key to continue."
        });
      }

      // Just a simple test query to check if the API key works
      await searchRecipesByIngredients(["apple"], [], 1);

      // Return success if key exists and works
      return res.json({
        success: true,
        message: "Spoonacular API key is valid and working."
      });
    } catch (error) {
      console.error("Error verifying Spoonacular API key:", error);

      // Check for specific authentication errors
      if ((error as Error).message.includes("API key is invalid")) {
        return res.status(401).json({
          success: false,
          message: "Spoonacular API key is invalid. Please check your API key settings.",
          error: (error as Error).message
        });
      }

      return res.status(500).json({
        success: false,
        message: "Failed to verify Spoonacular API key configuration.",
        error: (error as Error).message
      });
    }
  });

  // Nutrition log endpoints
  app.get("/api/nutrition/logs", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const logs = await storage.getNutritionLogs(userId);
      return res.json(logs);
    } catch (error) {
      console.error("Error fetching nutrition logs:", error);
      return res.status(500).json({ message: "Failed to fetch nutrition logs" });
    }
  });

  app.get("/api/nutrition/stats", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const period = req.query.period as 'day' | 'week' | 'month' | undefined;
      const stats = await storage.getUserNutritionStats(userId, period);
      return res.json(stats);
    } catch (error) {
      console.error("Error fetching nutrition stats:", error);
      return res.status(500).json({ message: "Failed to fetch nutrition stats" });
    }
  });

  app.post("/api/nutrition/logs", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Add user ID to the log
      const logData = {
        ...req.body,
        userId
      };

      const log = await storage.saveNutritionLog(logData);
      return res.status(201).json(log);
    } catch (error) {
      console.error("Error saving nutrition log:", error);
      return res.status(500).json({ message: "Failed to save nutrition log" });
    }
  });
  
  // Log a completed recipe to the nutrition dashboard
  app.post("/api/nutrition/log", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const { recipeId, date, servings } = req.body;
      
      // Get the recipe details
      const recipe = await storage.getRecipe(recipeId);
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      
      // Create a nutrition log entry based on the recipe
      const nutrition = recipe.nutrition as Record<string, number>;
      
      // Calculate servings ratio to adjust nutritional values
      const servingsRatio = servings ? servings / recipe.servings : 1;
      
      const logData = {
        userId,
        date: date ? new Date(date) : new Date(),
        recipeId,
        mealType: 'dinner', // Default to dinner, can be adjusted
        foodItems: recipe.ingredients, // Already an array in the recipe
        calories: Math.round(recipe.calories * servingsRatio),
        protein: nutrition?.protein ? Math.round(nutrition.protein * servingsRatio) : 0,
        carbs: nutrition?.carbs ? Math.round(nutrition.carbs * servingsRatio) : 0,
        fat: nutrition?.fat ? Math.round(nutrition.fat * servingsRatio) : 0,
        fiber: nutrition?.fiber ? Math.round(nutrition.fiber * servingsRatio) : 0,
        healthScore: recipe.healthScore || 0,
        notes: `Completed recipe: ${recipe.title} (${servings || recipe.servings} servings)`
      };
      
      const log = await storage.saveNutritionLog(logData);
      
      return res.status(201).json({
        success: true,
        message: "Recipe logged successfully",
        log
      });
    } catch (error) {
      console.error("Error logging completed recipe:", error);
      return res.status(500).json({ 
        success: false,
        message: "Failed to log completed recipe" 
      });
    }
  });

  app.get("/api/nutrition/logs/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid log ID" });
      }

      const log = await storage.getNutritionLog(id);
      if (!log) {
        return res.status(404).json({ message: "Nutrition log not found" });
      }

      // Make sure the user can only access their own logs
      if (log.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      return res.json(log);
    } catch (error) {
      console.error("Error fetching nutrition log:", error);
      return res.status(500).json({ message: "Failed to fetch nutrition log" });
    }
  });
  
  // Nutrition goals endpoints
  app.get("/api/nutrition/goals", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const goals = await storage.getNutritionGoals(userId);
      return res.json(goals || {}); // Return empty object if no goals exist
    } catch (error) {
      console.error("Error fetching nutrition goals:", error);
      return res.status(500).json({ message: "Failed to fetch nutrition goals" });
    }
  });
  
  app.post("/api/nutrition/goals", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Check if goals already exist
      const existingGoals = await storage.getNutritionGoals(userId);
      
      let goals;
      if (existingGoals) {
        // Update existing goals
        goals = await storage.updateNutritionGoals(userId, {
          ...req.body,
          userId
        });
      } else {
        // Create new goals
        goals = await storage.saveNutritionGoals({
          ...req.body,
          userId
        });
      }
      
      return res.status(201).json(goals);
    } catch (error) {
      console.error("Error saving nutrition goals:", error);
      return res.status(500).json({ message: "Failed to save nutrition goals" });
    }
  });

  // User update endpoint
  app.post('/api/user/update', async (req: Request, res: Response) => {
    try {
      const { username, fullName, email } = req.body;
      
      // Debug session information
      console.log('Update user session:', {
        sessionID: req.sessionID,
        hasSession: !!req.session,
        isAuthenticated: req.session?.isAuthenticated,
        userId: req.session?.userId
      });
      
      if (!req.session.userId) {
        return res.status(401).json({ success: false, error: 'Not authenticated' });
      }

      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ success: false, error: 'User not found' });
      }

      // Only update fields that have changed
      const updates: any = {};
      if (username && username !== user.username) updates.username = username;
      if (fullName && fullName !== user.name) updates.name = fullName;
      if (email && email !== user.email) updates.email = email;

      // Only make database call if there are actual changes
      const updatedUser = Object.keys(updates).length > 0 ? 
        await storage.updateUser(req.session.userId, updates) : 
        user;

      // Make sure session is saved before responding
      req.session.save((err) => {
        if (err) {
          console.error('Error saving session:', err);
          return res.status(500).json({ success: false, error: 'Failed to save session' });
        }
        
        // Return the updated user data
        res.json({ 
          success: true, 
          message: 'User updated successfully',
          user: updatedUser
        });
      });
    } catch (error: any) {
      console.error('Error updating user:', error);
      
      // Check for username conflict error - Postgres unique constraint violation
      if (error && typeof error === 'object' && 'code' in error && 'constraint' in error && 
          error.code === '23505' && error.constraint === 'users_username_key') {
        return res.status(409).json({ 
          success: false, 
          error: 'username_already_taken',
          message: 'Username already taken. Please choose a different username.' 
        });
      }
      
      res.status(500).json({ success: false, error: 'Failed to update user' });
    }
  });

  // Weight tracking endpoints
  app.post('/api/weight/log', async (req: Request, res: Response) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ success: false, message: 'Not authenticated' });
      }

      const { weight, date } = req.body;
      
      if (!weight || typeof weight !== 'number' || weight <= 0) {
        return res.status(400).json({ success: false, message: 'Valid weight value is required' });
      }

      const weightLog = await storage.saveWeightLog({
        userId: req.session.userId,
        weightKg: weight,
        date: date ? new Date(date) : new Date(),
      });

      res.status(201).json({ success: true, weightLog });
    } catch (error) {
      console.error('Error logging weight:', error);
      res.status(500).json({ success: false, message: 'Failed to log weight' });
    }
  });

  app.get('/api/weight/logs', async (req: Request, res: Response) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ success: false, message: 'Not authenticated' });
      }

      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;

      const weightLogs = await storage.getWeightLogs(req.session.userId, startDate, endDate);
      res.json({ success: true, weightLogs });
    } catch (error) {
      console.error('Error fetching weight logs:', error);
      res.status(500).json({ success: false, message: 'Failed to fetch weight logs' });
    }
  });

  app.get('/api/weight/latest', async (req: Request, res: Response) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ success: false, message: 'Not authenticated' });
      }

      const latestWeightLog = await storage.getLatestWeightLog(req.session.userId);
      res.json({ success: true, weightLog: latestWeightLog || null });
    } catch (error) {
      console.error('Error fetching latest weight:', error);
      res.status(500).json({ success: false, message: 'Failed to fetch latest weight' });
    }
  });

  // Health assessment endpoint
  app.get('/api/health/assessment', async (req: Request, res: Response) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ success: false, message: 'Not authenticated' });
      }

      const healthAssessment = await storage.getHealthAssessment(req.session.userId);
      res.json({ success: true, assessment: healthAssessment });
    } catch (error) {
      console.error('Error generating health assessment:', error);
      res.status(500).json({ success: false, message: 'Failed to generate health assessment' });
    }
  });
  
  // Cooking chat API endpoint
  app.post('/api/chat/cooking', async (req: Request, res: Response) => {
    try {
      const { messages, recipe, action, recipeId } = req.body;
      
      // Handle special actions
      if (action === 'save_recipe' && recipeId && req.session.userId) {
        try {
          // Get the recipe details
          const recipeData = await storage.getRecipe(recipeId);
          if (!recipeData) {
            return res.status(404).json({ success: false, message: 'Recipe not found' });
          }
          
          // Save to nutrition log
          const logData = {
            userId: req.session.userId,
            date: new Date(),
            recipeId,
            mealType: 'dinner', // Default to dinner
            foodItems: recipeData.ingredients,
            calories: recipeData.calories,
            protein: (recipeData.nutrition as any)?.protein || 0,
            carbs: (recipeData.nutrition as any)?.carbs || 0,
            fat: (recipeData.nutrition as any)?.fat || 0,
            fiber: (recipeData.nutrition as any)?.fiber || 0,
            healthScore: recipeData.healthScore || 0,
            notes: `Completed recipe: ${recipeData.title} (${recipeData.servings} servings)`
          };
          
          await storage.saveNutritionLog(logData);
          
          return res.json({
            success: true,
            message: `I've saved ${recipeData.title} to your nutrition log! Great job completing this recipe.`,
            recipeSaved: true
          });
        } catch (error) {
          console.error('Error saving recipe from chat:', error);
          return res.json({
            success: true,
            message: "I'm sorry, I couldn't save this recipe to your nutrition log. There was a technical issue.",
            recipeSaved: false
          });
        }
      }
      
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ success: false, message: 'Invalid messages array' });
      }
      
      // Detect save recipe intent in the last user message
      const lastUserMessage = [...messages].reverse().find(msg => msg.role === 'user');
      if (
        lastUserMessage && 
        recipeId &&
        req.session.userId &&
        /save|log|add|track|record|complete|done|finish|nutrition/i.test(lastUserMessage.content)
      ) {
        try {
          // Analyze the message content for save intent
          const intentMessage = lastUserMessage.content.toLowerCase();
          const hasSaveIntent = /save|log|add|track|record|complete|done|finish/i.test(intentMessage) &&
                               /recipe|food|meal|dish|nutrition/i.test(intentMessage);
                               
          if (hasSaveIntent) {
            // Get the recipe details
            const recipeData = await storage.getRecipe(recipeId);
            if (!recipeData) {
              // If recipe not found, still respond but continue with normal message
              const response = await chatWithFoodAI(messages);
              return res.json({ success: true, message: response });
            }
            
            // Save to nutrition log
            const logData = {
              userId: req.session.userId,
              date: new Date(),
              recipeId,
              mealType: 'dinner', // Default to dinner
              foodItems: recipeData.ingredients,
              calories: recipeData.calories,
              protein: (recipeData.nutrition as any)?.protein || 0,
              carbs: (recipeData.nutrition as any)?.carbs || 0,
              fat: (recipeData.nutrition as any)?.fat || 0,
              fiber: (recipeData.nutrition as any)?.fiber || 0,
              healthScore: recipeData.healthScore || 0,
              notes: `Completed recipe: ${recipeData.title} (${recipeData.servings} servings)`
            };
            
            await storage.saveNutritionLog(logData);
            
            return res.json({
              success: true,
              message: `I've saved ${recipeData.title} to your nutrition log! Great job completing this recipe.`,
              recipeSaved: true
            });
          }
        } catch (error) {
          console.error('Error detecting save intent:', error);
          // Continue with normal response flow if there's an error
        }
      }
      
      // Normal chat flow - Get chat response from OpenAI
      const response = await chatWithFoodAI(messages);
      
      return res.json({ 
        success: true, 
        message: response
      });
    } catch (error) {
      console.error('Error in cooking chat:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'Failed to get response from assistant' 
      });
    }
  });
  
  // Commenting out duplicate endpoint, we already have a similar endpoint above
  // app.post('/api/nutrition/log', async (req: Request, res: Response) => { ... }
  
  // Badge endpoints
  app.get('/api/badges', async (req, res) => {
    try {
      const { category, season } = req.query;
      const badges = await storage.getBadges(
        category as string | undefined, 
        season as string | undefined
      );
      return res.json(badges);
    } catch (error) {
      console.error("Error fetching badges:", error);
      return res.status(500).json({ message: "Failed to fetch badges" });
    }
  });
  
  app.get('/api/badges/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid badge ID" });
      }
      
      const badge = await storage.getBadge(id);
      if (!badge) {
        return res.status(404).json({ message: "Badge not found" });
      }
      
      return res.json(badge);
    } catch (error) {
      console.error("Error fetching badge:", error);
      return res.status(500).json({ message: "Failed to fetch badge" });
    }
  });
  
  app.get('/api/users/:userId/badges', isAuthenticated, async (req, res) => {
    try {
      const requestedUserId = parseInt(req.params.userId);
      const currentUserId = req.session.userId;
      
      // Only allow users to access their own badges or admin users
      if (!currentUserId || (currentUserId !== requestedUserId && !req.session.isAdmin)) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own badges' });
      }
      
      const badges = await storage.getUserBadges(requestedUserId);
      return res.json(badges);
    } catch (error) {
      console.error("Error fetching user badges:", error);
      return res.status(500).json({ message: "Failed to fetch user badges" });
    }
  });
  
  app.post('/api/users/:userId/badges/:badgeId', isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const badgeId = parseInt(req.params.badgeId);
      const currentUserId = req.session.userId;
      const { progress } = req.body;
      
      // Only allow users to update their own data or admin users
      if (!currentUserId || (currentUserId !== userId && !req.session.isAdmin)) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own badges' });
      }
      
      const userBadge = await storage.awardBadgeToUser(userId, badgeId, progress);
      return res.status(201).json(userBadge);
    } catch (error) {
      console.error("Error awarding badge:", error);
      return res.status(500).json({ message: "Failed to award badge" });
    }
  });
  
  // Challenge endpoints
  app.get('/api/challenges', async (req, res) => {
    try {
      const { season } = req.query;
      const challenges = await storage.getActiveChallenges(season as string | undefined);
      return res.json(challenges);
    } catch (error) {
      console.error("Error fetching challenges:", error);
      return res.status(500).json({ message: "Failed to fetch challenges" });
    }
  });
  
  app.get('/api/challenges/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid challenge ID" });
      }
      
      const challenge = await storage.getChallenge(id);
      if (!challenge) {
        return res.status(404).json({ message: "Challenge not found" });
      }
      
      return res.json(challenge);
    } catch (error) {
      console.error("Error fetching challenge:", error);
      return res.status(500).json({ message: "Failed to fetch challenge" });
    }
  });
  
  app.get('/api/users/:userId/challenges', isAuthenticated, async (req, res) => {
    try {
      const requestedUserId = parseInt(req.params.userId);
      const currentUserId = req.session.userId;
      
      // Only allow users to access their own challenges or admin users
      if (!currentUserId || (currentUserId !== requestedUserId && !req.session.isAdmin)) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own challenges' });
      }
      
      const challenges = await storage.getUserChallenges(requestedUserId);
      return res.json(challenges);
    } catch (error) {
      console.error("Error fetching user challenges:", error);
      return res.status(500).json({ message: "Failed to fetch user challenges" });
    }
  });
  
  app.post('/api/users/:userId/challenges/:challengeId/start', isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const challengeId = parseInt(req.params.challengeId);
      const currentUserId = req.session.userId;
      
      // Only allow users to update their own data or admin users
      if (!currentUserId || (currentUserId !== userId && !req.session.isAdmin)) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own challenges' });
      }
      
      const challenge = await storage.startChallenge(userId, challengeId);
      return res.status(201).json(challenge);
    } catch (error) {
      console.error("Error starting challenge:", error);
      return res.status(500).json({ message: "Failed to start challenge" });
    }
  });
  
  app.post('/api/users/:userId/challenges/:challengeId/update', isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const challengeId = parseInt(req.params.challengeId);
      const currentUserId = req.session.userId;
      const { recipeId } = req.body;
      
      // Only allow users to update their own data or admin users
      if (!currentUserId || (currentUserId !== userId && !req.session.isAdmin)) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own challenges' });
      }
      
      const challenge = await storage.updateChallengeProgress(userId, challengeId, recipeId);
      return res.json(challenge);
    } catch (error) {
      console.error("Error updating challenge:", error);
      return res.status(500).json({ message: "Failed to update challenge" });
    }
  });
  
  app.post('/api/users/:userId/challenges/:challengeId/complete', isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const challengeId = parseInt(req.params.challengeId);
      const currentUserId = req.session.userId;
      
      // Only allow users to update their own data or admin users
      if (!currentUserId || (currentUserId !== userId && !req.session.isAdmin)) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own challenges' });
      }
      
      const challenge = await storage.completeChallenge(userId, challengeId);
      return res.json(challenge);
    } catch (error) {
      console.error("Error completing challenge:", error);
      return res.status(500).json({ message: "Failed to complete challenge" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}