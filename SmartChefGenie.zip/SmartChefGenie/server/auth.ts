import bcrypt from 'bcrypt';
import { storage } from './storage';
import { InsertUser } from '@shared/schema';

export async function loginUser(email: string, password: string) {
  console.log(`Attempting login for email: ${email}`);
  
  // Get user by email
  const user = await storage.getUserByEmail(email);
  
  if (!user || !user.password) {
    console.log(`User not found with email: ${email}`);
    throw new Error('Account not found. Please register first.');
  }
  
  const isPasswordValid = await bcrypt.compare(password, user.password);
  
  if (!isPasswordValid) {
    console.log('Invalid password entered');
    throw new Error('Invalid password');
  }
  
  console.log(`User ${user.username} logged in successfully`);
  
  // Don't return the password
  const { password: _, ...userWithoutPassword } = user;
  
  return userWithoutPassword;
}

export async function registerUser(userData: InsertUser & { confirmPassword?: string, dateOfBirth?: string | Date }) {
  console.log(`Attempting to register user with email: ${userData.email}`);
  
  // Check if user already exists with this email
  const existingUser = await storage.getUserByEmail(userData.email || '');
  
  if (existingUser) {
    console.log(`Registration failed: Email already in use - ${userData.email}`);
    throw new Error('Email already in use');
  }
  
  // Generate a unique username if the provided one is already taken
  let username = userData.username;
  let counter = 1;
  
  // Check if username exists and generate a unique one by appending a number
  while (await storage.getUserByUsername(username)) {
    console.log(`Username ${username} already exists, trying alternative...`);
    username = `${userData.username}${counter}`;
    counter++;
    
    // Safety limit to prevent infinite loop
    if (counter > 100) {
      console.log(`Failed to generate unique username after 100 attempts for ${userData.username}`);
      throw new Error('Unable to generate a unique username. Please try with a different username.');
    }
  }
  
  // Update the username if it was changed
  if (username !== userData.username) {
    console.log(`Generated unique username: ${username} (original: ${userData.username})`);
    userData.username = username;
  }
  
  // Hash password
  if (userData.password) {
    const salt = await bcrypt.genSalt(10);
    userData.password = await bcrypt.hash(userData.password, salt);
  }
  
  // Remove confirmPassword if it exists and convert dateOfBirth from string to Date if needed
  const { confirmPassword, dateOfBirth, ...userDataWithoutConfirm } = userData;
  
  // Convert dateOfBirth string to Date object if provided
  const dateOfBirthDate = dateOfBirth 
    ? (typeof dateOfBirth === 'string' ? new Date(dateOfBirth) : dateOfBirth) 
    : null;
  
  // Set default health profile values if not provided
  const userWithDefaults = {
    ...userDataWithoutConfirm,
    dateOfBirth: dateOfBirthDate,
    provider: userDataWithoutConfirm.provider || 'credentials',
    allergies: userDataWithoutConfirm.allergies || [],
    medicalConditions: userDataWithoutConfirm.medicalConditions || [],
    dietaryRestrictions: userDataWithoutConfirm.dietaryRestrictions || [],
    isPregnant: userDataWithoutConfirm.isPregnant ?? false,
  };
  
  console.log(`Creating new user: ${userData.username}`);
  
  // Create user
  const newUser = await storage.createUser(userWithDefaults);
  
  console.log(`User registered successfully: ${newUser.username} (ID: ${newUser.id})`);
  
  // Don't return the password
  const { password: _, ...userWithoutPassword } = newUser;
  
  return userWithoutPassword;
}

export async function getUserById(id: number) {
  const user = await storage.getUser(id);
  
  if (!user) {
    return null;
  }
  
  // Don't return the password
  const { password: _, ...userWithoutPassword } = user;
  
  return userWithoutPassword;
}

export async function getUserByProvider(provider: string, providerId: string) {
  const user = await storage.getUserByProviderId(provider, providerId);
  
  if (!user) {
    return null;
  }
  
  // Don't return the password
  const { password: _, ...userWithoutPassword } = user;
  
  return userWithoutPassword;
}

export async function createUserFromProvider(
  provider: string,
  providerId: string,
  email: string,
  name: string,
  image?: string
) {
  // Generate a unique username based on the name
  const baseUsername = name.toLowerCase().replace(/\s+/g, '');
  let username = baseUsername;
  let counter = 1;
  
  // Check if username exists and append a number if necessary
  while (await storage.getUserByUsername(username)) {
    username = `${baseUsername}${counter}`;
    counter++;
  }
  
  const userData: InsertUser = {
    username,
    email,
    name,
    image,
    provider,
    providerId,
    // Default health profile values
    dateOfBirth: null,
    isPregnant: false,
    allergies: [],
    medicalConditions: [],
    dietaryRestrictions: [],
  };
  
  // Create user
  const newUser = await storage.createUser(userData);
  
  // Don't return the password
  const { password: _, ...userWithoutPassword } = newUser;
  
  return userWithoutPassword;
}