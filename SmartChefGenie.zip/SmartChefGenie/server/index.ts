import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { setupSession } from "./session";
import { setupOAuth } from "./oauth";
import { storage } from "./storage";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

const app = express();
app.use(express.json({ limit: '50mb' })); // Increase limit for image uploads
app.use(express.urlencoded({ extended: false }));

// Setup session
setupSession(app);

// Setup OAuth
setupOAuth(app);

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Initialize the database
  if (process.env.DATABASE_URL) {
    let retryCount = 0;
    const maxRetries = 3;
    let initialized = false;
    
    while (!initialized && retryCount < maxRetries) {
      try {
        await storage.initDb();
        console.log('Database initialized successfully');
        initialized = true;
      } catch (error: any) {
        retryCount++;
        
        // Check if this is a connection error that we should retry
        const isConnectionError = error.code && (
          error.code === '57P01' || // admin_shutdown
          error.code === '08006' || // connection_failure 
          error.code === '08001' || // sqlclient_unable_to_establish_sqlconnection
          error.code === '08004'    // sqlserver_rejected_establishment_of_sqlconnection
        );
        
        if (isConnectionError && retryCount < maxRetries) {
          const backoffMs = Math.min(1000 * Math.pow(2, retryCount), 10000);
          console.error(`Database initialization failed (attempt ${retryCount}/${maxRetries}), retrying in ${backoffMs}ms...`);
          await new Promise(resolve => setTimeout(resolve, backoffMs));
        } else {
          console.error('Failed to initialize database after multiple attempts:', error);
          console.log('Continuing startup with limited functionality. Database operations may fail.');
          break;
        }
      }
    }
  } else {
    console.log('Using memory storage (no DATABASE_URL provided)');
  }

  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    console.error("Unhandled error:", err);
    
    // Check for PostgreSQL connection errors
    if (err.code && (
      err.code === '57P01' || // admin_shutdown (PostgreSQL was shut down)
      err.code === '08006' || // connection_failure
      err.code === '08001' || // sqlclient_unable_to_establish_sqlconnection
      err.code === '08004'    // sqlserver_rejected_establishment_of_sqlconnection
    )) {
      console.error("Database connection error detected. Attempting to recover...");
      
      // Return a more user-friendly message for database errors
      return res.status(503).json({
        message: "The database is temporarily unavailable. Please try again in a moment.",
        error: "Database connection error",
        retryable: true
      });
    }
    
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    
    // Don't throw the error again, which would crash the server
    // Just log it and let the application continue running
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();