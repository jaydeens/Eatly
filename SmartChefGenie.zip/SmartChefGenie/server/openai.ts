import OpenAI from "openai";
import { GeneratedRecipes } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
// Support for both standard API keys and project-based API keys
const apiKey = process.env.OPENAI_API_KEY || "";

if (!apiKey) {
  console.error("OPENAI_API_KEY environment variable is not set. AI features will not work.");
}

// Clean the API key to remove any formatting issues
const cleanedApiKey = apiKey.trim().replace(/\s+/g, "");

console.log("Initializing OpenAI client with API key (first 5 chars):", cleanedApiKey.substring(0, 5) + "...");

export const openai = new OpenAI({ 
  apiKey: cleanedApiKey,
  dangerouslyAllowBrowser: false
});

type DietaryFilter = {
  name: string;
  active: boolean;
  icon: string;
};

// Types for food analysis responses
export type FoodAnalysisResult = {
  foodItems: string[];
  healthAssessment: {
    score: number;
    category: 'Very Healthy' | 'Healthy' | 'Moderate' | 'Unhealthy' | 'Very Unhealthy';
    summary: string;
    nutritionalHighlights: string[];
    healthBenefits: string[];
    concerns: string[];
    alternatives: string[];
  };
};

export type ChatMessage = {
  role: 'user' | 'assistant' | 'system';
  content: string;
};

// Import the Clarifai food analysis function
import { analyzeFoodImageWithClarifai, analyzeFoodImageHybrid } from './clarifai';

// Analyze food items using OpenAI (without vision capability)
export async function analyzeNutrition(foodItems: string[]): Promise<FoodAnalysisResult> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: 
            "You are a nutritionist and food expert AI. Analyze the foods listed, " +
            "and provide a detailed health assessment. Be precise and thorough in your analysis."
        },
        {
          role: "user",
          content: `Please analyze these food items and provide the following information in JSON format:
            Food items: ${foodItems.join(", ")}

            Please provide:
            1. A health assessment score from 1-10
            2. Categorize as 'Very Healthy', 'Healthy', 'Moderate', 'Unhealthy', or 'Very Unhealthy'
            3. Provide a summary of the nutritional profile
            4. List nutritional highlights, health benefits, concerns, and healthier alternatives if applicable`
        },
      ],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Failed to analyze nutrition: Empty response from OpenAI");
    }

    // Parse the response
    const analysisData = JSON.parse(content);

    // Transform to match our expected format
    const result: FoodAnalysisResult = {
      foodItems: foodItems,
      healthAssessment: {
        score: analysisData.healthAssessment?.score || 5,
        category: analysisData.healthAssessment?.category || 'Moderate',
        summary: analysisData.healthAssessment?.summary || 'No summary provided',
        nutritionalHighlights: analysisData.healthAssessment?.nutritionalHighlights || [],
        healthBenefits: analysisData.healthAssessment?.healthBenefits || [],
        concerns: analysisData.healthAssessment?.concerns || [],
        alternatives: analysisData.healthAssessment?.alternatives || []
      }
    };

    return result;
  } catch (error) {
    console.error("Failed to analyze nutrition:", error);

    // Provide a more user-friendly error message
    let errorMessage = "Failed to analyze nutrition";

    if ((error as any).status === 401) {
      errorMessage += ": API key is invalid or has insufficient permissions. Please check your OpenAI API key settings.";
    } else if ((error as Error).message) {
      errorMessage += ": " + (error as Error).message;
    }

    throw new Error(errorMessage);
  }
}

// Main function to analyze food image - uses Clarifai for food detection and OpenAI for nutritional analysis
export async function analyzeFoodImage(base64Image: string): Promise<FoodAnalysisResult> {
  try {
    // Use the hybrid approach with Clarifai for food detection and OpenAI for nutritional analysis
    return await analyzeFoodImageHybrid(base64Image, analyzeNutrition);
  } catch (error) {
    console.error("Failed to analyze food image:", error);

    // Provide a more user-friendly error message
    let errorMessage = "Failed to analyze food image";

    if ((error as any).status === 401) {
      errorMessage += ": API key is invalid or has insufficient permissions. Please check your API key settings.";
    } else if ((error as Error).message) {
      errorMessage += ": " + (error as Error).message;
    }

    throw new Error(errorMessage);
  }
}

// Chat with AI about food
export async function chatWithFoodAI(messages: ChatMessage[]): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: 
            "You are a nutritionist and chef AI assistant named Personal Coach (PC). When users ask about what to cook, what to make, " +
            "or what they can prepare with ingredients, first direct them to use our recipe generation feature by saying " +
            "\"I notice you're asking about meal preparation! Click the button below to try our recipe generator:\n\n" +
            "<RecipeGeneratorButton />\n\n" +
            "But I'm also happy to provide some general suggestions:\" followed by your response. For all other food-related " +
            "questions, provide helpful, accurate, and friendly advice about nutrition and health. Be conversational and " +
            "keep responses concise but informative. IMPORTANT: Never use asterisks (*) for emphasis - use direct formatting, like 'this is important' instead of '*this is important*'."
        },
        ...messages
      ]
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI");
    }

    return content;
  } catch (error) {
    console.error("Failed to chat with AI:", error);

    // Provide a more user-friendly error message
    let errorMessage = "Failed to chat with AI";

    if ((error as any).status === 401) {
      errorMessage += ": API key is invalid or has insufficient permissions. Please check your OpenAI API key settings.";
    } else if ((error as Error).message) {
      errorMessage += ": " + (error as Error).message;
    }

    throw new Error(errorMessage);
  }
}

// Health profile placeholder - removed to simplify application structure


export async function generateRecipes(
  ingredients: string[],
  dietaryFilters: DietaryFilter[],
  cuisineType?: string,
  servings: number = 2,
  userId?: string // Added userId parameter
): Promise<GeneratedRecipes> {
  // Get active dietary filters
  const activeFilters = dietaryFilters
    .filter((filter) => filter.active)
    .map((filter) => filter.name);

  console.log(`Generating recipes with OpenAI API:`);
  console.log(`- Ingredients: ${ingredients.join(', ')}`);
  console.log(`- Dietary filters: ${activeFilters.length ? activeFilters.join(', ') : 'none'}`);
  console.log(`- Cuisine type: ${cuisineType || 'not specified'}`);

  // Create the prompt
  const prompt = createRecipePrompt(ingredients, activeFilters, cuisineType, servings, userId);

  try {
    // Call OpenAI API
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional chef who creates delicious recipes based on available ingredients. Your recipes are creative, practical, and include detailed nutritional information. IMPORTANT: Never use asterisks (*) for emphasis - use direct formatting, like 'this is important' instead of '*this is important*'.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Failed to generate recipes: Empty response from OpenAI");
    }

    // Parse the response
    const recipeData = JSON.parse(content);

    // Generate images for each recipe
    const recipes = await Promise.all(
      recipeData.recipes.map(async (recipe: any) => {
        try {
          const imageUrl = await generateRecipeImage(recipe.title, recipe.description);
          return { ...recipe, image: imageUrl };
        } catch (error) {
          console.error("Failed to generate image for recipe:", error);
          // Fallback image
          return { 
            ...recipe, 
            image: getRandomFoodImage(recipe.tags)
          };
        }
      })
    );

    console.log(`Successfully generated ${recipes.length} recipes with OpenAI API`);
    if (cuisineType) {
      const cuisineTagCount = recipes.filter(recipe => 
        recipe.tags && recipe.tags.some((tag: string) => 
          tag.toLowerCase() === cuisineType.toLowerCase()
        )
      ).length;
      console.log(`${cuisineTagCount} of ${recipes.length} recipes have the ${cuisineType} cuisine tag`);
    }

    return { recipes };
  } catch (error) {
    console.error("Failed to generate recipes:", error);

    // Provide a more user-friendly error message
    let errorMessage = "Failed to generate recipes";

    if ((error as any).status === 401) {
      errorMessage += ": API key is invalid or has insufficient permissions. Please check your OpenAI API key settings.";
    } else if ((error as Error).message) {
      errorMessage += ": " + (error as Error).message;
    }

    throw new Error(errorMessage);
  }
}

async function generateRecipeImage(title: string, description: string): Promise<string> {
  try {
    const prompt = `A professional food photography image of ${title}. ${description}. The image should be high quality, well-lit, from a top-down perspective with the dish on a neutral plate/bowl against a clean background. No text overlay.`;

    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt,
      n: 1,
      size: "1024x1024",
      quality: "standard",
    });

    return response.data[0].url || getRandomFoodImage([]);
  } catch (error) {
    console.error("Failed to generate image:", error);
    return getRandomFoodImage([]);
  }
}

function createRecipePrompt(ingredients: string[], dietaryFilters: string[], cuisineType?: string, servings: number = 2, userId?: string): string {
  const dietaryRestrictions = dietaryFilters.length > 0
    ? `The recipes must be suitable for the following dietary restrictions: ${dietaryFilters.join(", ")}.`
    : "There are no specific dietary restrictions.";

  const cuisinePreference = cuisineType
    ? `Please create authentic ${cuisineType} cuisine recipes. Ensure ingredients, cooking methods, and flavor profiles are traditionally used in ${cuisineType} cooking. Focus on maintaining cultural authenticity while incorporating the available ingredients.`
    : "";

  const tagInstruction = cuisineType
    ? `Always include "${cuisineType}" as the first tag for each recipe to indicate the cuisine type.`
    : "Include tags that best represent the recipe's attributes.";

  return `
  Please create 12 unique recipes using some or all of these ingredients: ${ingredients.join(", ")}. 
  ${dietaryRestrictions}
  ${cuisinePreference}

  Please provide a detailed recipe that uses these ingredients: ${ingredients.join(", ")}.
  All recipes should be designed for ${servings} servings.

  For each recipe, provide:
  1. A catchy title
  2. A brief description (1-2 sentences)
  3. Preparation time (in minutes)
  4. Number of servings (set to ${servings})
  5. Calorie count per serving
  6. Difficulty level (Easy, Medium, Hard)
  7. Tags (${tagInstruction})
  8. A complete list of ingredients with measurements
  9. Step-by-step cooking instructions
  10. Nutritional information (protein, carbs, fat, fiber in grams)
  11. Chef's tips for best results

  Respond with a JSON object following this structure:
  {
    "recipes": [
      {
        "title": "Recipe Title",
        "description": "Brief description",
        "time": "XX mins",
        "servings": ${servings},
        "calories": 350,
        "difficulty": "Easy/Medium/Hard",
        "tags": ["Tag1", "Tag2"],
        "ingredients": ["Ingredient 1", "Ingredient 2"],
        "instructions": ["Step 1", "Step 2"],
        "nutrition": {
          "protein": 20,
          "carbs": 30,
          "fat": 15,
          "fiber": 5
        },
        "tips": "Chef's tips and recommendations"
      }
    ]
  }
  `;
}

// Fallback food images
function getRandomFoodImage(tags: string[]): string {
  const imageMap: Record<string, string[]> = {
    "Vegetarian": [
      "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      "https://images.unsplash.com/photo-1540420773420-3366772f4999?ixlib=rb-1.2.1&auto=format&fit=crop&w=1351&q=80"
    ],
    "Vegan": [
      "https://images.unsplash.com/photo-1540420773420-3366772f4999?ixlib=rb-1.2.1&auto=format&fit=crop&w=1351&q=80",
      "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
    ],
    "High-Protein": [
      "https://images.unsplash.com/photo-1532550907401-a500c9a57435?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
    ],
    "Pasta": [
      "https://images.unsplash.com/photo-1556761223-4c4282c73f77?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      "https://images.unsplash.com/photo-1473093295043-cdd812d0e601?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
    ],
    "default": [
      "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      "https://images.unsplash.com/photo-1505253758473-96b7015fcd40?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1540189549336-5a0ec919847b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      "https://images.unsplash.com/photo-1473093295043-cdd812d0e601?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
    ]
  };

  // Try to match with a specific tag
  for (const tag of tags) {
    const categoryKey = Object.keys(imageMap).find(
      (key: string) => tag.toLowerCase().includes(key.toLowerCase())
    );

    if (categoryKey && imageMap[categoryKey].length > 0) {
      const randomIndex = Math.floor(Math.random() * imageMap[categoryKey].length);
      return imageMap[categoryKey][randomIndex];
    }
  }

  // Fallback to default
  const defaultImages = imageMap["default"];
  const randomIndex = Math.floor(Math.random() * defaultImages.length);
  return defaultImages[randomIndex];
}