-- Create tables based on our schema
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(255) NOT NULL UNIQUE,
  name VARCHAR(255),
  password VARCHAR(255),
  email VARCHAR(255) UNIQUE,
  image VARCHAR(255),
  provider VARCHAR(50),
  "providerId" VARCHAR(255),
  "createdAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "ageRange" VARCHAR(50),
  "isPregnant" BOOLEAN DEFAULT FALSE,
  allergies TEXT[] DEFAULT '{}',
  "medicalConditions" TEXT[] DEFAULT '{}',
  "dietaryRestrictions" TEXT[] DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS accounts (
  id SERIAL PRIMARY KEY,
  "userId" INTEGER REFERENCES users(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL,
  provider VARCHAR(50) NOT NULL,
  "providerAccountId" VARCHAR(255) NOT NULL,
  refresh_token TEXT,
  access_token TEXT,
  expires_at BIGINT,
  token_type VARCHAR(50),
  scope VARCHAR(255),
  id_token TEXT,
  session_state VARCHAR(255),
  UNIQUE(provider, "providerAccountId")
);

CREATE TABLE IF NOT EXISTS recipes (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  "preparationTime" INTEGER,
  "cookingTime" INTEGER,
  servings INTEGER,
  difficulty VARCHAR(50),
  cuisine VARCHAR(50),
  "mealType" VARCHAR(50),
  ingredients JSONB,
  instructions JSONB,
  "nutritionInfo" JSONB,
  image VARCHAR(255),
  "createdAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "userId" INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS "nutrition_logs" (
  id SERIAL PRIMARY KEY,
  "userId" INTEGER REFERENCES users(id) ON DELETE CASCADE,
  date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "foodItems" TEXT[] DEFAULT '{}',
  image VARCHAR(255),
  "healthScore" INTEGER,
  "healthCategory" VARCHAR(50),
  "nutritionalSummary" TEXT,
  "nutritionalHighlights" TEXT[] DEFAULT '{}',
  "healthBenefits" TEXT[] DEFAULT '{}',
  concerns TEXT[] DEFAULT '{}',
  alternatives TEXT[] DEFAULT '{}',
  "calorieEstimate" INTEGER,
  "proteinEstimate" INTEGER,
  "carbEstimate" INTEGER,
  "fatEstimate" INTEGER
);

-- Create session table for connect-pg-simple
CREATE TABLE IF NOT EXISTS "session" (
  "sid" varchar NOT NULL COLLATE "default",
  "sess" json NOT NULL,
  "expire" timestamp(6) NOT NULL
)
WITH (OIDS=FALSE);

ALTER TABLE "session" ADD CONSTRAINT "session_pkey" PRIMARY KEY ("sid") NOT DEFERRABLE INITIALLY IMMEDIATE;
CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON "session" ("expire");